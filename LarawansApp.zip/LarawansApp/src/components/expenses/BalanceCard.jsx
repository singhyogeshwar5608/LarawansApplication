import { TrendingUp, TrendingDown, Wallet, AlertCircle } from 'lucide-react';
import Card from '../ui/Card';
import Badge from '../ui/Badge';

const BalanceCard = ({ balance, onClick }) => {
  if (!balance) {
    return null;
  }

  // Current balance = Total Revenue - Total Expenses
  const totalRevenue = balance.totalRevenue || balance.totalIncome || 0;
  const totalExpenses = balance.totalExpenses || 0;
  const currentBalance = totalRevenue - totalExpenses; // Balance = Revenue - Expenses

  // Calculate percentage of revenue spent
  const expensePercentage = totalRevenue > 0 
    ? ((totalExpenses / totalRevenue) * 100).toFixed(1)
    : 0;

  // Determine balance status based on expense percentage and balance amount
  const getBalanceStatus = () => {
    // Check if balance is negative
    if (currentBalance < 0) {
      return {
        color: 'text-red-600 dark:text-red-400',
        bgColor: 'bg-red-50 dark:bg-red-900/20',
        borderColor: 'border-red-200 dark:border-red-800',
        status: 'Critical',
        icon: <AlertCircle size={20} className="text-red-600 dark:text-red-400" />,
      };
    }
    
    // Calculate expense percentage of revenue
    if (totalRevenue > 0) {
      const expensePercentage = (totalExpenses / totalRevenue) * 100;
      
      if (expensePercentage >= 100) {
        // Expenses exceed or equal revenue
        return {
          color: 'text-red-600 dark:text-red-400',
          bgColor: 'bg-red-50 dark:bg-red-900/20',
          borderColor: 'border-red-200 dark:border-red-800',
          status: 'Critical',
          icon: <AlertCircle size={20} className="text-red-600 dark:text-red-400" />,
        };
      } else if (expensePercentage >= 80) {
        // Expenses are 80% or more of revenue
        return {
          color: 'text-yellow-600 dark:text-yellow-400',
          bgColor: 'bg-yellow-50 dark:bg-yellow-900/20',
          borderColor: 'border-yellow-200 dark:border-yellow-800',
          status: 'Warning',
          icon: <TrendingDown size={20} className="text-yellow-600 dark:text-yellow-400" />,
        };
      }
    }
    
    // Healthy: Expenses are less than 80% of revenue
    return {
      color: 'text-green-600 dark:text-green-400',
      bgColor: 'bg-green-50 dark:bg-green-900/20',
      borderColor: 'border-green-200 dark:border-green-800',
      status: 'Healthy',
      icon: <TrendingUp size={20} className="text-green-600 dark:text-green-400" />,
    };
  };

  const status = getBalanceStatus();

  return (
    <Card
      className={`p-4 border-2 ${status.borderColor} ${status.bgColor} cursor-pointer hover:shadow-lg transition-all ${
        onClick ? 'hover:scale-[1.02]' : ''
      }`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Wallet size={24} className={status.color} />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Company Balance
          </h3>
        </div>
        <Badge
          className={`${status.bgColor} ${status.color} border ${status.borderColor}`}
          size="sm"
        >
          {status.status}
        </Badge>
      </div>

      <div className="space-y-3">
        {/* Current Balance */}
        <div>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Current Balance</p>
          <p className={`text-3xl font-bold ${currentBalance < 0 ? 'text-red-600 dark:text-red-400' : status.color}`}>
            {currentBalance < 0 ? '-' : ''}₹{Math.abs(currentBalance).toLocaleString('en-IN')}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 pt-3 border-t border-gray-200 dark:border-gray-700">
          <div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Total Expenses</p>
            <p className="text-lg font-semibold text-gray-900 dark:text-white">
              ₹{totalExpenses.toLocaleString('en-IN')}
            </p>
            {totalRevenue > 0 && (
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {expensePercentage}% of revenue
              </p>
            )}
          </div>
          <div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Total Revenue</p>
            <p className="text-lg font-semibold text-green-600 dark:text-green-400">
              ₹{totalRevenue.toLocaleString('en-IN')}
            </p>
          </div>
        </div>

        {/* Warning Message */}
        {currentBalance < 0 && (
          <div className="mt-3 p-2 bg-red-100 dark:bg-red-900/30 rounded-lg">
            <p className="text-xs text-red-700 dark:text-red-300">
              ⚠️ Your balance is negative. Please add revenue or reduce expenses.
            </p>
          </div>
        )}
        {currentBalance >= 0 && status.status === 'Warning' && (
          <div className="mt-3 p-2 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg">
            <p className="text-xs text-yellow-700 dark:text-yellow-300">
              ⚠️ Expenses are high relative to revenue. Consider reducing expenses.
            </p>
          </div>
        )}
        {currentBalance >= 0 && status.status === 'Critical' && (
          <div className="mt-3 p-2 bg-red-100 dark:bg-red-900/30 rounded-lg">
            <p className="text-xs text-red-700 dark:text-red-300">
              ⚠️ Expenses exceed revenue. Please reduce expenses or increase revenue.
            </p>
          </div>
        )}
      </div>
    </Card>
  );
};

export default BalanceCard;

