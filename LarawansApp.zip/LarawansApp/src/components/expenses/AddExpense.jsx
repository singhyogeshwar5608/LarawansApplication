import { useState } from 'react';
import { X } from 'lucide-react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Textarea from '../ui/Textarea';
import DatePicker from '../ui/DatePicker';
import Checkbox from '../ui/Checkbox';
import { addExpense } from '../../services/expenseService';
import { useToast } from '../../hooks/useToast';

const AddExpense = ({ isOpen, onClose, onSuccess }) => {
  const { success, error: showError } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [saveAndAddAnother, setSaveAndAddAnother] = useState(false);
  
  const [formData, setFormData] = useState({
    amount: '',
    category: '',
    paymentMethod: '',
    reason: '',
    expenseDate: new Date().toISOString().split('T')[0],
    tags: '',
    isRecurring: false,
    recurringFrequency: '',
  });

  const [errors, setErrors] = useState({});

  const categories = [
    { value: '', label: 'Select Category' },
    { value: 'Home', label: 'Home' },
    { value: 'Company', label: 'Company' },
    { value: 'Travel', label: 'Travel' },
    { value: 'Salary', label: 'Salary' },
    { value: 'Marketing', label: 'Marketing' },
    { value: 'Office Supplies', label: 'Office Supplies' },
    { value: 'Utilities', label: 'Utilities' },
    { value: 'Maintenance', label: 'Maintenance' },
    { value: 'Food & Beverages', label: 'Food & Beverages' },
    { value: 'Other', label: 'Other' },
  ];

  const paymentMethods = [
    { value: '', label: 'Select Payment Method' },
    { value: 'Cash', label: 'Cash 💵' },
    { value: 'UPI', label: 'UPI 📱' },
    { value: 'Bank Transfer', label: 'Bank Transfer 🏦' },
    { value: 'Credit Card', label: 'Credit Card 💳' },
    { value: 'Debit Card', label: 'Debit Card 💳' },
  ];

  const recurringFrequencies = [
    { value: '', label: 'Select Frequency' },
    { value: 'Daily', label: 'Daily' },
    { value: 'Weekly', label: 'Weekly' },
    { value: 'Monthly', label: 'Monthly' },
  ];

  const validate = () => {
    const newErrors = {};

    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      newErrors.amount = 'Amount must be a positive number';
    }

    if (!formData.category) {
      newErrors.category = 'Please select a category';
    }

    if (!formData.paymentMethod) {
      newErrors.paymentMethod = 'Please select a payment method';
    }

    if (!formData.reason || formData.reason.trim().length < 10) {
      newErrors.reason = 'Reason must be at least 10 characters';
    }

    if (formData.reason && formData.reason.length > 500) {
      newErrors.reason = 'Reason must be less than 500 characters';
    }

    if (formData.isRecurring && !formData.recurringFrequency) {
      newErrors.recurringFrequency = 'Please select a frequency';
    }

    // Check if date is in future
    const selectedDate = new Date(formData.expenseDate);
    const today = new Date();
    today.setHours(23, 59, 59, 999);
    if (selectedDate > today) {
      newErrors.expenseDate = 'Expense date cannot be in the future';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    if (e) e.preventDefault();
    
    if (!validate()) {
      return;
    }

    setIsSubmitting(true);
    try {
      const expenseData = {
        amount: parseFloat(formData.amount),
        category: formData.category,
        paymentMethod: formData.paymentMethod,
        reason: formData.reason.trim(),
        expenseDate: formData.expenseDate,
        tags: formData.tags ? formData.tags.split(',').map(t => t.trim()) : [],
        isRecurring: formData.isRecurring,
        recurringFrequency: formData.isRecurring ? formData.recurringFrequency : null,
        createdBy: 'User', // You can get from auth context
      };

      const result = await addExpense(expenseData);
      
      const formattedAmount = parseFloat(formData.amount).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
      
      // Show success message with balance update
      if (result.newBalance !== null && result.isBalanceUpdated) {
        success(`Expense added! ₹${formattedAmount} deducted. New balance: ₹${result.newBalance.toLocaleString('en-IN')}`);
      } else {
        success(`Expense of ₹${formattedAmount} added successfully!`);
      }
      
      if (onSuccess) {
        onSuccess(result);
      }

      if (saveAndAddAnother) {
        // Reset form but keep date
        setFormData({
          amount: '',
          category: '',
          paymentMethod: '',
          reason: '',
          expenseDate: formData.expenseDate,
          tags: '',
          isRecurring: false,
          recurringFrequency: '',
        });
        setErrors({});
      } else {
        onClose();
      }
    } catch (error) {
      console.error('Error adding expense:', error);
      showError('Failed to add expense. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    if (isSubmitting) return;
    setFormData({
      amount: '',
      category: '',
      paymentMethod: '',
      reason: '',
      expenseDate: new Date().toISOString().split('T')[0],
      tags: '',
      isRecurring: false,
      recurringFrequency: '',
    });
    setErrors({});
    setSaveAndAddAnother(false);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Add New Expense" size="lg">
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Amount */}
        <div>
          <Input
            type="number"
            label="Amount (₹)"
            placeholder="Amount"
            value={formData.amount}
            onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
            error={errors.amount}
            required
            min="1"
            step="0.01"
          />
        </div>

        {/* Category and Payment Method */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Select
              label="Category"
              options={categories}
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              error={errors.category}
              required
            />
          </div>
          <div>
            <Select
              label="Payment Method"
              options={paymentMethods}
              value={formData.paymentMethod}
              onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
              error={errors.paymentMethod}
              required
            />
          </div>
        </div>

        {/* Reason */}
        <div>
          <Textarea
            label="Reason / Description"
            placeholder="Reason / Description"
            value={formData.reason}
            onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
            error={errors.reason}
            required
            rows={3}
            maxLength={500}
          />
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            {formData.reason.length}/500 characters
          </p>
        </div>

        {/* Expense Date */}
        <div>
          <DatePicker
            label="Expense Date"
            value={formData.expenseDate}
            onChange={(e) => setFormData({ ...formData, expenseDate: e.target.value })}
            error={errors.expenseDate}
            max={new Date().toISOString().split('T')[0]}
          />
        </div>

        {/* Tags */}
        <div>
          <Input
            label="Tags (comma-separated)"
            placeholder="Tags"
            value={formData.tags}
            onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
            helperText="Optional: Add tags to categorize expenses"
          />
        </div>

        {/* Recurring Expense */}
        <div>
          <Checkbox
            checked={formData.isRecurring}
            onChange={(e) => setFormData({ ...formData, isRecurring: e.target.checked })}
            label="This is a recurring expense"
          />
          {formData.isRecurring && (
            <div className="mt-2">
              <Select
                label="Recurring Frequency"
                options={recurringFrequencies}
                value={formData.recurringFrequency}
                onChange={(e) => setFormData({ ...formData, recurringFrequency: e.target.value })}
                error={errors.recurringFrequency}
              />
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
          <Button
            type="button"
            variant="outline"
            fullWidth
            onClick={handleClose}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="outline"
            fullWidth
            onClick={() => {
              setSaveAndAddAnother(true);
              handleSubmit(new Event('submit'));
            }}
            disabled={isSubmitting}
          >
            Save & Add Another
          </Button>
          <Button
            type="submit"
            variant="primary"
            fullWidth
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Saving...' : 'Save & Close'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};

export default AddExpense;

