import { useState } from 'react';
import { Trash2 } from 'lucide-react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import { deleteExpense } from '../../services/expenseService';
import { useToast } from '../../hooks/useToast';

const ExpenseCard = ({ expense, onEdit, onDelete }) => {
  const { success, error: showError } = useToast();
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await deleteExpense(expense.id);
      success(`Expense of ₹${expense.amount.toLocaleString('en-IN')} deleted. Amount added back to balance.`);
      if (onDelete) {
        onDelete(expense.id);
      }
      setShowDeleteModal(false);
    } catch (error) {
      console.error('Error deleting expense:', error);
      showError('Failed to delete expense. Please try again.');
      setIsDeleting(false);
    }
  };

  return (
    <>
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
        <div className="flex items-center justify-between gap-4">
          {/* Left: Reason and Date */}
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 dark:text-white mb-1">
              {expense.reason}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {formatDate(expense.expenseDate)}
            </p>
          </div>

          {/* Right: Amount and Delete */}
          <div className="flex items-center gap-3">
            <p className="text-lg font-semibold text-gray-900 dark:text-white">
              ₹{expense.amount.toLocaleString('en-IN')}
            </p>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowDeleteModal(true);
              }}
              className="p-2 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-lg transition-colors"
              title="Delete Expense"
            >
              <Trash2 size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => !isDeleting && setShowDeleteModal(false)}
        title="Delete Expense"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-gray-700 dark:text-gray-300">
            Are you sure you want to delete this expense? This will add ₹{expense.amount.toLocaleString('en-IN')} back to your balance.
          </p>
          <div className="p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
            <p className="text-sm font-medium text-gray-900 dark:text-white">
              {expense.reason}
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {formatDate(expense.expenseDate)} • ₹{expense.amount.toLocaleString('en-IN')}
            </p>
          </div>
          <div className="flex items-center gap-3 pt-2">
            <Button
              variant="outline"
              fullWidth
              onClick={() => setShowDeleteModal(false)}
              disabled={isDeleting}
            >
              Cancel
            </Button>
            <Button
              variant="danger"
              fullWidth
              onClick={handleDelete}
              disabled={isDeleting}
              icon={isDeleting ? null : <Trash2 size={16} />}
            >
              {isDeleting ? 'Deleting...' : 'Delete'}
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default ExpenseCard;

