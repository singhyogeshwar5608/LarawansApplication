import { Calendar } from 'lucide-react';

const FollowUpBadge = ({ followUpDate, className = '' }) => {
  if (!followUpDate) return null;

  const now = new Date();
  now.setHours(0, 0, 0, 0);

  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const weekEnd = new Date(now);
  weekEnd.setDate(weekEnd.getDate() + 7);

  const followUp = followUpDate?.toDate 
    ? followUpDate.toDate() 
    : new Date(followUpDate);
  followUp.setHours(0, 0, 0, 0);

  const diffTime = followUp.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  let colorClass = '';
  let label = '';

  if (diffDays < 0) {
    // Overdue
    colorClass = 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 border-red-300 dark:border-red-700';
    label = 'Overdue';
  } else if (diffDays === 0) {
    // Today
    colorClass = 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400 border-orange-300 dark:border-orange-700';
    label = 'Today';
  } else if (diffDays === 1) {
    // Tomorrow
    colorClass = 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400 border-yellow-300 dark:border-yellow-700';
    label = 'Tomorrow';
  } else if (diffDays <= 7) {
    // This Week
    colorClass = 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 border-blue-300 dark:border-blue-700';
    label = 'This Week';
  } else {
    // Later
    colorClass = 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-400 border-gray-300 dark:border-gray-700';
    label = 'Later';
  }

  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${colorClass} ${className}`}
      title={`Follow-up: ${followUp.toLocaleDateString()}`}
    >
      <Calendar size={12} />
      {label}
    </span>
  );
};

export default FollowUpBadge;

