import { useState, useEffect } from 'react';
import { Phone, Calendar, MessageSquare, ChevronDown, ChevronUp } from 'lucide-react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import EmptyState from '../ui/EmptyState';
import { getCallHistory } from '../../services/callHistoryService';
import { formatIndianPhone } from '../../utils/phoneFormat';

const CallHistory = ({ leadId, leadPhone }) => {
  const [callHistory, setCallHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedRemarks, setExpandedRemarks] = useState({});

  useEffect(() => {
    if (leadId) {
      loadCallHistory();
    }
  }, [leadId]);

  const loadCallHistory = async () => {
    setLoading(true);
    try {
      const history = await getCallHistory(leadId);
      setCallHistory(history);
    } catch (error) {
      console.error('Error loading call history:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (date) => {
    if (!date) return 'N/A';
    
    const callDate = date?.toDate ? date.toDate() : new Date(date);
    const now = new Date();
    const diffTime = now - callDate;
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffMinutes = Math.floor(diffTime / (1000 * 60));

    if (diffMinutes < 1) return 'Just now';
    if (diffMinutes < 60) return `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    
    return callDate.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const toggleRemark = (callId) => {
    setExpandedRemarks({
      ...expandedRemarks,
      [callId]: !expandedRemarks[callId],
    });
  };

  const handleCall = () => {
    if (leadPhone) {
      const phoneNumber = leadPhone.replace(/\D/g, '');
      const cleanPhone = phoneNumber.startsWith('91') ? phoneNumber.slice(2) : phoneNumber;
      window.location.href = `tel:+91${cleanPhone}`;
    }
  };

  if (loading) {
    return (
      <Card>
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
        </div>
      </Card>
    );
  }

  if (callHistory.length === 0) {
    return (
      <Card>
        <EmptyState
          icon={Phone}
          title="No Call History"
          description="Start tracking calls by adding your first call record"
        />
      </Card>
    );
  }

  return (
    <Card title="Call History" subtitle={`${callHistory.length} call${callHistory.length > 1 ? 's' : ''} recorded`}>
      <div className="space-y-4">
        {callHistory.map((call, index) => {
          const isExpanded = expandedRemarks[call.id];
          const remarkLength = call.remark?.length || 0;
          const shouldTruncate = remarkLength > 100;
          const displayRemark = shouldTruncate && !isExpanded 
            ? call.remark.substring(0, 100) + '...' 
            : call.remark;

          return (
            <div
              key={call.id || index}
              className="border-l-4 border-primary-500 pl-4 py-3 bg-gray-50 dark:bg-gray-900/50 rounded-r-lg"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <Phone size={16} className="text-primary-600 dark:text-primary-400 flex-shrink-0" />
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {call.calledBy || 'User'}
                    </span>
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      {formatDate(call.calledAt)}
                    </span>
                  </div>

                  <div className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                    {displayRemark}
                    {shouldTruncate && (
                      <button
                        onClick={() => toggleRemark(call.id)}
                        className="ml-2 text-primary-600 dark:text-primary-400 hover:underline text-xs"
                      >
                        {isExpanded ? 'Show less' : 'Show more'}
                      </button>
                    )}
                  </div>

                  {call.followUpDate && (
                    <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400 mt-2">
                      <Calendar size={12} />
                      <span>
                        Follow-up: {new Date(call.followUpDate).toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                        })}
                        {call.followUpTime && ` (${call.followUpTime})`}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {leadPhone && (
        <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
          <Button
            variant="primary"
            icon={<Phone size={16} />}
            fullWidth
            onClick={handleCall}
          >
            Call {formatIndianPhone(leadPhone)}
          </Button>
        </div>
      )}
    </Card>
  );
};

export default CallHistory;

