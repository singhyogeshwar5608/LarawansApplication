import { useState, useRef } from 'react';
import { Upload, FileText, CheckCircle, XCircle, AlertCircle, AlertTriangle } from 'lucide-react';
import { usePapaParse } from 'react-papaparse';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import Badge from '../ui/Badge';
import Spinner from '../ui/Spinner';
import { useToast } from '../../hooks/useToast';
import { createLead, checkPhoneExists } from '../../services/leadsService';

const ImportCSV = ({ onImportComplete }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [previewData, setPreviewData] = useState([]);
  const [validRows, setValidRows] = useState([]);
  const [invalidRows, setInvalidRows] = useState([]);
  const [duplicateRows, setDuplicateRows] = useState([]);
  const [isCheckingDuplicates, setIsCheckingDuplicates] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef(null);
  const { success, error: showError } = useToast();
  const { readString } = usePapaParse();

  // Validation functions
  const validatePhone = (phone) => {
    if (!phone) return { valid: false, error: 'Phone is required' };
    const digits = phone.toString().replace(/\D/g, '');
    if (digits.length !== 10) {
      return { valid: false, error: 'Phone must be exactly 10 digits' };
    }
    return { valid: true, formatted: `+91-${digits.slice(0, 5)}-${digits.slice(5)}` };
  };

  const validateEmail = (email) => {
    if (!email) return { valid: true }; // Email is optional
    if (!email.includes('@') || !email.includes('.')) {
      return { valid: false, error: 'Invalid email format' };
    }
    return { valid: true };
  };

  const validateName = (name) => {
    if (!name || name.trim().length < 2) {
      return { valid: false, error: 'Name must be at least 2 characters' };
    }
    return { valid: true, formatted: name.trim() };
  };

  // Parse and validate CSV
  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.name.toLowerCase().endsWith('.csv')) {
      showError('Please select a CSV file');
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      return;
    }

    try {
      const fileContent = await file.text();

      readString(fileContent, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          if (results.errors.length > 0 && results.data.length === 0) {
            showError('Error parsing CSV file. Please check the format.');
            return;
          }

          if (results.data.length === 0) {
            showError('CSV file is empty');
            return;
          }

          // Validate and process rows
          const valid = [];
          const invalid = [];

          results.data.forEach((row, index) => {
            const rowNumber = index + 2; // +2 because header is row 1, and array is 0-indexed
            const errors = [];

            // Find phone number - check multiple possible column names
            const phoneValue = row.phone || row.Phone || row.number || row.Number || row.mobile || row.Mobile || '';
            
            // Validate phone (required)
            const phoneValidation = validatePhone(phoneValue);
            if (!phoneValidation.valid) {
              errors.push(phoneValidation.error);
            }

            // Name is optional - check multiple possible column names
            const nameValue = row.name || row.Name || row.fullname || row.FullName || '';
            let nameValidation = { valid: true, formatted: null };
            if (nameValue && nameValue.trim()) {
              nameValidation = validateName(nameValue);
              if (!nameValidation.valid) {
                errors.push(nameValidation.error);
              }
            }

            // Validate email (optional)
            const emailValue = row.email || row.Email || '';
            const emailValidation = validateEmail(emailValue);
            if (!emailValidation.valid) {
              errors.push(emailValidation.error);
            }

            if (errors.length > 0) {
              invalid.push({
                rowNumber,
                data: row,
                errors: errors.join(', '),
              });
            } else {
              valid.push({
                rowNumber,
                name: nameValidation.formatted || null,
                phone: phoneValidation.formatted,
                email: emailValue?.trim() || null,
                source: (row.source || row.Source)?.trim() || null,
                notes: (row.notes || row.Notes)?.trim() || null,
              });
            }
          });

          setPreviewData(valid);
          setValidRows(valid);
          setInvalidRows(invalid);
          setDuplicateRows([]);
          setIsModalOpen(true);
          
          // Check for duplicates after modal opens
          checkDuplicates(valid);
        },
        error: (error) => {
          showError(`Error reading CSV file: ${error.message}`);
        },
      });
    } catch (error) {
      console.error('Error reading file:', error);
      showError('Unable to read the CSV file. Please try again.');
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Check for duplicate phone numbers
  const checkDuplicates = async (validRowsData) => {
    if (validRowsData.length === 0) return;
    
    setIsCheckingDuplicates(true);
    const duplicates = [];
    const unique = [];

    try {
      // Check each phone number
      for (const row of validRowsData) {
        try {
          const exists = await checkPhoneExists(row.phone);
          if (exists) {
            duplicates.push({
              ...row,
              reason: 'Phone number already exists in database',
            });
          } else {
            unique.push(row);
          }
        } catch (error) {
          // If permission error, allow import but warn
          if (error.code === 'permission-denied') {
            console.warn('Cannot check duplicates - permissions not set up');
            // Add to unique to allow import
            unique.push(row);
          } else {
            console.error('Error checking duplicate:', error);
            // On error, add to unique to allow import
            unique.push(row);
          }
        }
      }

      setDuplicateRows(duplicates);
      setValidRows(unique); // Update valid rows to exclude duplicates
    } catch (error) {
      console.error('Error checking duplicates:', error);
    } finally {
      setIsCheckingDuplicates(false);
    }
  };

  // Import valid leads to Firebase (excluding duplicates)
  const handleImport = async () => {
    if (validRows.length === 0) {
      showError('No valid rows to import');
      return;
    }

    setIsImporting(true);

    try {
      let successCount = 0;
      let errorCount = 0;

      // Import leads one by one
      for (const row of validRows) {
        try {
          // Build notes combining email, source, and notes if provided
          let notes = row.notes || '';
          if (row.email) {
            notes = notes ? `${notes}\nEmail: ${row.email}` : `Email: ${row.email}`;
          }
          if (row.source) {
            notes = notes ? `${notes}\nSource: ${row.source}` : `Source: ${row.source}`;
          }

          const leadData = {
            phone: row.phone,
            name: row.name || null, // Name is optional
            status: 'new',
            notes: notes || null,
            city: null,
            district: null,
            businessDetails: null,
            services: [],
            followUpDate: null,
            meetingLocation: null,
            callHistory: [],
          };

          await createLead(leadData);
          successCount++;
        } catch (err) {
          console.error(`Error importing row ${row.rowNumber}:`, err);
          errorCount++;
        }
      }

      setIsModalOpen(false);
      setPreviewData([]);
      setValidRows([]);
      setInvalidRows([]);
      setDuplicateRows([]);

      if (successCount > 0) {
        let message = `Successfully imported ${successCount} lead${successCount > 1 ? 's' : ''}`;
        if (duplicateRows.length > 0) {
          message += `. ${duplicateRows.length} duplicate${duplicateRows.length > 1 ? 's' : ''} skipped.`;
        }
        success(message);
        if (onImportComplete) {
          onImportComplete();
        }
      } else if (duplicateRows.length > 0) {
        showError(`All ${duplicateRows.length} phone number${duplicateRows.length > 1 ? 's are' : ' is'} already in your database. No new leads imported.`);
      }

      if (errorCount > 0) {
        showError(`Failed to import ${errorCount} lead${errorCount > 1 ? 's' : ''}`);
      }
    } catch (error) {
      console.error('Error during import:', error);
      showError('Error importing leads. Please try again.');
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <>
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv"
        onChange={handleFileSelect}
        className="hidden"
        id="csv-import-input"
      />
      <Button
        variant="outline"
        size="sm"
        icon={<Upload size={16} />}
        onClick={() => fileInputRef.current?.click()}
        className="flex-shrink-0"
      >
        <span className="hidden sm:inline">Import CSV</span>
        <span className="sm:hidden">CSV</span>
      </Button>

      <Modal
        isOpen={isModalOpen}
        onClose={() => !isImporting && setIsModalOpen(false)}
        title="Preview Import"
        size="xl"
        footer={
          <div className="flex flex-col sm:flex-row gap-2 sm:justify-end">
            <Button
              variant="outline"
              onClick={() => setIsModalOpen(false)}
              disabled={isImporting}
              fullWidth
              className="sm:w-auto"
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={handleImport}
              loading={isImporting}
              disabled={isImporting || validRows.length === 0}
              fullWidth
              className="sm:w-auto"
            >
              Import {validRows.length} Lead{validRows.length !== 1 ? 's' : ''}
            </Button>
          </div>
        }
      >
        {isImporting ? (
          <div className="flex flex-col items-center justify-center py-8">
            <Spinner size="lg" label="Importing leads..." />
          </div>
        ) : (
          <div className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                  <span className="text-sm font-medium text-green-700 dark:text-green-300">
                    Will Import
                  </span>
                </div>
                <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                  {validRows.length}
                </p>
              </div>

              <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                  <span className="text-sm font-medium text-yellow-700 dark:text-yellow-300">
                    Duplicates
                  </span>
                </div>
                <p className="text-2xl font-bold text-yellow-900 dark:text-yellow-100">
                  {duplicateRows.length}
                </p>
              </div>

              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <XCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
                  <span className="text-sm font-medium text-red-700 dark:text-red-300">
                    Invalid Rows
                  </span>
                </div>
                <p className="text-2xl font-bold text-red-900 dark:text-red-100">
                  {invalidRows.length}
                </p>
              </div>

              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                    Total Rows
                  </span>
                </div>
                <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                  {validRows.length + duplicateRows.length + invalidRows.length}
                </p>
              </div>
            </div>

            {/* Duplicate rows details */}
            {isCheckingDuplicates && (
              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                <div className="flex items-center gap-2">
                  <Spinner size="sm" />
                  <span className="text-sm text-blue-700 dark:text-blue-300">
                    Checking for duplicate phone numbers...
                  </span>
                </div>
              </div>
            )}

            {duplicateRows.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                  <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
                    Duplicate Phone Numbers (will be skipped)
                  </h3>
                </div>
                <div className="max-h-48 overflow-y-auto overflow-x-auto border border-yellow-200 dark:border-yellow-800 rounded-lg bg-yellow-50/50 dark:bg-yellow-900/10">
                  <table className="w-full text-sm min-w-[400px]">
                    <thead className="bg-yellow-100 dark:bg-yellow-900/30 sticky top-0">
                      <tr>
                        <th className="px-3 py-2 text-left text-xs font-medium text-yellow-800 dark:text-yellow-300">
                          Row
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-yellow-800 dark:text-yellow-300">
                          Phone
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-yellow-800 dark:text-yellow-300">
                          Name
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-yellow-800 dark:text-yellow-300">
                          Reason
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-yellow-200 dark:divide-yellow-800">
                      {duplicateRows.map((row) => (
                        <tr key={row.rowNumber} className="bg-white dark:bg-gray-800">
                          <td className="px-3 py-2 text-gray-900 dark:text-gray-100">
                            {row.rowNumber}
                          </td>
                          <td className="px-3 py-2 text-gray-900 dark:text-gray-100 font-medium">
                            {row.phone}
                          </td>
                          <td className="px-3 py-2 text-gray-600 dark:text-gray-400">
                            {row.name || '-'}
                          </td>
                          <td className="px-3 py-2">
                            <Badge variant="warning" size="sm">
                              {row.reason}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="mt-2 text-xs text-yellow-700 dark:text-yellow-300">
                  These phone numbers already exist in your database. They will be automatically skipped during import.
                </p>
              </div>
            )}

            {/* Invalid rows details */}
            {invalidRows.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
                  <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
                    Invalid Rows (will be skipped)
                  </h3>
                </div>
                <div className="max-h-48 overflow-y-auto overflow-x-auto border border-gray-200 dark:border-gray-700 rounded-lg">
                  <table className="w-full text-sm min-w-[400px]">
                    <thead className="bg-gray-50 dark:bg-gray-800 sticky top-0">
                      <tr>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300">
                          Row
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300">
                          Data
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300">
                          Error
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                      {invalidRows.map((row) => (
                        <tr key={row.rowNumber} className="bg-white dark:bg-gray-800">
                          <td className="px-3 py-2 text-gray-900 dark:text-gray-100">
                            {row.rowNumber}
                          </td>
                          <td className="px-3 py-2 text-gray-600 dark:text-gray-400 text-xs">
                            {JSON.stringify(row.data).slice(0, 50)}...
                          </td>
                          <td className="px-3 py-2">
                            <Badge variant="danger" size="sm">
                              {row.errors}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Valid rows preview */}
            {validRows.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
                    Valid Rows (will be imported)
                  </h3>
                </div>
                <div className="max-h-96 overflow-y-auto overflow-x-auto border border-gray-200 dark:border-gray-700 rounded-lg">
                  <table className="w-full text-sm min-w-[500px]">
                    <thead className="bg-gray-50 dark:bg-gray-800 sticky top-0">
                      <tr>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300">
                          Row
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300">
                          Phone
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300">
                          Name
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300">
                          Email
                        </th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300">
                          Source
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                      {validRows.map((row) => (
                        <tr key={row.rowNumber} className="bg-white dark:bg-gray-800">
                          <td className="px-3 py-2 text-gray-900 dark:text-gray-100">
                            {row.rowNumber}
                          </td>
                          <td className="px-3 py-2 text-gray-600 dark:text-gray-400 font-medium">
                            {row.phone}
                          </td>
                          <td className="px-3 py-2 text-gray-900 dark:text-gray-100">
                            {row.name || '-'}
                          </td>
                          <td className="px-3 py-2 text-gray-600 dark:text-gray-400">
                            {row.email || '-'}
                          </td>
                          <td className="px-3 py-2 text-gray-600 dark:text-gray-400">
                            {row.source || '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* CSV Format Info */}
            <div className="p-3 sm:p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
              <p className="text-xs font-medium text-blue-900 dark:text-blue-100 mb-2">
                CSV Format Options:
              </p>
              <div className="space-y-2 sm:space-y-3">
                <div>
                  <p className="text-xs font-semibold text-blue-800 dark:text-blue-200 mb-1">
                    Option 1: Phone Only (Simplest)
                  </p>
                  <code className="text-[10px] sm:text-xs text-blue-800 dark:text-blue-200 block bg-blue-100 dark:bg-blue-900/40 p-2 rounded overflow-x-auto">
                    phone<br />
                    9876543210<br />
                    9876543211
                  </code>
                </div>
                <div>
                  <p className="text-xs font-semibold text-blue-800 dark:text-blue-200 mb-1">
                    Option 2: Phone + Name
                  </p>
                  <code className="text-[10px] sm:text-xs text-blue-800 dark:text-blue-200 block bg-blue-100 dark:bg-blue-900/40 p-2 rounded overflow-x-auto">
                    phone,name<br />
                    9876543210,John Doe
                  </code>
                </div>
                <div>
                  <p className="text-xs font-semibold text-blue-800 dark:text-blue-200 mb-1">
                    Option 3: Full Format
                  </p>
                  <code className="text-[10px] sm:text-xs text-blue-800 dark:text-blue-200 block bg-blue-100 dark:bg-blue-900/40 p-2 rounded overflow-x-auto">
                    phone,name,email,source,notes
                  </code>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-blue-300 dark:border-blue-700">
                <p className="text-[10px] sm:text-xs text-blue-700 dark:text-blue-300 leading-relaxed">
                  <strong>Required:</strong> phone (10 digits)<br />
                  <strong>Optional:</strong> name, email, source, notes
                </p>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
};

export default ImportCSV;

