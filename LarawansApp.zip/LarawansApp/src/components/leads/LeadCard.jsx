import { Phone, Calendar, MessageCircle, Edit, Trash2, ChevronDown } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Badge from '../ui/Badge';
import FollowUpBadge from './FollowUpBadge';
import Checkbox from '../ui/Checkbox';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import AddCallRecord from './AddCallRecord';
import { updateLead, deleteLead } from '../../services/leadsService';
import { useToast } from '../../hooks/useToast';
import { formatIndianPhone, getWhatsAppLink } from '../../utils/phoneFormat';

const LeadCard = ({ lead, isSelected = false, onSelect }) => {
  const navigate = useNavigate();
  const { success, error: showError } = useToast();
  const [swipeOffset, setSwipeOffset] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showAddCallModal, setShowAddCallModal] = useState(false);
  const [showCallStatusDropdown, setShowCallStatusDropdown] = useState(false);
  const touchStartX = useRef(0);
  const touchStartY = useRef(0);
  const dropdownRef = useRef(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowCallStatusDropdown(false);
      }
    };

    if (showCallStatusDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [showCallStatusDropdown]);
  
  const formatDateTime = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleCall = (e) => {
    if (e) e.stopPropagation();
    if (!lead || !lead.phone) return;
    const phoneNumber = lead.phone.replace(/\D/g, '');
    const cleanPhone = phoneNumber.startsWith('91') ? phoneNumber.slice(2) : phoneNumber;
    window.location.href = `tel:+91${cleanPhone}`;
  };

  const handleWhatsApp = (e) => {
    if (e) e.stopPropagation();
    window.open(getWhatsAppLink(lead.phone), '_blank');
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await deleteLead(lead.id);
      success('Lead deleted successfully');
      setShowDeleteModal(false);
    } catch (error) {
      console.error('Error deleting lead:', error);
      showError('Failed to delete lead. Please try again.');
      setIsDeleting(false);
    }
  };

  const handleTouchStart = (e) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    setIsSwiping(true);
  };

  const handleTouchMove = (e) => {
    if (!isSwiping) return;
    
    const touchX = e.touches[0].clientX;
    const touchY = e.touches[0].clientY;
    const deltaX = touchX - touchStartX.current;
    const deltaY = Math.abs(touchY - touchStartY.current);
    
    // Only allow horizontal swipe (not vertical)
    if (deltaY < 50) {
      // Left swipe (negative deltaX) = Call
      // Right swipe (positive deltaX) = WhatsApp
      const maxSwipe = 100;
      if (deltaX < 0) {
        // Swipe left for call
        const offset = Math.max(deltaX, -maxSwipe);
        setSwipeOffset(offset);
      } else if (deltaX > 0) {
        // Swipe right for WhatsApp
        const offset = Math.min(deltaX, maxSwipe);
        setSwipeOffset(offset);
      }
    }
  };

  const handleTouchEnd = () => {
    if (swipeOffset < -60) {
      // Swipe left threshold reached, trigger call
      handleCall();
    } else if (swipeOffset > 60) {
      // Swipe right threshold reached, trigger WhatsApp
      handleWhatsApp();
    }
    setSwipeOffset(0);
    setIsSwiping(false);
  };

  return (
    <div className="relative rounded-lg">
      {/* Swipe Action Backgrounds */}
      <div className="absolute inset-0 flex items-center justify-between z-0">
        {/* Left swipe - Call */}
        <div 
          className={`w-24 h-full bg-blue-600 flex items-center justify-center transition-opacity duration-200 ${
            swipeOffset < -40 ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <Phone size={24} className="text-white" />
        </div>
        
        {/* Right swipe - WhatsApp */}
        <div 
          className={`w-24 h-full bg-green-600 flex items-center justify-center ml-auto transition-opacity duration-200 ${
            swipeOffset > 40 ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <MessageCircle size={24} className="text-white" />
        </div>
      </div>
      
      {/* Main Card */}
      <div
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className={`bg-white dark:bg-gray-800 rounded-lg border-2 p-3 transition-all duration-200 relative z-10 ${
          isSelected 
            ? 'border-blue-500 dark:border-blue-400 bg-blue-50 dark:bg-blue-900/20' 
            : 'border-gray-200 dark:border-gray-700'
        }`}
        style={{ transform: `translateX(${swipeOffset}px)` }}
      >
        {/* Header: Checkbox, Status Badge and Action Icons */}
        <div className="flex items-center justify-between mb-2 gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            {onSelect && (
              <div onClick={(e) => e.stopPropagation()}>
                <Checkbox
                  checked={isSelected}
                  onChange={onSelect}
                />
              </div>
            )}
            <Badge status={lead.status || 'new'} size="sm" />
            <FollowUpBadge followUpDate={lead.nextFollowUp} />
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/leads/${lead.id}/edit`);
              }}
              className="p-1.5 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              disabled={isUpdating || isDeleting}
              title="Edit Lead"
            >
              <Edit size={16} />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleCall(e);
              }}
              className="p-1.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors"
              disabled={isUpdating || isDeleting}
              title="Call"
            >
              <Phone size={16} />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowDeleteModal(true);
              }}
              className="p-1.5 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-200 dark:hover:bg-red-900/50 transition-colors"
              disabled={isUpdating || isDeleting}
              title="Delete Lead"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>

        {/* Phone Number */}
        <div className="mb-2">
          <div className="flex items-center gap-2">
            <p className="text-base sm:text-lg font-bold text-gray-900 dark:text-white">
              {formatIndianPhone(lead.phone)}
            </p>
            {lead.status === 'interested' && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleWhatsApp(e);
                }}
                className="p-1 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded hover:bg-green-200 dark:hover:bg-green-900/50 transition-colors"
                title="WhatsApp"
              >
                <MessageCircle size={16} />
              </button>
            )}
          </div>
        </div>

        {/* Date Added */}
        <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400 mb-3">
          <Calendar size={12} />
          <span>{formatDateTime(lead.createdAt)}</span>
        </div>

        {/* Call Status Dropdown */}
        <div ref={dropdownRef} className="pt-2 border-t border-gray-200 dark:border-gray-700 relative z-50">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowCallStatusDropdown(!showCallStatusDropdown);
            }}
            className="w-full flex items-center justify-between gap-2 px-3 py-2.5 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors text-sm font-medium"
          >
            <span>{lead.callStatus || 'Select Call Status'}</span>
            <ChevronDown size={16} className={`transition-transform ${showCallStatusDropdown ? 'rotate-180' : ''}`} />
          </button>
          
          {showCallStatusDropdown && (
            <div className="absolute left-0 right-0 top-full mt-1 bg-white dark:bg-gray-800 border-2 border-gray-300 dark:border-gray-600 rounded-lg shadow-2xl z-[100] max-h-64 overflow-y-auto">
              {[
                { value: 'interested', label: 'Interested', color: 'green' },
                { value: 'not_interested', label: 'Not Interested', color: 'red' },
                { value: 'no_answer', label: 'No Answer', color: 'gray' },
                { value: 'call_back', label: 'Call Back', color: 'yellow' },
                { value: 'busy', label: 'Busy', color: 'orange' },
                { value: 'switch_off', label: 'Switch Off', color: 'purple' },
              ].map((status) => (
                <button
                  key={status.value}
                  onClick={async (e) => {
                    e.stopPropagation();
                    setShowCallStatusDropdown(false);
                    setIsUpdating(true);
                    try {
                      // Map call status to lead status
                      let newLeadStatus = lead.status;
                      if (status.value === 'interested') {
                        newLeadStatus = 'interested';
                      } else if (status.value === 'not_interested') {
                        newLeadStatus = 'rejected';
                      } else if (status.value === 'call_back' || status.value === 'no_answer' || status.value === 'busy' || status.value === 'switch_off') {
                        newLeadStatus = 'scheduled';
                      }
                      
                      await updateLead(lead.id, { 
                        callStatus: status.label,
                        status: newLeadStatus,
                        lastCallDate: new Date().toISOString()
                      });
                      success(`Call status updated to ${status.label}`);
                      if (status.value === 'interested') {
                        setTimeout(() => {
                          navigate(`/leads/${lead.id}/edit`);
                        }, 300);
                      }
                    } catch (error) {
                      console.error('Error updating call status:', error);
                      showError('Failed to update call status');
                    } finally {
                      setIsUpdating(false);
                    }
                  }}
                  className="w-full px-3 py-2.5 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-900 dark:text-white transition-colors border-b border-gray-100 dark:border-gray-700 last:border-0"
                >
                  {status.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Show name if available (for non-new leads) */}
        {lead.status !== 'new' && lead.name && (
          <div className="pt-2 border-t border-gray-200 dark:border-gray-700">
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
              {lead.name}
            </p>
          </div>
        )}
      </div>

      {/* Add Call Record Modal */}
      <AddCallRecord
        isOpen={showAddCallModal}
        onClose={() => setShowAddCallModal(false)}
        leadId={lead.id}
        leadName={lead.name || formatIndianPhone(lead.phone)}
        onSuccess={() => {
          setShowAddCallModal(false);
        }}
      />

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => !isDeleting && setShowDeleteModal(false)}
        title="Delete Lead"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-gray-700 dark:text-gray-300">
            Are you sure you want to delete this lead? This action cannot be undone.
          </p>
          {lead.phone && (
            <div className="p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
              <p className="text-sm font-medium text-gray-900 dark:text-white">
                {lead.name || 'Unknown Lead'}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {formatIndianPhone(lead.phone)}
              </p>
            </div>
          )}
          <div className="flex items-center gap-3 pt-2">
            <Button
              variant="outline"
              fullWidth
              onClick={() => setShowDeleteModal(false)}
              disabled={isDeleting}
            >
              Cancel
            </Button>
            <Button
              variant="danger"
              fullWidth
              onClick={handleDelete}
              disabled={isDeleting}
              icon={isDeleting ? null : <Trash2 size={16} />}
            >
              {isDeleting ? 'Deleting...' : 'Delete'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default LeadCard;
