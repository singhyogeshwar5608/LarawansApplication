import { useState } from 'react';
import { X, Phone, Calendar } from 'lucide-react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Textarea from '../ui/Textarea';
import Select from '../ui/Select';
import DatePicker from '../ui/DatePicker';
import Toggle from '../ui/Toggle';
import { useToast } from '../../hooks/useToast';
import { addCallRecord } from '../../services/callHistoryService';
import { useAuth } from '../../context/AuthContext';

const AddCallRecord = ({ isOpen, onClose, leadId, leadName, onSuccess }) => {
  const { user } = useAuth();
  const { success, error: showError } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    remark: '',
    needsFollowUp: false,
    followUpDate: '',
    followUpTime: 'morning',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validation
    if (!formData.remark.trim()) {
      showError('Please enter a remark');
      return;
    }

    if (formData.remark.trim().length < 10) {
      showError('Remark must be at least 10 characters');
      return;
    }

    if (formData.remark.trim().length > 500) {
      showError('Remark must be less than 500 characters');
      return;
    }

    if (formData.needsFollowUp && !formData.followUpDate) {
      showError('Please select a follow-up date');
      return;
    }

    if (formData.needsFollowUp && formData.followUpDate) {
      const selectedDate = new Date(formData.followUpDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      selectedDate.setHours(0, 0, 0, 0);

      if (selectedDate.getTime() < today.getTime()) {
        showError('Follow-up date cannot be in the past');
        return;
      }
    }

    setLoading(true);
    try {
      const callData = {
        remark: formData.remark.trim(),
        duration: 'N/A', // Duration removed as per user request
        calledBy: user?.displayName || user?.email || 'User',
        calledAt: new Date(),
        followUpDate: formData.needsFollowUp && formData.followUpDate 
          ? new Date(formData.followUpDate).toISOString().split('T')[0]
          : null,
        followUpTime: formData.needsFollowUp ? formData.followUpTime : null,
      };

      await addCallRecord(leadId, callData);
      success('Call record added successfully!');
      
      // Reset form
      setFormData({
        remark: '',
        needsFollowUp: false,
        followUpDate: '',
        followUpTime: 'morning',
      });

      onClose();
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error('Error adding call record:', error);
      showError('Failed to add call record. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDate = (type) => {
    const today = new Date();
    let date = new Date(today);

    if (type === 'tomorrow') {
      date.setDate(date.getDate() + 1);
    }

    // Format date as YYYY-MM-DD for date input
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const dateStr = `${year}-${month}-${day}`;
    
    setFormData({
      ...formData,
      needsFollowUp: true,
      followUpDate: dateStr,
    });
  };

  if (!isOpen) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="md">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">
              Add Call Record
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              {leadName}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Textarea
            label="Call Remark *"
            value={formData.remark}
            onChange={(e) => setFormData({ ...formData, remark: e.target.value })}
            rows={4}
            placeholder="Enter details about the call..."
            helperText={`${formData.remark.length}/500 characters (minimum 10)`}
            maxLength={500}
            required
          />

          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-2">
              <Calendar size={18} className="text-gray-500 dark:text-gray-400" />
              <span className="text-sm font-medium text-gray-900 dark:text-white">
                Follow-up Needed?
              </span>
            </div>
            <Toggle
              checked={formData.needsFollowUp}
              onChange={(checked) => setFormData({ ...formData, needsFollowUp: checked })}
            />
          </div>

          {formData.needsFollowUp && (
            <div className="space-y-4 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Follow-up Date *
                </label>
                <div className="flex gap-2 mb-3">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickDate('today')}
                    className="flex-1"
                  >
                    Today
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickDate('tomorrow')}
                    className="flex-1"
                  >
                    Tomorrow
                  </Button>
                </div>
                <DatePicker
                  value={formData.followUpDate}
                  onChange={(e) => setFormData({ ...formData, followUpDate: e.target.value })}
                  min={new Date().toISOString().split('T')[0]}
                  required
                />
              </div>

              <Select
                label="Follow-up Time"
                value={formData.followUpTime}
                onChange={(e) => setFormData({ ...formData, followUpTime: e.target.value })}
                options={[
                  { value: 'morning', label: 'Morning (9 AM - 12 PM)' },
                  { value: 'afternoon', label: 'Afternoon (12 PM - 5 PM)' },
                  { value: 'evening', label: 'Evening (5 PM - 8 PM)' },
                ]}
              />
            </div>
          )}

          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              fullWidth
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              fullWidth
              loading={loading}
              icon={<Phone size={16} />}
            >
              Save Call Record
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
};

export default AddCallRecord;

