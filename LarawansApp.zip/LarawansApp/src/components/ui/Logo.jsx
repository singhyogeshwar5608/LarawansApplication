import logoImage from '../../assets/Logo.png';

const Logo = ({ className = '', size = 'default' }) => {
  const sizeClasses = {
    small: 'h-8 w-8',
    default: 'h-12 w-12',
    large: 'h-16 w-16',
    xl: 'h-24 w-24'
  };

  return (
    <img 
      src={logoImage} 
      alt="Larawans Digital Agency" 
      className={`${sizeClasses[size]} ${className}`}
      onError={(e) => {
        // Fallback to text if image fails to load
        e.target.style.display = 'none';
        if (!e.target.nextSibling) {
          const fallback = document.createElement('span');
          fallback.className = 'text-lg font-bold text-primary-600';
          fallback.textContent = 'Larawans';
          e.target.parentNode.appendChild(fallback);
        }
      }}
    />
  );
};

export default Logo;

