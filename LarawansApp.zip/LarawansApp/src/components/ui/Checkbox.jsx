import { Check } from 'lucide-react';

const Checkbox = ({
  checked,
  onChange,
  label,
  disabled = false,
  error,
  helperText,
  className = '',
  ...props
}) => {
  return (
    <div className={className}>
      <label className={`inline-flex items-center cursor-pointer ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}>
        <div className="relative flex items-center justify-center min-w-[44px] min-h-[44px]">
          <input
            type="checkbox"
            checked={checked}
            onChange={onChange}
            disabled={disabled}
            className="sr-only peer"
            {...props}
          />
          <div className="w-5 h-5 border-2 border-gray-300 dark:border-gray-600 rounded peer-checked:bg-primary-600 peer-checked:border-primary-600 transition-all duration-200 flex items-center justify-center">
            {checked && <Check size={14} className="text-white" />}
          </div>
        </div>
        {label && (
          <span className="ml-2 text-sm text-gray-900 dark:text-gray-100">
            {label}
          </span>
        )}
      </label>
      
      {error && (
        <p className="mt-1 text-sm text-red-600 dark:text-red-400">{error}</p>
      )}
      
      {helperText && !error && (
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{helperText}</p>
      )}
    </div>
  );
};

export default Checkbox;

