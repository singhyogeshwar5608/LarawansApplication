const Radio = ({
  checked,
  onChange,
  label,
  value,
  name,
  disabled = false,
  className = '',
  ...props
}) => {
  return (
    <label className={`inline-flex items-center cursor-pointer ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${className}`}>
      <div className="relative flex items-center justify-center min-w-[44px] min-h-[44px]">
        <input
          type="radio"
          checked={checked}
          onChange={onChange}
          value={value}
          name={name}
          disabled={disabled}
          className="sr-only peer"
          {...props}
        />
        <div className="w-5 h-5 border-2 border-gray-300 dark:border-gray-600 rounded-full peer-checked:border-primary-600 transition-all duration-200 flex items-center justify-center">
          {checked && (
            <div className="w-2.5 h-2.5 bg-primary-600 rounded-full" />
          )}
        </div>
      </div>
      {label && (
        <span className="ml-2 text-sm text-gray-900 dark:text-gray-100">
          {label}
        </span>
      )}
    </label>
  );
};

// Radio Group Component
export const RadioGroup = ({
  options = [],
  value,
  onChange,
  name,
  label,
  error,
  helperText,
  disabled = false,
  orientation = 'vertical',
  className = '',
}) => {
  return (
    <div className={className}>
      {label && (
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          {label}
        </label>
      )}
      
      <div className={`flex ${orientation === 'vertical' ? 'flex-col space-y-2' : 'flex-row space-x-4'}`}>
        {options.map((option) => (
          <Radio
            key={option.value}
            name={name}
            value={option.value}
            checked={value === option.value}
            onChange={() => onChange(option.value)}
            label={option.label}
            disabled={disabled || option.disabled}
          />
        ))}
      </div>

      {error && (
        <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>
      )}
      
      {helperText && !error && (
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">{helperText}</p>
      )}
    </div>
  );
};

export default Radio;

