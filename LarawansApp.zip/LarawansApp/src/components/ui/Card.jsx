const Card = ({
  children,
  title,
  subtitle,
  footer,
  hoverable = false,
  className = '',
  padding = 'normal',
  onClick,
  ...props
}) => {
  const baseStyles = 'bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 transition-all duration-200';
  
  const hoverStyles = hoverable
    ? 'hover:shadow-card-hover hover:border-gray-300 dark:hover:border-gray-600 cursor-pointer'
    : 'shadow-card';

  const paddingStyles = {
    none: '',
    sm: 'p-3',
    normal: 'p-4',
    lg: 'p-6',
  };

  return (
    <div
      className={`${baseStyles} ${hoverStyles} ${paddingStyles[padding]} ${className}`}
      onClick={onClick}
      {...props}
    >
      {(title || subtitle) && (
        <div className="mb-3 sm:mb-4">
          {title && (
            <h3 className="text-base sm:text-lg font-semibold text-gray-900 dark:text-gray-100">
              {typeof title === 'string' ? title : title}
            </h3>
          )}
          {subtitle && (
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 mt-1">
              {subtitle}
            </p>
          )}
        </div>
      )}
      
      <div className="card-content">
        {children}
      </div>

      {footer && (
        <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
          {footer}
        </div>
      )}
    </div>
  );
};

export default Card;

