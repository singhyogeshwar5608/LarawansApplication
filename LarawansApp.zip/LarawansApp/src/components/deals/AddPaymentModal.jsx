import { useState } from 'react';
import Modal from '../ui/Modal';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Textarea from '../ui/Textarea';
import Button from '../ui/Button';
import { useToast } from '../../hooks/useToast';

const AddPaymentModal = ({ isOpen, onClose, deal, onPaymentAdded }) => {
  const { success } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    date: new Date().toISOString().split('T')[0],
    mode: '',
    notes: '',
  });
  const [errors, setErrors] = useState({});

  const paymentModes = [
    { value: '', label: 'Select payment mode' },
    { value: 'cash', label: 'Cash' },
    { value: 'online', label: 'Online (UPI/Net Banking)' },
    { value: 'card', label: 'Card (Credit/Debit)' },
    { value: 'cheque', label: 'Cheque' },
    { value: 'bank', label: 'Bank Transfer' },
  ];

  const validate = () => {
    const newErrors = {};

    if (!formData.amount) {
      newErrors.amount = 'Amount is required';
    } else if (parseFloat(formData.amount) <= 0) {
      newErrors.amount = 'Amount must be greater than 0';
    } else if (parseFloat(formData.amount) > deal.pendingAmount) {
      newErrors.amount = `Cannot exceed pending amount (₹${deal.pendingAmount})`;
    }

    if (!formData.mode) {
      newErrors.mode = 'Payment mode is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) return;

    setLoading(true);

    // Simulate API call
    setTimeout(() => {
      const payment = {
        id: `payment_${Date.now()}`,
        ...formData,
        amount: parseFloat(formData.amount),
        receivedBy: 'You',
        timestamp: new Date().toISOString(),
      };

      setLoading(false);
      success('Payment added successfully!');
      
      // Check if fully paid
      const newPaidAmount = deal.paidAmount + payment.amount;
      if (newPaidAmount >= deal.totalAmount) {
        success('🎉 Deal fully paid! Congratulations!', { duration: 5000 });
      }

      onPaymentAdded(payment);
      onClose();
      
      // Reset form
      setFormData({
        amount: '',
        date: new Date().toISOString().split('T')[0],
        mode: '',
        notes: '',
      });
    }, 1000);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="💳 Add Payment"
      size="md"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSubmit} loading={loading}>
            💾 Save Payment
          </Button>
        </>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-lg">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600 dark:text-gray-400">Deal:</span>
            <span className="font-semibold text-gray-900 dark:text-white">
              {deal.customerName}
            </span>
          </div>
          <div className="flex justify-between text-sm mt-1">
            <span className="text-gray-600 dark:text-gray-400">Pending:</span>
            <span className="font-semibold text-orange-600 dark:text-orange-400">
              ₹{deal.pendingAmount.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        <Input
          label="💰 Payment Amount"
          type="number"
          placeholder="Enter amount"
          value={formData.amount}
          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
          error={errors.amount}
          required
          helperText={`Maximum: ₹${deal.pendingAmount.toLocaleString('en-IN')}`}
        />

        <Input
          label="📅 Payment Date"
          type="date"
          value={formData.date}
          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
          max={new Date().toISOString().split('T')[0]}
          required
        />

        <Select
          label="💳 Payment Mode"
          options={paymentModes}
          value={formData.mode}
          onChange={(e) => setFormData({ ...formData, mode: e.target.value })}
          error={errors.mode}
          required
        />

        <Textarea
          label="📝 Payment Note"
          placeholder="Any notes about this payment..."
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          rows={3}
        />
      </form>
    </Modal>
  );
};

export default AddPaymentModal;

