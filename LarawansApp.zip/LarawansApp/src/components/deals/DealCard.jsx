import { Phone, MoreVertical } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Button from '../ui/Button';
import Checkbox from '../ui/Checkbox';
import { formatIndianPhone } from '../../utils/phoneFormat';

const DealCard = ({ deal, isSelected = false, onSelect }) => {
  const navigate = useNavigate();

  const progressPercentage = deal.totalAmount > 0 
    ? ((deal.paidAmount / deal.totalAmount) * 100).toFixed(0)
    : 0;

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  const calculateDaysLeft = () => {
    if (!deal.completionDays || !deal.createdAt) return null;
    
    const createdDate = new Date(deal.createdAt);
    const completionDate = new Date(createdDate);
    completionDate.setDate(completionDate.getDate() + parseInt(deal.completionDays));
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    completionDate.setHours(0, 0, 0, 0);
    
    const diffTime = completionDate - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  const daysLeft = calculateDaysLeft();

  const getBorderColor = () => {
    if (deal.pendingAmount === 0) return 'border-l-green-500';
    if (deal.pendingAmount > 0) return 'border-l-blue-500';
    return 'border-l-gray-300';
  };

  const handleCall = (e) => {
    e.stopPropagation();
    window.location.href = `tel:${deal.customerPhone}`;
  };

  return (
    <div
      className={`bg-white dark:bg-gray-800 rounded-lg border-l-4 ${getBorderColor()} shadow-sm hover:shadow-md transition-all duration-200 animate-slide-up ${
        isSelected 
          ? 'border-2 border-blue-500 dark:border-blue-400 bg-blue-50 dark:bg-blue-900/20' 
          : 'border-2 border-transparent'
      }`}
    >
      <div className="p-3">
        {/* Header */}
        <div className="flex items-start justify-between mb-1.5">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            {onSelect && (
              <div onClick={(e) => e.stopPropagation()}>
                <Checkbox
                  checked={isSelected}
                  onChange={() => onSelect(deal.id)}
                />
              </div>
            )}
            <div className="flex-1 min-w-0" onClick={() => navigate(`/deals/${deal.id}`)}>
              <div className="flex items-center gap-1.5 mb-1">
                <span className="text-lg">💼</span>
                <h3 className="text-sm sm:text-base font-bold text-gray-900 dark:text-white truncate">
                  {deal.customerName}
                </h3>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleCall(e);
                }}
                className="flex items-center gap-1 text-xs sm:text-sm text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
              >
                <Phone size={12} />
                <span className="truncate">{formatIndianPhone(deal.customerPhone)}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Services */}
        {deal.services && deal.services.length > 0 && (
          <div 
            className="flex items-center gap-1.5 mb-1.5 text-xs text-gray-700 dark:text-gray-300 cursor-pointer"
            onClick={() => navigate(`/deals/${deal.id}`)}
          >
            <span>🎯</span>
            <span className="truncate">{deal.services.join(' • ')}</span>
          </div>
        )}

        {/* Payment Info */}
        <div 
          className="space-y-1 mb-1.5 cursor-pointer"
          onClick={() => navigate(`/deals/${deal.id}`)}
        >
          <div className="flex justify-between text-xs">
            <span className="text-gray-600 dark:text-gray-400">Total:</span>
            <span className="font-semibold text-gray-900 dark:text-white">
              ₹{deal.totalAmount.toLocaleString('en-IN')}
            </span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-600 dark:text-gray-400">Paid:</span>
            <span className="font-semibold text-green-600 dark:text-green-400">
              ₹{deal.paidAmount.toLocaleString('en-IN')} ({progressPercentage}%)
            </span>
          </div>
          {deal.pendingAmount > 0 && (
            <div className="flex justify-between text-xs">
              <span className="text-gray-600 dark:text-gray-400">Pending:</span>
              <span className="font-semibold text-orange-600 dark:text-orange-400">
                ₹{deal.pendingAmount.toLocaleString('en-IN')}
              </span>
            </div>
          )}
        </div>

        {/* Days Left */}
        {daysLeft !== null && (
          <div 
            className={`mb-1.5 p-1.5 rounded-lg text-center cursor-pointer ${
              daysLeft < 0 
                ? 'bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-400'
                : daysLeft <= 3
                ? 'bg-orange-100 dark:bg-orange-900/20 text-orange-700 dark:text-orange-400'
                : 'bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400'
            }`}
            onClick={() => navigate(`/deals/${deal.id}`)}
          >
            <p className="text-xs font-semibold">
              {daysLeft < 0 
                ? `⚠️ Overdue by ${Math.abs(daysLeft)} day${Math.abs(daysLeft) > 1 ? 's' : ''}`
                : daysLeft === 0
                ? '⚠️ Due Today'
                : `⏱️ ${daysLeft} day${daysLeft > 1 ? 's' : ''} left`
              }
            </p>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            fullWidth
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/deals/${deal.id}`);
            }}
            className="text-xs py-1.5"
          >
            Invoice
          </Button>
        </div>
      </div>
    </div>
  );
};

export default DealCard;

