import { useState } from 'react';
import { X, Calendar } from 'lucide-react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input from '../ui/Input';

const PaymentHistoryFilter = ({ isOpen, onClose, onApply, totalPaymentCount, initialFilters = {} }) => {
  const [selectedPeriod, setSelectedPeriod] = useState(initialFilters.period || '');
  const [startDate, setStartDate] = useState(initialFilters.startDate || '');
  const [endDate, setEndDate] = useState(initialFilters.endDate || '');
  const [selectedStatus, setSelectedStatus] = useState(initialFilters.status || '');

  const periodOptions = [
    { id: 'today', label: 'Today' },
    { id: 'thisWeek', label: 'This week' },
    { id: 'thisMonth', label: 'This month' },
    { id: 'previousMonth', label: 'Previous month' },
    { id: 'thisYear', label: 'This year' },
  ];

  const statusOptions = [
    { id: 'all', label: 'All' },
    { id: 'paid', label: 'Paid' },
    { id: 'pending', label: 'Pending' },
  ];

  const handleClear = () => {
    setSelectedPeriod('');
    setStartDate('');
    setEndDate('');
    setSelectedStatus('');
  };

  const handlePeriodSelect = (periodId) => {
    setSelectedPeriod(periodId);
    
    // Auto-fill dates based on period
    const today = new Date();
    let start, end;
    
    switch (periodId) {
      case 'today':
        start = end = today.toISOString().split('T')[0];
        break;
      case 'thisWeek':
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - today.getDay());
        start = weekStart.toISOString().split('T')[0];
        end = today.toISOString().split('T')[0];
        break;
      case 'thisMonth':
        start = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
        end = today.toISOString().split('T')[0];
        break;
      case 'previousMonth':
        const prevMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const lastDayPrevMonth = new Date(today.getFullYear(), today.getMonth(), 0);
        start = prevMonth.toISOString().split('T')[0];
        end = lastDayPrevMonth.toISOString().split('T')[0];
        break;
      case 'thisYear':
        start = new Date(today.getFullYear(), 0, 1).toISOString().split('T')[0];
        end = today.toISOString().split('T')[0];
        break;
      default:
        return;
    }
    
    setStartDate(start);
    setEndDate(end);
  };

  const handleApply = () => {
    onApply({
      period: selectedPeriod,
      startDate,
      endDate,
      status: selectedStatus,
    });
    onClose();
  };

  const hasFilters = selectedPeriod || startDate || endDate || selectedStatus;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center justify-between w-full">
          <span>Filters</span>
          {hasFilters && (
            <button
              onClick={handleClear}
              className="text-xs sm:text-sm text-primary-600 dark:text-primary-400 hover:underline"
            >
              Clear
            </button>
          )}
        </div>
      }
      size="md"
      footer={
        <div className="flex gap-2 w-full">
          <Button
            variant="outline"
            onClick={handleClear}
            className="flex-1 text-xs sm:text-sm"
            disabled={!hasFilters}
          >
            Clear
          </Button>
          <Button
            variant="primary"
            onClick={handleApply}
            className="flex-1 text-xs sm:text-sm"
          >
            Show results ({totalPaymentCount})
          </Button>
        </div>
      }
    >
      <div className="space-y-4 sm:space-y-5">
        {/* Period Section */}
        <div>
          <label className="block text-xs sm:text-sm font-semibold text-gray-900 dark:text-white mb-2">
            Period
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {periodOptions.map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => handlePeriodSelect(option.id)}
                className={`py-2 px-3 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  selectedPeriod === option.id
                    ? 'bg-primary-600 text-white border-2 border-primary-600'
                    : 'bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-primary-300 dark:hover:border-primary-700'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        {/* Select Period Section */}
        <div>
          <label className="block text-xs sm:text-sm font-semibold text-gray-900 dark:text-white mb-2">
            Select period
          </label>
          <div className="flex items-center gap-2">
            <Input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setSelectedPeriod('');
              }}
              className="flex-1 text-xs sm:text-sm"
              icon={<Calendar size={14} />}
            />
            <span className="text-gray-500 dark:text-gray-400">-</span>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setSelectedPeriod('');
              }}
              className="flex-1 text-xs sm:text-sm"
              icon={<Calendar size={14} />}
            />
          </div>
        </div>

        {/* Status Section */}
        <div>
          <label className="block text-xs sm:text-sm font-semibold text-gray-900 dark:text-white mb-2">
            Status
          </label>
          <div className="grid grid-cols-3 gap-2">
            {statusOptions.map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => setSelectedStatus(option.id)}
                className={`py-2 px-3 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  selectedStatus === option.id
                    ? 'bg-primary-600 text-white border-2 border-primary-600'
                    : 'bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-primary-300 dark:hover:border-primary-700'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default PaymentHistoryFilter;

