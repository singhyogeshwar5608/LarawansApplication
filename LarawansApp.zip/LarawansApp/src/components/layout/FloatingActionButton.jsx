import { Plus } from 'lucide-react';

const FloatingActionButton = ({ onClick, icon: Icon = Plus, label }) => {
  return (
    <button
      onClick={onClick}
      className="fixed bottom-20 right-4 lg:bottom-8 lg:right-8 z-30 w-14 h-14 bg-primary-600 hover:bg-primary-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center group"
      aria-label={label}
    >
      <Icon size={24} />
      
      {label && (
        <span className="absolute right-16 whitespace-nowrap bg-gray-900 text-white text-sm px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          {label}
        </span>
      )}
    </button>
  );
};

export default FloatingActionButton;

