// Main Settings page - redirects to SettingsMain
import SettingsMain from './settings/SettingsMain';

const Settings = () => {
  return <SettingsMain />;
};

export default Settings;

