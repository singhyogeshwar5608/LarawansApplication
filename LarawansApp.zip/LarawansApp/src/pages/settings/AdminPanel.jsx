import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Settings, Shield, Plus, GripVertical, Trash2 } from 'lucide-react';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Toggle from '../../components/ui/Toggle';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import { getAppSettings, updateAppSettings } from '../../services/settingsService';

const AdminPanel = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { success, showError } = useToast();
  const [loading, setLoading] = useState(false);
  const [appSettings, setAppSettings] = useState({
    services: [
      { id: '1', name: 'Meta Ads', icon: '📱', order: 1, enabled: true },
      { id: '2', name: 'Website Development', icon: '🌐', order: 2, enabled: true },
      { id: '3', name: 'Marketplace Setup', icon: '🛒', order: 3, enabled: true },
      { id: '4', name: 'Others', icon: '➕', order: 4, enabled: true },
    ],
    features: {
      whatsapp: true,
      email: true,
      sms: true,
      portfolio: true,
      voiceNotes: true,
    },
    preferences: {
      defaultFollowUp: '3',
      dateFormat: 'DD/MM/YYYY',
      currency: '₹ INR',
      timeFormat: '12',
    },
  });

  useEffect(() => {
    if (user) {
      loadAppSettings();
    }
  }, [user]);

  const loadAppSettings = async () => {
    try {
      const settings = await getAppSettings();
      if (settings) {
        setAppSettings(settings);
      }
      // If no settings found, that's okay - use defaults
    } catch (error) {
      // Error is already handled in getAppSettings
      console.warn('App settings not available:', error.message);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      await updateAppSettings(appSettings);
      success('Settings saved successfully!');
      navigate('/settings');
    } catch (error) {
      console.error('Error saving settings:', error);
      showError('Failed to save settings');
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageContainer>
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/settings')}
              icon={ArrowLeft}
            >
              Back
            </Button>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Panel</h1>
          </div>
          <Button variant="primary" onClick={handleSave} loading={loading}>
            Save All Changes
          </Button>
        </div>

        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
          <div className="flex items-center gap-2">
            <Shield size={18} className="text-yellow-600 dark:text-yellow-400" />
            <p className="text-sm font-medium text-yellow-800 dark:text-yellow-300">
              SUPER ADMIN CONTROLS - Changes here affect the entire application for all users.
            </p>
          </div>
        </div>

        <Card title="SERVICES MANAGEMENT">
          <div className="space-y-4">
            {appSettings.services.map((service) => (
              <div
                key={service.id}
                className="flex items-center gap-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg"
              >
                <GripVertical size={20} className="text-gray-400 cursor-move" />
                <span className="text-2xl">{service.icon}</span>
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900 dark:text-white">{service.name}</h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Display Order: {service.order}
                  </p>
                </div>
                <Toggle
                  checked={service.enabled}
                  onChange={(e) => {
                    const updated = appSettings.services.map((s) =>
                      s.id === service.id ? { ...s, enabled: e.target.checked } : s
                    );
                    setAppSettings({ ...appSettings, services: updated });
                  }}
                />
                <Button variant="outline" size="sm">
                  Configure
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  icon={Trash2}
                  className="text-red-600 hover:text-red-700"
                >
                  Delete
                </Button>
              </div>
            ))}
            <Button variant="outline" icon={Plus} fullWidth>
              Add New Service
            </Button>
          </div>
        </Card>

        <Card title="APP FEATURES TOGGLE">
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                Communication:
              </h4>
              <div className="space-y-2">
                {[
                  { key: 'whatsapp', label: 'WhatsApp Integration' },
                  { key: 'email', label: 'Email Notifications' },
                  { key: 'sms', label: 'SMS Reminders' },
                ].map(({ key, label }) => (
                  <div key={key} className="flex items-center justify-between">
                    <span className="text-sm text-gray-700 dark:text-gray-300">{label}</span>
                    <Toggle
                      checked={appSettings.features[key]}
                      onChange={(e) => {
                        setAppSettings({
                          ...appSettings,
                          features: { ...appSettings.features, [key]: e.target.checked },
                        });
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                Portfolio:
              </h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-700 dark:text-gray-300">
                    Portfolio Link Sharing
                  </span>
                  <Toggle
                    checked={appSettings.features.portfolio}
                    onChange={(e) => {
                      setAppSettings({
                        ...appSettings,
                        features: { ...appSettings.features, portfolio: e.target.checked },
                      });
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </Card>

        <Card title="DEFAULT PREFERENCES">
          <div className="space-y-4">
            <Input
              label="Default Follow-up Duration"
              value={appSettings.preferences.defaultFollowUp}
              onChange={(e) => {
                setAppSettings({
                  ...appSettings,
                  preferences: {
                    ...appSettings.preferences,
                    defaultFollowUp: e.target.value,
                  },
                });
              }}
            />
            <Select
              label="Date Format"
              value={appSettings.preferences.dateFormat}
              onChange={(e) => {
                setAppSettings({
                  ...appSettings,
                  preferences: {
                    ...appSettings.preferences,
                    dateFormat: e.target.value,
                  },
                });
              }}
              options={[
                { value: 'DD/MM/YYYY', label: 'DD/MM/YYYY' },
                { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY' },
                { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD' },
              ]}
            />
            <Select
              label="Currency Symbol"
              value={appSettings.preferences.currency}
              onChange={(e) => {
                setAppSettings({
                  ...appSettings,
                  preferences: {
                    ...appSettings.preferences,
                    currency: e.target.value,
                  },
                });
              }}
              options={[
                { value: '₹ INR', label: '₹ INR' },
                { value: '$ USD', label: '$ USD' },
                { value: '€ EUR', label: '€ EUR' },
              ]}
            />
          </div>
        </Card>
      </div>
    </PageContainer>
  );
};

export default AdminPanel;

