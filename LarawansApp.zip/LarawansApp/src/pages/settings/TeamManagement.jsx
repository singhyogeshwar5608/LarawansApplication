import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Users,
  Plus,
  Edit2,
  Trash2,
  Crown,
  User as UserIcon,
  Mail,
  Phone,
  Calendar,
  TrendingUp,
  Download,
} from 'lucide-react';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Avatar from '../../components/ui/Avatar';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import { subscribeToTeamMembers } from '../../services/settingsService';

const TeamManagement = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { success, showError } = useToast();
  const [teamMembers, setTeamMembers] = useState([]);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteData, setInviteData] = useState({
    email: '',
    name: '',
    phone: '',
    role: 'team_member',
  });

  useEffect(() => {
    if (user) {
      // Subscribe to team members
      const unsubscribe = subscribeToTeamMembers(user.uid, (members) => {
        setTeamMembers(members);
      });
      return () => unsubscribe();
    }
  }, [user]);

  const handleInvite = () => {
    if (!inviteData.email) {
      showError('Email is required');
      return;
    }
    // TODO: Implement invite logic
    success('Invitation sent successfully!');
    setShowInviteModal(false);
    setInviteData({ email: '', name: '', phone: '', role: 'team_member' });
  };

  const handleRemove = (memberId) => {
    if (window.confirm('Are you sure you want to remove this team member?')) {
      // TODO: Implement remove logic
      success('Team member removed');
    }
  };

  const mockMembers = [
    {
      id: '1',
      name: user?.displayName || 'You',
      email: user?.email || '',
      phone: '+91-9876543210',
      role: 'owner',
      memberSince: '15 Oct 2024',
      lastActive: 'Just now',
      stats: {
        leads: 28,
        deals: 15,
        revenue: 675000,
        portfolioShares: 45,
      },
    },
    {
      id: '2',
      name: 'Rahul Verma',
      email: 'rahul@email.com',
      phone: '+91-9123456789',
      role: 'team_member',
      memberSince: '20 Oct 2024',
      lastActive: '2 hours ago',
      stats: {
        leads: 15,
        deals: 6,
        revenue: 350000,
        portfolioShares: 28,
      },
    },
  ];

  const displayMembers = teamMembers.length > 0 ? teamMembers : mockMembers;

  return (
    <PageContainer>
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/settings')}
              icon={ArrowLeft}
            >
              Back
            </Button>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Team Management
            </h1>
          </div>
          <Button
            variant="primary"
            icon={Plus}
            onClick={() => setShowInviteModal(true)}
          >
            Invite Team Member
          </Button>
        </div>

        <Card>
          <div className="flex items-center gap-2 mb-4">
            <Users size={18} />
            <h3 className="font-semibold">YOUR TEAM ({displayMembers.length}/3 Slots Used)</h3>
          </div>

          <div className="space-y-4">
            {displayMembers.map((member) => (
              <Card key={member.id} className="border-2">
                <div className="flex items-start gap-4">
                  <Avatar name={member.name} size="lg" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-gray-900 dark:text-white">
                        {member.name}
                      </h4>
                      {member.role === 'owner' && (
                        <Crown size={16} className="text-yellow-500" />
                      )}
                    </div>
                    <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                      <div className="flex items-center gap-2">
                        <Mail size={14} />
                        <span>{member.email}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone size={14} />
                        <span>{member.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs px-2 py-1 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 rounded">
                          {member.role === 'owner' ? 'Owner' : 'Team Member'}
                        </span>
                      </div>
                    </div>

                    {member.stats && (
                      <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
                        <p className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Performance (This Month):
                        </p>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                          <div>
                            <span className="text-gray-500 dark:text-gray-400">Leads:</span>
                            <span className="ml-1 font-semibold text-gray-900 dark:text-white">
                              {member.stats.leads}
                            </span>
                          </div>
                          <div>
                            <span className="text-gray-500 dark:text-gray-400">Deals:</span>
                            <span className="ml-1 font-semibold text-gray-900 dark:text-white">
                              {member.stats.deals}
                            </span>
                          </div>
                          <div>
                            <span className="text-gray-500 dark:text-gray-400">Revenue:</span>
                            <span className="ml-1 font-semibold text-gray-900 dark:text-white">
                              ₹{member.stats.revenue.toLocaleString()}
                            </span>
                          </div>
                          <div>
                            <span className="text-gray-500 dark:text-gray-400">Shares:</span>
                            <span className="ml-1 font-semibold text-gray-900 dark:text-white">
                              {member.stats.portfolioShares}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="mt-3 flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                      <Calendar size={12} />
                      <span>Member since: {member.memberSince}</span>
                      <span className="mx-2">•</span>
                      <span>Last active: {member.lastActive}</span>
                    </div>

                    {member.role !== 'owner' && (
                      <div className="mt-4 flex gap-2">
                        <Button variant="outline" size="sm" icon={Edit2}>
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          icon={Trash2}
                          onClick={() => handleRemove(member.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          Remove
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </Card>

        {/* Invite Modal */}
        {showInviteModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-md">
              <h3 className="text-lg font-semibold mb-4">Invite Team Member</h3>
              <div className="space-y-4">
                <Input
                  label="Email Address *"
                  type="email"
                  value={inviteData.email}
                  onChange={(e) => setInviteData({ ...inviteData, email: e.target.value })}
                />
                <Input
                  label="Full Name"
                  value={inviteData.name}
                  onChange={(e) => setInviteData({ ...inviteData, name: e.target.value })}
                />
                <Input
                  label="Phone Number (Optional)"
                  value={inviteData.phone}
                  onChange={(e) => setInviteData({ ...inviteData, phone: e.target.value })}
                />
                <Select
                  label="Assign Role *"
                  value={inviteData.role}
                  onChange={(e) => setInviteData({ ...inviteData, role: e.target.value })}
                  options={[
                    { value: 'team_member', label: 'Team Member (Recommended)' },
                    { value: 'admin', label: 'Admin' },
                  ]}
                />
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    fullWidth
                    onClick={() => setShowInviteModal(false)}
                  >
                    Cancel
                  </Button>
                  <Button variant="primary" fullWidth onClick={handleInvite}>
                    Send Invitation
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </PageContainer>
  );
};

export default TeamManagement;

