import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Building2, Upload, Eye, X } from 'lucide-react';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import Textarea from '../../components/ui/Textarea';
import Button from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import { getBusinessProfile, updateBusinessProfile } from '../../services/settingsService';
import { generateInvoiceWithLogo } from '../../utils/invoiceGenerator';
import logoImage from '../../assets/Logo.png';

const BusinessProfile = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { success, showError } = useToast();
  const [loading, setLoading] = useState(false);
  const [loadingProfile, setLoadingProfile] = useState(true);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [logoPreview, setLogoPreview] = useState(null);
  const fileInputRef = useRef(null);
  const [formData, setFormData] = useState({
    companyName: '',
    businessType: '',
    tagline: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    phone: '',
    email: '',
    website: '',
    gstNumber: '',
    panNumber: '',
    invoicePrefix: 'INV-',
    invoiceNumber: '001',
    invoiceTerms: 'Please submit some token money so that we can proceed. You can pay via Google Pay, PhonePe, or UPI. Taxes are included.',
    invoiceNotes: '',
    defaultTaxPercent: 0,
    bankName: '',
    accountNumber: '',
    ifscCode: '',
    upiId: '',
    logoUrl: '',
  });

  useEffect(() => {
    if (user) {
      loadBusinessProfile();
    } else {
      setLoadingProfile(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const loadBusinessProfile = async () => {
    if (!user || !user.uid) {
      setLoadingProfile(false);
      return;
    }
    
    setLoadingProfile(true);
    try {
      const profile = await getBusinessProfile(user.uid);
      if (profile) {
        setFormData({
          companyName: profile.companyName || '',
          businessType: profile.businessType || '',
          tagline: profile.tagline || '',
          address: profile.address || '',
          city: profile.city || '',
          state: profile.state || '',
          pincode: profile.pincode || '',
          phone: profile.phone || '',
          email: profile.email || '',
          website: profile.website || '',
          gstNumber: profile.gstNumber || '',
          panNumber: profile.panNumber || '',
          invoicePrefix: profile.invoicePrefix || 'INV-',
          invoiceNumber: profile.invoiceNumber || '001',
          invoiceTerms: profile.invoiceTerms || 'Please submit some token money so that we can proceed. You can pay via Google Pay, PhonePe, or UPI. Taxes are included.',
          invoiceNotes: profile.invoiceNotes || '',
          defaultTaxPercent: profile.defaultTaxPercent || 0,
          bankName: profile.bankName || '',
          accountNumber: profile.accountNumber || '',
          ifscCode: profile.ifscCode || '',
          upiId: profile.upiId || '',
          logoUrl: profile.logoUrl || logoImage,
        });
        // Set logo preview - use saved logo or default from assets
        if (profile.logoUrl) {
          setLogoPreview(profile.logoUrl);
        } else {
          setLogoPreview(logoImage);
        }
      } else {
        // No profile exists yet - set default logo
        setLogoPreview(logoImage);
        setFormData({
          ...formData,
          logoUrl: logoImage,
        });
      }
    } catch (error) {
      console.error('Error loading business profile:', error);
      // Set default logo even if there's an error
      setLogoPreview(logoImage);
      setFormData({
        ...formData,
        logoUrl: logoImage,
      });
    } finally {
      setLoadingProfile(false);
    }
  };

  const handleLogoUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      showError('Please select an image file');
      return;
    }

    // Validate file size (2MB max)
    if (file.size > 2 * 1024 * 1024) {
      showError('File size must be less than 2MB');
      return;
    }

    setUploadingLogo(true);
    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result;
      setLogoPreview(base64);
      // Store base64 image (in production, upload to Firebase Storage)
      setFormData({ ...formData, logoUrl: base64 });
      setUploadingLogo(false);
    };
    reader.onerror = () => {
      showError('Failed to read image file');
      setUploadingLogo(false);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveLogo = () => {
    // Reset to default logo from assets
    setLogoPreview(logoImage);
    setFormData({ ...formData, logoUrl: logoImage });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handlePreviewInvoice = async () => {
    if (!user) {
      showError('Please login to preview invoice');
      return;
    }

    // Create a sample deal for preview
    const sampleDeal = {
      id: 'preview',
      dealId: `${formData.invoicePrefix}${formData.invoiceNumber}`,
      customerName: 'Sample Customer',
      customerPhone: '+91-9876543210',
      customerAddress: '123 Sample Street, Sample City',
      services: ['Sample Service 1', 'Sample Service 2'],
      totalAmount: 10000,
      paidAmount: 5000,
      pendingAmount: 5000,
      tax: formData.defaultTaxPercent ? (10000 * formData.defaultTaxPercent / 100) : 0,
      taxPercent: formData.defaultTaxPercent || 0,
      discount: 0,
      dealNotes: formData.invoiceNotes || 'This is a preview invoice.',
      createdAt: new Date().toISOString(),
    };

    try {
      setLoading(true);
      await generateInvoiceWithLogo(sampleDeal, user.uid);
      success('Invoice preview generated!');
    } catch (error) {
      console.error('Error generating preview:', error);
      showError('Failed to generate invoice preview. Please check your business settings.');
    } finally {
      setLoading(false);
    }
  };

  const validateForm = () => {
    if (!formData.companyName.trim()) {
      showError('Company name is required');
      return false;
    }
    if (!formData.address.trim()) {
      showError('Office address is required');
      return false;
    }
    if (!formData.city.trim()) {
      showError('City is required');
      return false;
    }
    if (!formData.state.trim()) {
      showError('State is required');
      return false;
    }
    if (!formData.pincode.trim()) {
      showError('Pincode is required');
      return false;
    }
    if (!formData.phone.trim()) {
      showError('Business phone is required');
      return false;
    }
    if (!formData.email.trim()) {
      showError('Business email is required');
      return false;
    }
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      showError('Please enter a valid email address');
      return false;
    }
    return true;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      await updateBusinessProfile(user.uid, formData);
      success('Business profile saved successfully!');
      navigate('/settings');
    } catch (error) {
      console.error('Error saving business profile:', error);
      showError('Failed to save business profile');
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <PageContainer>
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <p className="text-gray-600 dark:text-gray-400">Please login to view business profile</p>
            </div>
          </div>
        </div>
      </PageContainer>
    );
  }

  if (loadingProfile) {
    return (
      <PageContainer>
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
              <p className="text-gray-600 dark:text-gray-400">Loading business profile...</p>
            </div>
          </div>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/settings')}
              icon={<ArrowLeft size={16} />}
            >
              Back
            </Button>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Business Profile
            </h1>
          </div>
          <Button variant="primary" onClick={handleSave} loading={loading}>
            Save
          </Button>
        </div>

        <Card title="COMPANY INFORMATION">
          <div className="space-y-4">
            <div className="text-center">
              <div className="relative inline-block">
                <div className="w-32 h-32 bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center mb-2 overflow-hidden">
                  {logoPreview ? (
                    <img
                      src={logoPreview}
                      alt="Company Logo"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <Building2 size={48} className="text-gray-400" />
                  )}
                </div>
                {logoPreview && (
                  <button
                    onClick={handleRemoveLogo}
                    className="absolute top-0 right-0 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
                    title="Remove logo"
                  >
                    <X size={16} />
                  </button>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleLogoUpload}
                className="hidden"
                id="logo-upload"
              />
              <label htmlFor="logo-upload" className="cursor-pointer">
                <Button
                  variant="outline"
                  size="sm"
                  icon={<Upload size={16} />}
                  className="cursor-pointer"
                  disabled={uploadingLogo}
                  type="button"
                >
                  {logoPreview ? 'Change Logo' : 'Upload New Logo'}
                </Button>
              </label>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                Recommended: 500x500px, PNG • Max size: 2MB
              </p>
            </div>
            <Input
              label="Company Name *"
              value={formData.companyName}
              onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
            />
            <Input
              label="Business Type"
              value={formData.businessType}
              onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
              placeholder="Business Type"
            />
            <Input
              label="Tagline/Slogan"
              value={formData.tagline}
              onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
              helperText="Appears on invoices"
            />
          </div>
        </Card>

        <Card title="CONTACT DETAILS">
          <div className="space-y-4">
            <Textarea
              label="Office Address *"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              rows={3}
              placeholder="Office Address"
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="City *"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              />
              <Input
                label="State *"
                value={formData.state}
                onChange={(e) => setFormData({ ...formData, state: e.target.value })}
              />
            </div>
            <Input
              label="Pincode *"
              value={formData.pincode}
              onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
            />
            <Input
              label="Business Phone *"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              helperText="Appears on invoices"
            />
            <Input
              label="Business Email *"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              helperText="Appears on invoices"
            />
            <Input
              label="Website URL"
              value={formData.website}
              onChange={(e) => setFormData({ ...formData, website: e.target.value })}
            />
          </div>
        </Card>

        <Card title="TAX & LEGAL DETAILS">
          <div className="space-y-4">
            <Input
              label="GST Number"
              value={formData.gstNumber}
              onChange={(e) => setFormData({ ...formData, gstNumber: e.target.value })}
              helperText="Optional, for invoices"
            />
            <Input
              label="PAN Number"
              value={formData.panNumber}
              onChange={(e) => setFormData({ ...formData, panNumber: e.target.value })}
            />
          </div>
        </Card>

        <Card title="INVOICE CONFIGURATION">
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Invoice Prefix"
                value={formData.invoicePrefix}
                onChange={(e) => setFormData({ ...formData, invoicePrefix: e.target.value })}
                helperText="Example: INV-001, LWNS-001"
              />
              <Input
                label="Starting Invoice Number"
                value={formData.invoiceNumber}
                onChange={(e) => setFormData({ ...formData, invoiceNumber: e.target.value })}
                helperText={`Next invoice: ${formData.invoicePrefix}${formData.invoiceNumber}`}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Default Tax Percentage"
                type="number"
                value={formData.defaultTaxPercent || 0}
                onChange={(e) => setFormData({ ...formData, defaultTaxPercent: parseFloat(e.target.value) || 0 })}
                helperText="Default tax rate for invoices (e.g., 18 for 18%)"
              />
            </div>
            <Textarea
              label="Invoice Notes (Default)"
              value={formData.invoiceNotes || ''}
              onChange={(e) => setFormData({ ...formData, invoiceNotes: e.target.value })}
              rows={3}
              placeholder="Invoice Notes"
            />
            <Textarea
              label="Invoice Terms & Conditions"
              value={formData.invoiceTerms || ''}
              onChange={(e) => setFormData({ ...formData, invoiceTerms: e.target.value })}
              rows={4}
              placeholder="Terms & Conditions"
            />
          </div>
        </Card>

        <Card title="PAYMENT DETAILS">
          <div className="space-y-4">
            <Input
              label="Bank Name"
              value={formData.bankName}
              onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
            />
            <Input
              label="Account Number"
              value={formData.accountNumber}
              onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
            />
            <Input
              label="IFSC Code"
              value={formData.ifscCode}
              onChange={(e) => setFormData({ ...formData, ifscCode: e.target.value })}
            />
            <Input
              label="UPI ID"
              value={formData.upiId}
              onChange={(e) => setFormData({ ...formData, upiId: e.target.value })}
            />
          </div>
        </Card>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button variant="primary" onClick={handleSave} loading={loading} fullWidth>
            Save All Settings
          </Button>
          <Button variant="outline" icon={<Eye size={16} />} fullWidth onClick={handlePreviewInvoice}>
            Preview Invoice
          </Button>
        </div>
      </div>
    </PageContainer>
  );
};

export default BusinessProfile;

