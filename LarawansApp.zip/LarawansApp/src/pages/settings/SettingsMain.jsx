import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User,
  Users,
  Building2,
  Settings as SettingsIcon,
  Database,
  Palette,
  Bell,
  Calendar,
  LogOut,
  Trash2,
  Lock,
  HelpCircle,
  FileText,
  Mail,
  Shield,
  ChevronRight,
  Moon,
  Sun,
} from 'lucide-react';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import Toggle from '../../components/ui/Toggle';
import Button from '../../components/ui/Button';
import Avatar from '../../components/ui/Avatar';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import { getUserSettings } from '../../services/settingsService';

const SettingsMain = () => {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const { user, logout } = useAuth();
  const { success, showError } = useToast();
  const [userSettings, setUserSettings] = useState(null);
  const [notifications, setNotifications] = useState({
    followUpReminders: true,
    paymentReceived: true,
    teamUpdates: true,
    dailySummary: true,
  });
  const [preferences, setPreferences] = useState({
    dateFormat: 'DD/MM/YYYY',
    currency: '₹ INR',
    defaultFollowUp: '3',
  });
  const [defaultView, setDefaultView] = useState('cards');
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (user) {
      loadUserSettings();
    }
  }, [user]);

  const loadUserSettings = async () => {
    try {
      const settings = await getUserSettings(user.uid);
      if (settings) {
        setUserSettings(settings);
        setIsAdmin(settings.role === 'admin' || settings.role === 'owner');
        if (settings.notifications) setNotifications(settings.notifications);
        if (settings.preferences) setPreferences(settings.preferences);
        if (settings.defaultView) setDefaultView(settings.defaultView);
      }
      // If no settings found, that's okay - user just hasn't set preferences yet
    } catch (error) {
      // Error is already handled in getUserSettings, just log for debugging
      console.warn('Settings not available:', error.message);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      success('Logged out successfully');
      navigate('/login');
    } catch (error) {
      showError('Failed to logout');
    }
  };

  const handleDeleteAccount = () => {
    if (window.confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      showError('Account deletion is not yet implemented. Please contact support.');
    }
  };

  const SettingSection = ({ icon: Icon, title, children, className = '' }) => (
    <div className={`space-y-3 ${className}`}>
      <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
        {Icon && <Icon size={18} />}
        <h3 className="font-semibold text-sm sm:text-base">{title}</h3>
      </div>
      {children}
    </div>
  );

  const SettingItem = ({ label, value, onClick, icon: Icon, action }) => (
    <div
      onClick={onClick}
      className={`flex items-center justify-between p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 ${
        onClick ? 'cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors' : ''
      }`}
    >
      <div className="flex items-center gap-3 flex-1">
        {Icon && <Icon size={18} className="text-gray-500 dark:text-gray-400" />}
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-900 dark:text-white">{label}</p>
          {value && <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{value}</p>}
        </div>
      </div>
      {action || (onClick && <ChevronRight size={18} className="text-gray-400" />)}
    </div>
  );

  return (
    <PageContainer title="Settings" subtitle="Manage your account and preferences">
      <div className="max-w-4xl mx-auto space-y-4 sm:space-y-6">
        {/* Profile Section */}
        <Card>
          <SettingSection icon={User} title="PROFILE">
            <div className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
              <Avatar
                name={user?.displayName || user?.email || 'User'}
                size="lg"
                src={user?.photoURL}
              />
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-gray-900 dark:text-white truncate">
                  {user?.displayName || 'Your Name'}
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
                  {user?.email}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                  {user?.phoneNumber || '+91-9876543210'}
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/settings/profile')}
              >
                View Profile
              </Button>
            </div>
          </SettingSection>
        </Card>

        {/* General Settings */}
        <Card>
          <SettingSection icon={SettingsIcon} title="GENERAL SETTINGS">
            <div className="space-y-3">
              {/* Appearance */}
              <div className="p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Palette size={16} className="text-gray-500 dark:text-gray-400" />
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      Appearance
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-2">
                    <Moon size={16} className="text-gray-400" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">Dark</span>
                  </div>
                  <div className="flex-1 mx-4">
                    <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                      <div
                        className={`absolute top-0 left-0 h-2 rounded-full transition-all duration-300 ${
                          theme === 'dark' ? 'w-full bg-primary-600' : 'w-0'
                        }`}
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Sun size={16} className="text-gray-400" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">Light</span>
                  </div>
                </div>
                <div className="mt-3 flex justify-center">
                  <Toggle
                    checked={theme === 'dark'}
                    onChange={toggleTheme}
                    size="md"
                  />
                </div>
              </div>

              {/* Default View */}
              <div className="p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
                <div className="flex items-center gap-2 mb-3">
                  <SettingsIcon size={16} className="text-gray-500 dark:text-gray-400" />
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    Default View
                  </span>
                </div>
                <div className="flex gap-2">
                  {['cards', 'table', 'list'].map((view) => (
                    <button
                      key={view}
                      onClick={() => setDefaultView(view)}
                      className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                        defaultView === view
                          ? 'bg-primary-600 text-white'
                          : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700'
                      }`}
                    >
                      {view.charAt(0).toUpperCase() + view.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Notifications */}
              <div className="p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
                <div className="flex items-center gap-2 mb-3">
                  <Bell size={16} className="text-gray-500 dark:text-gray-400" />
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    Notifications
                  </span>
                </div>
                <div className="space-y-3">
                  {[
                    { key: 'followUpReminders', label: 'Follow-up reminders' },
                    { key: 'paymentReceived', label: 'Payment received' },
                    { key: 'teamUpdates', label: 'Team updates' },
                    { key: 'dailySummary', label: 'Daily summary' },
                  ].map(({ key, label }) => (
                    <div key={key} className="flex items-center justify-between">
                      <span className="text-sm text-gray-700 dark:text-gray-300">{label}</span>
                      <Toggle
                        checked={notifications[key]}
                        onChange={(e) =>
                          setNotifications({ ...notifications, [key]: e.target.checked })
                        }
                        size="sm"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Preferences */}
              <div className="p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
                <div className="flex items-center gap-2 mb-3">
                  <Calendar size={16} className="text-gray-500 dark:text-gray-400" />
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    Preferences
                  </span>
                </div>
                <div className="space-y-2">
                  <div
                    onClick={() => navigate('/settings/preferences')}
                    className="cursor-pointer p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        Manage Preferences
                      </span>
                      <ChevronRight size={18} className="text-gray-400" />
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      Date: {preferences.dateFormat} • Currency: {preferences.currency} • Follow-up: {preferences.defaultFollowUp} days
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </SettingSection>
        </Card>

        {/* Team Management (Admin Only) */}
        {isAdmin && (
          <Card>
            <SettingSection icon={Users} title="TEAM (Admin Only)">
              <SettingItem
                label="Team Members"
                value="2/3 used"
                onClick={() => navigate('/settings/team')}
                icon={Users}
              />
            </SettingSection>
          </Card>
        )}

        {/* Business Profile */}
        <Card>
          <SettingSection icon={Building2} title="BUSINESS PROFILE">
            <SettingItem
              label="Business Details"
              value="Edit company information"
              onClick={() => navigate('/settings/business')}
              icon={Building2}
            />
          </SettingSection>
        </Card>

        {/* Admin Panel (Super Admin Only) */}
        {isAdmin && (
          <Card>
            <SettingSection icon={Shield} title="ADMIN PANEL (Super Admin)">
              <SettingItem
                label="Advanced Configuration"
                value="Customize app settings"
                onClick={() => navigate('/settings/admin')}
                icon={SettingsIcon}
              />
            </SettingSection>
          </Card>
        )}

        {/* Account Actions */}
        <Card>
          <SettingSection icon={Lock} title="ACCOUNT">
            <div className="space-y-2">
              <SettingItem
                label="Change Password"
                onClick={() => navigate('/settings/password')}
                icon={Lock}
              />
              <SettingItem
                label="Logout"
                onClick={handleLogout}
                icon={LogOut}
                action={
                  <Button variant="outline" size="sm" onClick={handleLogout}>
                    <LogOut size={16} className="mr-2" />
                    Logout
                  </Button>
                }
              />
              <div className="pt-2 border-t border-red-200 dark:border-red-900">
                <SettingItem
                  label="Delete Account"
                  value="Permanently delete your account"
                  onClick={handleDeleteAccount}
                  icon={Trash2}
                  action={
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDeleteAccount}
                      className="border-red-500 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
                    >
                      <Trash2 size={16} className="mr-2" />
                      Delete
                    </Button>
                  }
                />
              </div>
            </div>
          </SettingSection>
        </Card>
      </div>
    </PageContainer>
  );
};

export default SettingsMain;

