import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Database,
  Download,
  Upload,
  Trash2,
  RefreshCw,
  FileText,
  AlertTriangle,
} from 'lucide-react';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import { useToast } from '../../hooks/useToast';
import { getAllLeads } from '../../services/leadsService';
import { getAllDeals } from '../../services/dealsService';
import { useAuth } from '../../context/AuthContext';

const DataManagement = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { success, showError } = useToast();
  const [loading, setLoading] = useState(false);
  const [exportDateRange, setExportDateRange] = useState({
    from: '',
    to: '',
  });

  // Convert data to CSV format
  const convertToCSV = (data, headers) => {
    const csvRows = [];
    // Add headers
    csvRows.push(headers.join(','));
    // Add data rows
    data.forEach((row) => {
      const values = headers.map((header) => {
        const value = row[header] || '';
        // Escape commas and quotes in values
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      });
      csvRows.push(values.join(','));
    });
    return csvRows.join('\n');
  };

  // Download CSV file
  const downloadCSV = (csvContent, filename) => {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExport = async (type) => {
    setLoading(true);
    try {
      let data = [];
      let filename = '';
      let headers = [];

      if (type === 'Leads') {
        const leads = await getAllLeads();
        // Filter by date range if provided
        let filteredLeads = leads;
        if (exportDateRange.from && exportDateRange.to) {
          const fromDate = new Date(exportDateRange.from);
          const toDate = new Date(exportDateRange.to);
          toDate.setHours(23, 59, 59, 999);
          filteredLeads = leads.filter((lead) => {
            const leadDate = lead.createdAt?.toDate?.() || new Date(lead.createdAt);
            return leadDate >= fromDate && leadDate <= toDate;
          });
        }
        data = filteredLeads.map((lead) => ({
          name: lead.name || '',
          phone: lead.phone || '',
          email: lead.email || '',
          source: lead.source || '',
          status: lead.status || '',
          notes: lead.notes || '',
          createdAt: lead.createdAt?.toDate?.()?.toLocaleString() || lead.createdAt || '',
        }));
        headers = ['name', 'phone', 'email', 'source', 'status', 'notes', 'createdAt'];
        filename = `leads_export_${new Date().toISOString().split('T')[0]}.csv`;
      } else if (type === 'Deals') {
        const deals = await getAllDeals();
        // Filter by date range if provided
        let filteredDeals = deals;
        if (exportDateRange.from && exportDateRange.to) {
          const fromDate = new Date(exportDateRange.from);
          const toDate = new Date(exportDateRange.to);
          toDate.setHours(23, 59, 59, 999);
          filteredDeals = deals.filter((deal) => {
            const dealDate = deal.createdAt?.toDate?.() || new Date(deal.createdAt);
            return dealDate >= fromDate && dealDate <= toDate;
          });
        }
        data = filteredDeals.map((deal) => ({
          dealId: deal.dealId || deal.id || '',
          customerName: deal.customerName || '',
          customerPhone: deal.customerPhone || '',
          customerEmail: deal.customerEmail || '',
          services: deal.services?.join('; ') || '',
          totalAmount: deal.totalAmount || 0,
          paidAmount: deal.paidAmount || 0,
          pendingAmount: deal.pendingAmount || 0,
          status: deal.status || '',
          createdAt: deal.createdAt?.toDate?.()?.toLocaleString() || deal.createdAt || '',
        }));
        headers = [
          'dealId',
          'customerName',
          'customerPhone',
          'customerEmail',
          'services',
          'totalAmount',
          'paidAmount',
          'pendingAmount',
          'status',
          'createdAt',
        ];
        filename = `deals_export_${new Date().toISOString().split('T')[0]}.csv`;
      } else if (type === 'Payments') {
        const deals = await getAllDeals();
        const payments = [];
        deals.forEach((deal) => {
          if (deal.paymentHistory && deal.paymentHistory.length > 0) {
            deal.paymentHistory.forEach((payment) => {
              payments.push({
                dealId: deal.dealId || deal.id || '',
                customerName: deal.customerName || '',
                amount: payment.amount || 0,
                paymentDate: payment.date?.toDate?.()?.toLocaleString() || payment.date || '',
                paymentMethod: payment.method || '',
                notes: payment.notes || '',
              });
            });
          }
        });
        // Filter by date range if provided
        let filteredPayments = payments;
        if (exportDateRange.from && exportDateRange.to) {
          const fromDate = new Date(exportDateRange.from);
          const toDate = new Date(exportDateRange.to);
          toDate.setHours(23, 59, 59, 999);
          filteredPayments = payments.filter((payment) => {
            const paymentDate = payment.paymentDate
              ? new Date(payment.paymentDate)
              : new Date();
            return paymentDate >= fromDate && paymentDate <= toDate;
          });
        }
        data = filteredPayments;
        headers = ['dealId', 'customerName', 'amount', 'paymentDate', 'paymentMethod', 'notes'];
        filename = `payments_export_${new Date().toISOString().split('T')[0]}.csv`;
      } else if (type === 'Everything') {
        // Export everything as ZIP (for now, just export all separately)
        await handleExport('Leads');
        await new Promise((resolve) => setTimeout(resolve, 500));
        await handleExport('Deals');
        await new Promise((resolve) => setTimeout(resolve, 500));
        await handleExport('Payments');
        success('All data exported successfully!');
        setLoading(false);
        return;
      }

      if (data.length === 0) {
        showError(`No ${type.toLowerCase()} found to export`);
        setLoading(false);
        return;
      }

      const csvContent = convertToCSV(data, headers);
      downloadCSV(csvContent, filename);
      success(`${type} exported successfully! (${data.length} records)`);
    } catch (error) {
      console.error('Error exporting data:', error);
      showError(`Failed to export ${type}. Please try again.`);
    } finally {
      setLoading(false);
    }
  };

  const handleBackup = async () => {
    setLoading(true);
    try {
      // Export all data as backup
      await handleExport('Leads');
      await new Promise((resolve) => setTimeout(resolve, 500));
      await handleExport('Deals');
      await new Promise((resolve) => setTimeout(resolve, 500));
      await handleExport('Payments');
      success('Backup created successfully! All files downloaded.');
    } catch (error) {
      console.error('Error creating backup:', error);
      showError('Failed to create backup. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleImport = () => {
    // Redirect to leads page where CSV import is available
    navigate('/leads');
    success('Navigate to Leads page to use CSV import feature');
  };

  const handleDelete = (type) => {
    const confirmText = type === 'all' ? 'DELETE' : 'DELETE ALL';
    const input = window.prompt(
      `⚠️ This action is PERMANENT and CANNOT be undone!\n\nTo confirm, type: ${confirmText}`
    );
    if (input === confirmText) {
      // TODO: Implement delete logic
      showError('Delete functionality not yet implemented');
    }
  };

  return (
    <PageContainer>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/settings')}
            icon={ArrowLeft}
          >
            Back
          </Button>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Data Management</h1>
        </div>

        <Card title="BACKUP & RESTORE">
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                Last Backup: 29 Nov 2024, 10:30 AM
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                Size: 2.5 MB • Status: ✅ Successful
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Auto-backup: ✓ Enabled • Frequency: Daily at 2:00 AM
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="primary"
                icon={RefreshCw}
                onClick={handleBackup}
                loading={loading}
                disabled={loading}
              >
                Backup Now
              </Button>
            </div>
          </div>
        </Card>

        <Card title="EXPORT DATA">
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="From Date"
                type="date"
                value={exportDateRange.from}
                onChange={(e) =>
                  setExportDateRange({ ...exportDateRange, from: e.target.value })
                }
              />
              <Input
                label="To Date"
                type="date"
                value={exportDateRange.to}
                onChange={(e) =>
                  setExportDateRange({ ...exportDateRange, to: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Button
                variant="outline"
                icon={FileText}
                fullWidth
                onClick={() => handleExport('Leads')}
                loading={loading}
                disabled={loading}
              >
                Export All Leads (CSV)
              </Button>
              <Button
                variant="outline"
                icon={FileText}
                fullWidth
                onClick={() => handleExport('Deals')}
                loading={loading}
                disabled={loading}
              >
                Export All Deals (CSV)
              </Button>
              <Button
                variant="outline"
                icon={FileText}
                fullWidth
                onClick={() => handleExport('Payments')}
                loading={loading}
                disabled={loading}
              >
                Export Payments (CSV)
              </Button>
              <Button
                variant="outline"
                icon={Download}
                fullWidth
                onClick={() => handleExport('Everything')}
                loading={loading}
                disabled={loading}
              >
                Export Everything (All Files)
              </Button>
            </div>
          </div>
        </Card>

        <Card title="IMPORT DATA">
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
              <Upload size={24} className="mx-auto text-gray-400 mb-2" />
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                Choose File to Upload
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-500 mb-4">
                Supported: Excel (.xlsx, .xls) • CSV (.csv)
              </p>
              <Button variant="outline" icon={Upload} onClick={handleImport} disabled={loading}>
                Select File
              </Button>
            </div>
            <Button variant="outline" icon={Download} fullWidth>
              Download Sample Template
            </Button>
          </div>
        </Card>

        <Card title="DATA STATISTICS">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Total Database Size:</span>
              <span className="font-medium text-gray-900 dark:text-white">2.5 MB</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Leads:</span>
              <span className="font-medium text-gray-900 dark:text-white">52 records (1.2 MB)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Deals:</span>
              <span className="font-medium text-gray-900 dark:text-white">23 records (0.8 MB)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Payments:</span>
              <span className="font-medium text-gray-900 dark:text-white">
                45 records (0.3 MB)
              </span>
            </div>
          </div>
        </Card>

        <Card
          title="DANGER ZONE"
          className="border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-900/10"
        >
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-red-600 dark:text-red-400 mb-4">
              <AlertTriangle size={18} />
              <p className="text-sm font-medium">
                These actions are PERMANENT and CANNOT be undone!
              </p>
            </div>
            <div className="space-y-2">
              <Button
                variant="outline"
                icon={Trash2}
                fullWidth
                onClick={() => handleDelete('leads')}
                className="border-red-500 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
              >
                Delete All Leads
              </Button>
              <Button
                variant="outline"
                icon={Trash2}
                fullWidth
                onClick={() => handleDelete('deals')}
                className="border-red-500 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
              >
                Delete All Deals
              </Button>
              <Button
                variant="outline"
                icon={Trash2}
                fullWidth
                onClick={() => handleDelete('all')}
                className="border-red-500 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
              >
                Clear All Data
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </PageContainer>
  );
};

export default DataManagement;

