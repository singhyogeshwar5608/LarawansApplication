import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Calendar, DollarSign, Clock } from 'lucide-react';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Select from '../../components/ui/Select';
import Input from '../../components/ui/Input';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import { getUserSettings, updateUserSettings } from '../../services/settingsService';

const Preferences = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { success, showError } = useToast();
  const [loading, setLoading] = useState(false);
  const [preferences, setPreferences] = useState({
    dateFormat: 'DD/MM/YYYY',
    currency: '₹ INR',
    defaultFollowUp: '3',
    timeFormat: '12',
    defaultView: 'cards',
  });

  useEffect(() => {
    if (user) {
      loadPreferences();
    }
  }, [user]);

  const loadPreferences = async () => {
    try {
      const settings = await getUserSettings(user.uid);
      if (settings?.preferences) {
        setPreferences(settings.preferences);
      }
      // If no settings found, that's okay - use defaults
    } catch (error) {
      console.error('Error loading preferences:', error);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      await updateUserSettings(user.uid, { preferences });
      success('Preferences saved successfully!');
      navigate('/settings');
    } catch (error) {
      console.error('Error saving preferences:', error);
      showError('Failed to save preferences');
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageContainer>
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/settings')}
              icon={ArrowLeft}
            >
              Back
            </Button>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Preferences</h1>
          </div>
          <Button variant="primary" onClick={handleSave} loading={loading}>
            Save
          </Button>
        </div>

        <Card title="DATE & TIME">
          <div className="space-y-4">
            <Select
              label="Date Format"
              value={preferences.dateFormat}
              onChange={(e) => setPreferences({ ...preferences, dateFormat: e.target.value })}
              options={[
                { value: 'DD/MM/YYYY', label: 'DD/MM/YYYY' },
                { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY' },
                { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD' },
              ]}
              icon={Calendar}
            />
            <Select
              label="Time Format"
              value={preferences.timeFormat}
              onChange={(e) => setPreferences({ ...preferences, timeFormat: e.target.value })}
              options={[
                { value: '12', label: '12 Hour (2:30 PM)' },
                { value: '24', label: '24 Hour (14:30)' },
              ]}
              icon={Clock}
            />
          </div>
        </Card>

        <Card title="CURRENCY & FORMATTING">
          <div className="space-y-4">
            <Select
              label="Currency Symbol"
              value={preferences.currency}
              onChange={(e) => setPreferences({ ...preferences, currency: e.target.value })}
              options={[
                { value: '₹ INR', label: '₹ INR' },
                { value: '$ USD', label: '$ USD' },
                { value: '€ EUR', label: '€ EUR' },
              ]}
              icon={DollarSign}
            />
          </div>
        </Card>

        <Card title="DEFAULT SETTINGS">
          <div className="space-y-4">
            <Input
              label="Default Follow-up Duration (days)"
              type="number"
              value={preferences.defaultFollowUp}
              onChange={(e) => setPreferences({ ...preferences, defaultFollowUp: e.target.value })}
              helperText="Default number of days for follow-up reminders"
            />
            <Select
              label="Default View Mode"
              value={preferences.defaultView}
              onChange={(e) => setPreferences({ ...preferences, defaultView: e.target.value })}
              options={[
                { value: 'cards', label: 'Cards (Mobile-friendly)' },
                { value: 'table', label: 'Table (Desktop-friendly)' },
                { value: 'list', label: 'List (Compact)' },
              ]}
            />
          </div>
        </Card>
      </div>
    </PageContainer>
  );
};

export default Preferences;

