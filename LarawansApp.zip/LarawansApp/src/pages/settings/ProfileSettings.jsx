import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Camera,
  User,
  Mail,
  Phone,
  Briefcase,
  Calendar,
  Facebook,
  Instagram,
  Youtube,
  Globe,
  Linkedin,
  Plus,
  Edit2,
  Trash2,
  Eye,
  Upload,
  X,
  FileText,
} from 'lucide-react';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import Avatar from '../../components/ui/Avatar';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../hooks/useToast';
import { getUserSettings, updateUserSettings } from '../../services/settingsService';

const ProfileSettings = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { success, showError } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    role: '',
    memberSince: '',
  });
  const [portfolioLinks, setPortfolioLinks] = useState([]);
  const [workSamples, setWorkSamples] = useState([]);
  const [showAddLinkModal, setShowAddLinkModal] = useState(false);
  const [newLink, setNewLink] = useState({ type: '', url: '', label: '' });

  useEffect(() => {
    if (user) {
      loadProfile();
    }
  }, [user]);

  const loadProfile = async () => {
    try {
      const settings = await getUserSettings(user.uid);
      if (settings) {
        setFormData({
          name: settings.name || user.displayName || '',
          email: user.email || '',
          phone: settings.phone || '',
          role: settings.role || 'Team Member',
          memberSince: settings.memberSince || new Date().toLocaleDateString(),
        });
        setPortfolioLinks(settings.portfolioLinks || []);
        setWorkSamples(settings.workSamples || []);
      } else {
        // No settings found - use defaults from user object
        setFormData({
          name: user.displayName || '',
          email: user.email || '',
          phone: '',
          role: 'Team Member',
          memberSince: new Date().toLocaleDateString(),
        });
      }
      // If getUserSettings returns null due to permissions, that's okay
    } catch (error) {
      // Error is already handled in getUserSettings
      console.warn('Profile settings not available:', error.message);
      // Use defaults from user object
      setFormData({
        name: user.displayName || '',
        email: user.email || '',
        phone: '',
        role: 'Team Member',
        memberSince: new Date().toLocaleDateString(),
      });
    }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      await updateUserSettings(user.uid, {
        name: formData.name,
        phone: formData.phone,
        portfolioLinks,
        workSamples,
      });
      success('Profile updated successfully!');
      navigate('/settings');
    } catch (error) {
      console.error('Error saving profile:', error);
      showError('Failed to save profile');
    } finally {
      setLoading(false);
    }
  };

  const handleAddLink = () => {
    if (!newLink.type || !newLink.url) {
      showError('Please fill in all required fields');
      return;
    }
    setPortfolioLinks([...portfolioLinks, { ...newLink, id: Date.now() }]);
    setNewLink({ type: '', url: '', label: '' });
    setShowAddLinkModal(false);
    success('Link added successfully');
  };

  const handleDeleteLink = (id) => {
    setPortfolioLinks(portfolioLinks.filter((link) => link.id !== id));
    success('Link removed');
  };

  const handleDeleteSample = (id) => {
    setWorkSamples(workSamples.filter((sample) => sample.id !== id));
    success('Work sample removed');
  };

  const linkTypes = [
    { value: 'facebook', label: 'Facebook Profile/Page', icon: Facebook },
    { value: 'instagram', label: 'Instagram Account', icon: Instagram },
    { value: 'youtube', label: 'YouTube Channel', icon: Youtube },
    { value: 'website', label: 'Website', icon: Globe },
    { value: 'linkedin', label: 'LinkedIn Profile', icon: Linkedin },
    { value: 'other', label: 'Other Link', icon: Globe },
  ];

  return (
    <PageContainer>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/settings')}
            icon={ArrowLeft}
          >
            Back
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Your Profile</h1>
          </div>
          <Button variant="primary" onClick={handleSave} loading={loading}>
            Save Changes
          </Button>
        </div>

        {/* Avatar Section */}
        <Card>
          <div className="text-center">
            <div className="inline-block relative">
              <Avatar
                name={formData.name || user?.email}
                size="2xl"
                src={user?.photoURL}
              />
              <button className="absolute bottom-0 right-0 p-2 bg-primary-600 text-white rounded-full hover:bg-primary-700 transition-colors">
                <Camera size={16} />
              </button>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
              150x150px, max 2MB
            </p>
          </div>
        </Card>

        {/* Basic Information */}
        <Card title="BASIC INFORMATION">
          <div className="space-y-4">
            <Input
              label="Full Name *"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              icon={User}
            />
            <Input
              label="Email *"
              value={formData.email}
              disabled
              icon={Mail}
              helperText="Used for login"
            />
            <Input
              label="Phone *"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              icon={Phone}
            />
            <Input
              label="Role"
              value={formData.role}
              disabled
              icon={Briefcase}
              helperText="Display only, set by owner"
            />
            <Input
              label="Member Since"
              value={formData.memberSince}
              disabled
              icon={Calendar}
            />
          </div>
        </Card>

        {/* Portfolio Links */}
        <Card title="PORTFOLIO LINKS" subtitle="Share these with customers">
          <div className="space-y-4">
            {linkTypes.map((type) => {
              const links = portfolioLinks.filter((l) => l.type === type.value);
              return (
                <div key={type.value} className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                    {<type.icon size={16} />}
                    <span>{type.label}</span>
                  </div>
                  {links.map((link) => (
                    <div
                      key={link.id}
                      className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                          {link.label || link.url}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                          {link.url}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" icon={Edit2}>
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          icon={Trash2}
                          onClick={() => handleDeleteLink(link.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          Delete
                        </Button>
                      </div>
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    icon={Plus}
                    onClick={() => {
                      setNewLink({ type: type.value, url: '', label: '' });
                      setShowAddLinkModal(true);
                    }}
                    fullWidth
                  >
                    Add {type.label}
                  </Button>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Work Samples */}
        <Card title="WORK SAMPLES" subtitle="Upload portfolio images/videos">
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
              <Upload size={24} className="mx-auto text-gray-400 mb-2" />
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                Upload Files
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                Supported: JPG, PNG, PDF, MP4 • Max 5MB per file
              </p>
            </div>
            {workSamples.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Uploaded Samples ({workSamples.length}):
                </p>
                {workSamples.map((sample) => (
                  <div
                    key={sample.id}
                    className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                        <FileText size={16} className="text-gray-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900 dark:text-white">
                          {sample.name}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {sample.size}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" icon={Eye}>
                        Preview
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        icon={Trash2}
                        onClick={() => handleDeleteSample(sample.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>

        {/* Add Link Modal */}
        {showAddLinkModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Add {linkTypes.find((t) => t.value === newLink.type)?.label}
                </h3>
                <button
                  onClick={() => setShowAddLinkModal(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X size={20} />
                </button>
              </div>
              <div className="space-y-4">
                <Input
                  label="URL/Username *"
                  value={newLink.url}
                  onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                  placeholder="URL or Username"
                />
                <Input
                  label="Display Label"
                  value={newLink.label}
                  onChange={(e) => setNewLink({ ...newLink, label: e.target.value })}
                  placeholder="Display Label"
                />
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    fullWidth
                    onClick={() => setShowAddLinkModal(false)}
                  >
                    Cancel
                  </Button>
                  <Button variant="primary" fullWidth onClick={handleAddLink}>
                    Add Link
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </PageContainer>
  );
};

export default ProfileSettings;

