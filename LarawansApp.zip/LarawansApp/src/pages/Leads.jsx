import { useState, useEffect } from 'react';
import { Filter, Download, Search, Plus, Trash2, CheckSquare, Square, Phone, Calendar, Edit, Eye } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import PageContainer from '../components/layout/PageContainer';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import Checkbox from '../components/ui/Checkbox';
import Modal from '../components/ui/Modal';
import FloatingActionButton from '../components/layout/FloatingActionButton';
import LeadCard from '../components/leads/LeadCard';
import EmptyState from '../components/ui/EmptyState';
import ImportCSV from '../components/leads/ImportCSV';
import { subscribeToLeads, deleteLead } from '../services/leadsService';
import { useToast } from '../hooks/useToast';

const Leads = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { success, error: showError } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedLeads, setSelectedLeads] = useState(new Set());
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Read status from URL query params
  useEffect(() => {
    const statusFromUrl = searchParams.get('status');
    if (statusFromUrl) {
      setStatusFilter(statusFromUrl);
    }
  }, [searchParams]);

  // Fetch leads from Firebase with real-time updates
  useEffect(() => {
    // For "active" status, we need to fetch all leads and filter client-side
    // since Firestore doesn't support OR queries easily
    const filters = statusFilter && statusFilter !== 'active' ? { status: statusFilter } : {};
    
    const unsubscribe = subscribeToLeads(
      (leadsData) => {
        // Convert Firestore timestamps to ISO strings for compatibility
        let processedLeads = leadsData.map(lead => ({
          ...lead,
          createdAt: lead.createdAt?.toDate?.()?.toISOString() || lead.createdAt || new Date().toISOString(),
          updatedAt: lead.updatedAt?.toDate?.()?.toISOString() || lead.updatedAt || new Date().toISOString(),
        }));

        // Filter for "active" status (interested or scheduled) if needed
        if (statusFilter === 'active') {
          processedLeads = processedLeads.filter(lead => 
            lead.status === 'interested' || lead.status === 'scheduled'
          );
        }

        setLeads(processedLeads);
        setLoading(false);
      },
      filters
    );

    return () => unsubscribe();
  }, [statusFilter]);

  const statusOptions = [
    { value: '', label: 'All Status' },
    { value: 'new', label: 'New' },
    { value: 'active', label: 'Active' },
    { value: 'interested', label: 'Interested' },
    { value: 'scheduled', label: 'Scheduled' },
    { value: 'converted', label: 'Converted' },
    { value: 'rejected', label: 'Rejected' },
    { value: 'followup', label: 'Follow-up Pending' },
  ];

  // Filter leads (client-side search and status)
  const filteredLeads = leads.filter((lead) => {
    const matchesSearch = 
      lead.phone?.includes(searchTerm) || 
      (lead.name && lead.name.toLowerCase().includes(searchTerm.toLowerCase()));
    
    // Filter by follow-up pending if selected
    if (statusFilter === 'followup') {
      return matchesSearch && lead.nextFollowUp;
    }
    
    return matchesSearch;
  });

  // Sort by follow-up date if needed
  const sortedLeads = [...filteredLeads].sort((a, b) => {
    if (statusFilter === 'followup') {
      const dateA = a.nextFollowUp?.toDate ? a.nextFollowUp.toDate() : new Date(a.nextFollowUp || 0);
      const dateB = b.nextFollowUp?.toDate ? b.nextFollowUp.toDate() : new Date(b.nextFollowUp || 0);
      return dateA.getTime() - dateB.getTime();
    }
    return 0;
  });

  // Count new leads
  const newLeadsCount = leads.filter(l => l.status === 'new').length;

  // Handle import completion - refresh leads list
  const handleImportComplete = () => {
    // The leads list will automatically refresh via the real-time subscription
    // This function is here for potential future use
  };

  // Selection handlers
  const handleSelectLead = (leadId) => {
    const newSelected = new Set(selectedLeads);
    if (newSelected.has(leadId)) {
      newSelected.delete(leadId);
    } else {
      newSelected.add(leadId);
    }
    setSelectedLeads(newSelected);
  };

  const handleSelectAll = () => {
    if (selectedLeads.size === sortedLeads.length) {
      setSelectedLeads(new Set());
    } else {
      setSelectedLeads(new Set(sortedLeads.map(lead => lead.id)));
    }
  };

  const handleBulkDelete = async () => {
    if (selectedLeads.size === 0) return;
    
    setIsDeleting(true);
    try {
      const deletePromises = Array.from(selectedLeads).map(leadId => deleteLead(leadId));
      await Promise.all(deletePromises);
      success(`Successfully deleted ${selectedLeads.size} lead${selectedLeads.size > 1 ? 's' : ''}`);
      setSelectedLeads(new Set());
      setShowDeleteModal(false);
    } catch (error) {
      console.error('Error deleting leads:', error);
      showError('Failed to delete some leads. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <>
      <PageContainer
        title="Leads"
        subtitle={`${leads.length} total leads • ${newLeadsCount} new`}
        actions={
          <div className="flex gap-2 w-full sm:w-auto">
            <ImportCSV onImportComplete={handleImportComplete} />
            <Button 
              variant="outline" 
              size="sm"
              icon={<Download size={16} />}
              className="flex-1 sm:flex-none"
            >
              <span className="hidden sm:inline">Export</span>
              <span className="sm:hidden">📥</span>
            </Button>
            <Button 
              variant="primary" 
              size="sm"
              onClick={() => navigate('/leads/new')}
              className="flex-1 sm:flex-none"
            >
              <span className="hidden sm:inline">Add Lead</span>
              <span className="sm:hidden">+ Add</span>
            </Button>
          </div>
        }
      >
        {/* Selection Bar */}
        {selectedLeads.size > 0 && (
          <Card className="mb-4 bg-blue-50 dark:bg-blue-900/20 border-2 border-blue-200 dark:border-blue-800">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <Checkbox
                  checked={selectedLeads.size === sortedLeads.length && sortedLeads.length > 0}
                  onChange={handleSelectAll}
                  label={`${selectedLeads.size} selected`}
                />
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="danger"
                  size="sm"
                  icon={<Trash2 size={16} />}
                  onClick={() => setShowDeleteModal(true)}
                >
                  Delete ({selectedLeads.size})
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedLeads(new Set())}
                >
                  Clear
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Filters */}
        <Card className="mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              placeholder="Search by phone or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              icon={<Search size={18} />}
            />
            <Select
              placeholder="Filter by status"
              options={statusOptions}
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            />
            <Button variant="outline" icon={<Filter size={16} />} fullWidth>
              More Filters
            </Button>
          </div>
        </Card>

        {/* New Leads Alert */}
        {newLeadsCount > 0 && !statusFilter && (
          <div className="mb-4 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-900/30 rounded-lg animate-slide-down">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-900 dark:text-green-100 font-semibold">
                  {newLeadsCount} New Lead{newLeadsCount > 1 ? 's' : ''} Waiting
                </p>
                <p className="text-sm text-green-700 dark:text-green-300">
                  Tap on each lead to update status and add details
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setStatusFilter('new')}
                className="border-green-300 text-green-700 hover:bg-green-100 dark:border-green-700 dark:text-green-300 dark:hover:bg-green-900/30"
              >
                View All
              </Button>
            </div>
          </div>
        )}

        {/* Leads List */}
        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Loading leads...</div>
          </div>
        ) : sortedLeads.length === 0 ? (
          <EmptyState
            title="No leads found"
            description={searchTerm || statusFilter ? "Try adjusting your filters" : "Add your first lead to get started"}
            actionLabel="Add Lead"
            onAction={() => navigate('/leads/new')}
          />
        ) : (
          <>
            {/* Desktop Table View */}
            <div className="hidden lg:block">
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-900">
                    <tr>
                      <th className="px-4 py-3 text-left">
                        <Checkbox
                          checked={selectedLeads.size === sortedLeads.length && sortedLeads.length > 0}
                          onChange={handleSelectAll}
                        />
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Phone</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Name</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Call Status</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Date Added</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {sortedLeads.map((lead) => (
                      <tr 
                        key={lead.id} 
                        className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors cursor-pointer"
                        onClick={() => navigate(`/leads/${lead.id}`)}
                      >
                        <td className="px-4 py-4" onClick={(e) => e.stopPropagation()}>
                          <Checkbox
                            checked={selectedLeads.has(lead.id)}
                            onChange={() => handleSelectLead(lead.id)}
                          />
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <Phone size={16} className="text-gray-400" />
                            <span className="text-sm font-medium text-gray-900 dark:text-white">{lead.phone}</span>
                          </div>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className="text-sm text-gray-900 dark:text-white">{lead.name || '-'}</span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <Badge status={lead.status || 'new'} size="sm" />
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className="text-sm text-gray-600 dark:text-gray-400">{lead.callStatus || '-'}</span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-1 text-sm text-gray-500 dark:text-gray-400">
                            <Calendar size={14} />
                            <span>{new Date(lead.createdAt).toLocaleDateString('en-IN')}</span>
                          </div>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => navigate(`/leads/${lead.id}`)}
                              className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                              title="View"
                            >
                              <Eye size={16} />
                            </button>
                            <button
                              onClick={() => navigate(`/leads/${lead.id}/edit`)}
                              className="p-2 text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                              title="Edit"
                            >
                              <Edit size={16} />
                            </button>
                            <button
                              onClick={() => window.location.href = `tel:${lead.phone.replace(/\D/g, '')}`}
                              className="p-2 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                              title="Call"
                            >
                              <Phone size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Mobile Card View */}
            <div className="lg:hidden">
              {sortedLeads.length > 0 && (
                <div className="mb-3 flex items-center gap-2">
                  <Checkbox
                    checked={selectedLeads.size === sortedLeads.length && sortedLeads.length > 0}
                    onChange={handleSelectAll}
                    label="Select All"
                  />
                </div>
              )}
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {sortedLeads.map((lead, index) => (
                  <div
                    key={lead.id}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <LeadCard 
                      lead={lead} 
                      isSelected={selectedLeads.has(lead.id)}
                      onSelect={() => handleSelectLead(lead.id)}
                    />
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </PageContainer>

      <FloatingActionButton
        onClick={() => navigate('/leads/new')}
        icon={Plus}
        label="Add New Lead"
      />

      {/* Bulk Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => !isDeleting && setShowDeleteModal(false)}
        title="Delete Selected Leads"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-gray-700 dark:text-gray-300">
            Are you sure you want to delete <strong>{selectedLeads.size}</strong> lead{selectedLeads.size > 1 ? 's' : ''}? This action cannot be undone.
          </p>
          <div className="flex items-center gap-3 pt-2">
            <Button
              variant="outline"
              fullWidth
              onClick={() => setShowDeleteModal(false)}
              disabled={isDeleting}
            >
              Cancel
            </Button>
            <Button
              variant="danger"
              fullWidth
              onClick={handleBulkDelete}
              disabled={isDeleting}
              icon={isDeleting ? null : <Trash2 size={16} />}
            >
              {isDeleting ? 'Deleting...' : `Delete ${selectedLeads.size}`}
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default Leads;
