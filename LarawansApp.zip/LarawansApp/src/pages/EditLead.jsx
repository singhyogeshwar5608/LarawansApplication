import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Phone, Lock, User, MapPin, Briefcase, Target, Calendar, Clock, Save } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import Textarea from '../components/ui/Textarea';
import Checkbox from '../components/ui/Checkbox';
import { RadioGroup } from '../components/ui/Radio';
import Badge from '../components/ui/Badge';
import Card from '../components/ui/Card';
import { useToast } from '../hooks/useToast';
import { subscribeToLead, updateLead } from '../services/leadsService';

const EditLead = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { success, error: showError } = useToast();

  const [formData, setFormData] = useState({
    phone: '',
    status: 'interested',
    name: '',
    city: '',
    district: '',
    businessDetails: '',
    services: {
      metaAds: false,
      website: false,
      marketplace: false,
      others: false,
      allAbove: false,
    },
    otherService: '',
    followUpDays: '',
    followUpDate: '',
    followUpTime: '',
    meetingLocation: 'office',
    notes: '',
  });

  const [loading, setLoading] = useState(false);
  const [loadingLead, setLoadingLead] = useState(true);
  const [errors, setErrors] = useState({});
  const [quickScheduleTab, setQuickScheduleTab] = useState(true);

  // Fetch lead from Firebase
  useEffect(() => {
    if (!id) return;

    const unsubscribe = subscribeToLead(id, (leadData) => {
      if (leadData) {
        // Convert Firestore timestamps
        const followUpDate = leadData.followUpDate?.toDate?.()?.toISOString() || leadData.followUpDate || '';
        
        // Parse services into checkbox format
        const services = leadData.services || [];
        const servicesObj = {
          metaAds: services.includes('Meta Ads'),
          website: services.includes('Website'),
          marketplace: services.includes('Marketplace'),
          others: services.some(s => !['Meta Ads', 'Website', 'Marketplace'].includes(s)),
          allAbove: false,
        };
        
        // Extract other service if exists
        const otherService = services.find(s => !['Meta Ads', 'Website', 'Marketplace'].includes(s)) || '';

        setFormData({
          phone: leadData.phone || '',
          status: leadData.status || 'interested',
          name: leadData.name || '',
          city: leadData.city || '',
          district: leadData.district || '',
          businessDetails: leadData.businessDetails || '',
          services: servicesObj,
          otherService: otherService,
          followUpDays: '',
          followUpDate: followUpDate ? followUpDate.split('T')[0] : '',
          followUpTime: followUpDate ? followUpDate.split('T')[1]?.slice(0, 5) : '',
          meetingLocation: leadData.meetingLocation || 'office',
          notes: leadData.notes || '',
        });
        setLoadingLead(false);
      } else {
        showError('Lead not found');
        navigate('/leads');
      }
    });

    return () => unsubscribe();
  }, [id, navigate, showError]);

  // City options
  const cityOptions = [
    { value: '', label: 'Select city' },
    { value: 'Delhi', label: 'Delhi' },
    { value: 'Mumbai', label: 'Mumbai' },
    { value: 'Bangalore', label: 'Bangalore' },
    { value: 'Hyderabad', label: 'Hyderabad' },
    { value: 'Chennai', label: 'Chennai' },
    { value: 'Kolkata', label: 'Kolkata' },
    { value: 'Pune', label: 'Pune' },
    { value: 'Ahmedabad', label: 'Ahmedabad' },
  ];


  // Meeting location options
  const meetingLocationOptions = [
    { value: 'office', label: 'Our Office' },
    { value: 'client', label: "Client's Place" },
  ];

  // Calculate follow-up date from days
  const calculateFollowUpDate = (days) => {
    const date = new Date();
    date.setDate(date.getDate() + parseInt(days));
    return date.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  // Handle service checkbox changes
  const handleServiceChange = (service) => {
    if (service === 'allAbove') {
      const allChecked = !formData.services.allAbove;
      setFormData({
        ...formData,
        services: {
          metaAds: allChecked,
          website: allChecked,
          marketplace: allChecked,
          others: false,
          allAbove: allChecked,
        },
      });
    } else {
      setFormData({
        ...formData,
        services: {
          ...formData.services,
          [service]: !formData.services[service],
          allAbove: false,
        },
      });
    }
  };

  // Get selected services as array
  const getSelectedServices = () => {
    const services = [];
    if (formData.services.metaAds) services.push('Meta Ads');
    if (formData.services.website) services.push('Website');
    if (formData.services.marketplace) services.push('Marketplace');
    if (formData.services.others && formData.otherService) services.push(formData.otherService);
    return services;
  };

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.city) {
      newErrors.city = 'City is required';
    }

    const selectedServices = getSelectedServices();
    if (selectedServices.length === 0) {
      newErrors.services = 'Please select at least one service';
    }

    if (formData.services.others && !formData.otherService.trim()) {
      newErrors.otherService = 'Please specify the service';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle submit
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const selectedServices = getSelectedServices();
      
      // Calculate follow-up date
      let followUpDate = null;
      if (quickScheduleTab && formData.followUpDays) {
        const date = new Date();
        date.setDate(date.getDate() + parseInt(formData.followUpDays));
        followUpDate = date.toISOString();
      } else if (formData.followUpDate) {
        const dateTime = formData.followUpTime 
          ? `${formData.followUpDate}T${formData.followUpTime}:00`
          : `${formData.followUpDate}T12:00:00`;
        followUpDate = new Date(dateTime).toISOString();
      }
      
      const updatedLead = {
        phone: formData.phone,
        status: formData.status,
        name: formData.name.trim(),
        city: formData.city,
        district: formData.district.trim(),
        businessDetails: formData.businessDetails.trim(),
        services: selectedServices,
        followUpDate: followUpDate,
        meetingLocation: formData.meetingLocation,
        notes: formData.notes.trim(),
      };

      // Update in Firebase
      await updateLead(id, updatedLead);

      setLoading(false);
      success('Lead details saved successfully!');
      navigate(`/leads/${id}`);
    } catch (error) {
      console.error('Error updating lead:', error);
      setLoading(false);
      showError('Failed to save lead. Please try again.');
    }
  };

  const selectedServicesChips = getSelectedServices();

  if (loadingLead) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
        <div className="text-gray-500 dark:text-gray-400">Loading lead...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-24 lg:pb-6">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-4 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(`/leads/${id}`)}
            className="p-2 -ml-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <ArrowLeft size={24} className="text-gray-700 dark:text-gray-300" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white">
              Complete Lead Details
            </h1>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Status:</span>
              <Badge status={formData.status} size="sm" />
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="max-w-2xl mx-auto px-4 py-4 sm:py-6 space-y-4 sm:space-y-6">
        {/* SECTION 0: Status Change */}
        <Card title="🔄 Change Status" padding="sm" className="sm:p-4">
          <Select
            label="Lead Status"
            options={[
              { value: 'interested', label: 'Interested' },
              { value: 'scheduled', label: 'Scheduled' },
              { value: 'converted', label: 'Converted' },
              { value: 'rejected', label: 'Rejected' },
            ]}
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value })}
          />
        </Card>

        {/* SECTION 1: Basic Information */}
        <Card title="📋 Basic Information" padding="sm" className="sm:p-6">
          <div className="space-y-4">
            {/* Phone (Locked) */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Phone Number
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <Phone className="absolute left-10 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="tel"
                  value={formData.phone}
                  disabled
                  className="w-full pl-20 pr-4 py-3 bg-gray-100 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg text-gray-500 dark:text-gray-400 cursor-not-allowed"
                />
              </div>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Phone number cannot be changed
              </p>
            </div>

            {/* Name */}
            <Input
              label="Name"
              placeholder="Customer Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              error={errors.name}
              required
              icon={<User size={18} />}
            />

            {/* City */}
            <Select
              label="City"
              options={cityOptions}
              value={formData.city}
              onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              error={errors.city}
              required
            />

            {/* District */}
            <Input
              label="District"
              placeholder="District/Area"
              value={formData.district}
              onChange={(e) => setFormData({ ...formData, district: e.target.value })}
              icon={<MapPin size={18} />}
            />

            {/* Business Details */}
            <Textarea
              label="Business Type/Details"
              placeholder="Business Type/Details"
              value={formData.businessDetails}
              onChange={(e) => setFormData({ ...formData, businessDetails: e.target.value })}
              rows={3}
            />
          </div>
        </Card>

        {/* SECTION 2: Services Required */}
        <Card title="🎯 Services Required" padding="sm" className="sm:p-6">
          {errors.services && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/30 rounded-lg">
              <p className="text-sm text-red-600 dark:text-red-400">{errors.services}</p>
            </div>
          )}

          {/* Selected Services Chips */}
          {selectedServicesChips.length > 0 && (
            <div className="mb-4 flex flex-wrap gap-2">
              {selectedServicesChips.map((service, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-sm rounded-full font-medium"
                >
                  {service}
                </span>
              ))}
            </div>
          )}

          <div className="space-y-3">
            <Checkbox
              checked={formData.services.metaAds}
              onChange={() => handleServiceChange('metaAds')}
              label={
                <div className="flex items-center gap-2">
                  <span className="text-blue-600">📘</span>
                  <span>Meta Ads (Facebook & Instagram)</span>
                </div>
              }
            />

            <Checkbox
              checked={formData.services.website}
              onChange={() => handleServiceChange('website')}
              label={
                <div className="flex items-center gap-2">
                  <span className="text-green-600">🌐</span>
                  <span>Website Development</span>
                </div>
              }
            />

            <Checkbox
              checked={formData.services.marketplace}
              onChange={() => handleServiceChange('marketplace')}
              label={
                <div className="flex items-center gap-2">
                  <span className="text-orange-600">🛒</span>
                  <span>Marketplace (Amazon, Flipkart)</span>
                </div>
              }
            />

            <div>
              <Checkbox
                checked={formData.services.others}
                onChange={() => handleServiceChange('others')}
                label={
                  <div className="flex items-center gap-2">
                    <span>➕</span>
                    <span>Others (Specify)</span>
                  </div>
                }
              />
              {formData.services.others && (
                <div className="mt-2 ml-6">
                  <Input
                    placeholder="Other Service"
                    value={formData.otherService}
                    onChange={(e) => setFormData({ ...formData, otherService: e.target.value })}
                    error={errors.otherService}
                  />
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-gray-200 dark:border-gray-700">
              <Checkbox
                checked={formData.services.allAbove}
                onChange={() => handleServiceChange('allAbove')}
                label={
                  <div className="flex items-center gap-2">
                    <span className="text-purple-600">✅</span>
                    <span className="font-semibold">All Above Services</span>
                  </div>
                }
              />
            </div>
          </div>
        </Card>

        {/* SECTION 3: Schedule Follow-up */}
        <Card title="📅 Schedule Follow-up" padding="sm" className="sm:p-6">
          {/* Tabs */}
          <div className="flex gap-2 mb-3">
            <button
              type="button"
              onClick={() => setQuickScheduleTab(true)}
              className={`flex-1 py-1.5 sm:py-2 px-3 sm:px-4 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                quickScheduleTab
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              Quick
            </button>
            <button
              type="button"
              onClick={() => setQuickScheduleTab(false)}
              className={`flex-1 py-1.5 sm:py-2 px-3 sm:px-4 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                !quickScheduleTab
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              Custom
            </button>
          </div>

          {/* Quick Schedule Tab */}
          {quickScheduleTab ? (
            <div className="space-y-3">
              <div>
                <label className="block text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Days from today
                </label>
                <Input
                  type="number"
                  placeholder="Number of Days"
                  value={formData.followUpDays}
                  onChange={(e) => {
                    const value = e.target.value;
                    if (value === '' || (parseInt(value) > 0 && parseInt(value) <= 365)) {
                      setFormData({ ...formData, followUpDays: value });
                    }
                  }}
                  min="1"
                  max="365"
                  icon={<Calendar size={16} />}
                  className="text-sm"
                />
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Quick options: 1, 2, 3, 5, 7, 10, 15 days
                </p>
              </div>

              {formData.followUpDays && (
                <div className="p-2 sm:p-3 bg-primary-50 dark:bg-primary-900/20 rounded-lg">
                  <p className="text-xs sm:text-sm text-primary-700 dark:text-primary-300 font-medium">
                    📅 Follow-up on: {calculateFollowUpDate(formData.followUpDays)}
                  </p>
                </div>
              )}
            </div>
          ) : (
            /* Custom Date Tab */
            <div className="space-y-4">
              <Input
                label="Follow-up Date"
                type="date"
                value={formData.followUpDate}
                onChange={(e) => setFormData({ ...formData, followUpDate: e.target.value })}
                min={new Date().toISOString().split('T')[0]}
                icon={<Calendar size={18} />}
              />

              <Input
                label="Follow-up Time (Optional)"
                type="time"
                value={formData.followUpTime}
                onChange={(e) => setFormData({ ...formData, followUpTime: e.target.value })}
                icon={<Clock size={18} />}
              />
            </div>
          )}

          {/* Meeting Location */}
          <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
            <RadioGroup
              label="Meeting Location"
              name="meetingLocation"
              options={meetingLocationOptions}
              value={formData.meetingLocation}
              onChange={(value) => setFormData({ ...formData, meetingLocation: value })}
              orientation="vertical"
            />
          </div>
        </Card>

        {/* SECTION 4: Notes */}
        <Card title="📝 Notes" padding="sm" className="sm:p-6">
          <Textarea
            placeholder="Notes"
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            rows={4}
            maxLength={500}
          />
        </Card>
      </form>

      {/* Sticky Bottom Save Button - Above Bottom Nav */}
      <div className="fixed bottom-16 left-0 right-0 p-3 sm:p-4 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg z-50 lg:bottom-0 lg:z-40">
        <div className="max-w-2xl mx-auto flex gap-2 sm:gap-3">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => navigate(`/leads/${id}`)}
            className="flex-1 text-xs sm:text-sm"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            variant="primary"
            size="sm"
            loading={loading}
            onClick={handleSubmit}
            icon={<Save size={16} />}
            className="flex-1 text-xs sm:text-sm"
          >
            <span className="hidden sm:inline">Save Details</span>
            <span className="sm:hidden">Save</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default EditLead;

