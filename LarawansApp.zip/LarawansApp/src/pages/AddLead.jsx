import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Phone, Check } from 'lucide-react';
import Button from '../components/ui/Button';
import ImportCSV from '../components/leads/ImportCSV';
import { useToast } from '../hooks/useToast';
import { createLead, checkPhoneExists } from '../services/leadsService';

const AddLead = () => {
  const navigate = useNavigate();
  const { success, error: showError } = useToast();
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Format phone number as user types
  const formatPhoneNumber = (value) => {
    // Remove all non-digits
    const digits = value.replace(/\D/g, '');
    
    // Limit to 10 digits
    const limited = digits.slice(0, 10);
    
    // Format as +91-XXXXX-XXXXX
    if (limited.length <= 5) {
      return limited;
    } else {
      return `${limited.slice(0, 5)}-${limited.slice(5)}`;
    }
  };

  const handlePhoneChange = (e) => {
    const formatted = formatPhoneNumber(e.target.value);
    setPhone(formatted);
    setError('');
  };

  const validatePhone = async () => {
    const digits = phone.replace(/\D/g, '');
    
    if (!digits) {
      setError('Phone number is required');
      return false;
    }
    
    if (digits.length !== 10) {
      setError('Phone number must be exactly 10 digits');
      return false;
    }
    
    // Check for duplicate phone number using Firebase (non-blocking)
    const phoneNumber = `+91-${phone}`;
    try {
      const exists = await checkPhoneExists(phoneNumber);
      if (exists) {
        setError('This phone number already exists in your leads!');
        showError('Duplicate phone number detected. This lead already exists.');
        return false;
      }
    } catch (error) {
      // If permission error, allow saving anyway (user can set up rules later)
      if (error.code === 'permission-denied') {
        console.warn('Firestore permissions not set up. Allowing save anyway.');
        // Don't block the save, just warn
      } else {
        console.error('Error checking phone:', error);
        // Still allow save, but show warning
      }
      // Continue with save even if check fails
    }
    
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const isValid = await validatePhone();
    if (!isValid) return;
    
    setLoading(true);
    
    try {
      // Create lead object
      const newLead = {
        phone: `+91-${phone}`,
        status: 'new',
        // All other fields null until status changes
        name: null,
        city: null,
        district: null,
        businessDetails: null,
        services: [],
        followUpDate: null,
        meetingLocation: null,
        notes: null,
        callHistory: [], // Initialize call history
      };
      
      // Save to Firebase
      await createLead(newLead);
      
      setLoading(false);
      success('Lead added successfully!');
      
      // Navigate back to leads list
      navigate('/leads');
    } catch (error) {
      console.error('Error creating lead:', error);
      setLoading(false);
      showError('Failed to add lead. Please try again.');
    }
  };

  const isValid = phone.replace(/\D/g, '').length === 10;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-24 lg:pb-6">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3 sm:py-4 sticky top-0 z-10">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
            <button
              onClick={() => navigate('/leads')}
              className="p-2 -ml-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors flex-shrink-0"
            >
              <ArrowLeft size={20} className="sm:w-6 sm:h-6 text-gray-700 dark:text-gray-300" />
            </button>
            <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white truncate">
              Add New Lead
            </h1>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <ImportCSV onImportComplete={() => navigate('/leads')} />
          </div>
        </div>
      </div>

      {/* Main Content - Centered */}
      <div className="flex items-center justify-center px-4 pt-12">
        <div className="w-full max-w-md">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Icon */}
            <div className="flex justify-center animate-slide-down">
              <div className="w-20 h-20 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center">
                <Phone size={40} className="text-primary-600 dark:text-primary-400" />
              </div>
            </div>

            {/* Heading */}
            <div className="text-center animate-slide-up">
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white mb-2">
                Enter Customer Phone Number
              </h2>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                You can add more details after the first call
              </p>
            </div>

            {/* Phone Input */}
            <div className="animate-slide-up" style={{ animationDelay: '100ms' }}>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 text-gray-500 dark:text-gray-400">
                  <Phone size={20} />
                  <span className="text-lg font-medium">+91</span>
                  <span className="text-gray-300 dark:text-gray-600">|</span>
                </div>
                
                <input
                  type="tel"
                  value={phone}
                  onChange={handlePhoneChange}
                  placeholder="XXXXX-XXXXX"
                  autoFocus
                  className={`w-full pl-20 sm:pl-24 pr-8 sm:pr-12 py-4 sm:py-5 text-lg sm:text-xl md:text-2xl font-semibold bg-white dark:bg-gray-800 border-2 ${
                    error 
                      ? 'border-red-500 focus:border-red-500' 
                      : isValid
                      ? 'border-green-500 focus:border-green-500'
                      : 'border-gray-300 dark:border-gray-600 focus:border-primary-500'
                  } rounded-2xl text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-0 transition-all duration-200`}
                  inputMode="numeric"
                />
                
                {isValid && (
                  <div className="absolute right-4 top-1/2 -translate-y-1/2">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center animate-fade-in">
                      <Check size={20} className="text-white" />
                    </div>
                  </div>
                )}
              </div>
              
              {/* Error Message */}
              {error && (
                <p className="mt-2 text-sm text-red-600 dark:text-red-400 animate-slide-down">
                  {error}
                </p>
              )}
              
              {/* Help Text */}
              {!error && (
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400 text-center">
                  Enter 10-digit mobile number
                </p>
              )}
            </div>

            {/* Character count */}
            <div className="text-center">
              <span className={`text-sm font-medium ${
                isValid 
                  ? 'text-green-600 dark:text-green-400' 
                  : 'text-gray-500 dark:text-gray-400'
              }`}>
                {phone.replace(/\D/g, '').length} / 10 digits
              </span>
            </div>
          </form>
        </div>
      </div>

      {/* Bottom Save Button - Sticky (Above Bottom Nav) */}
      <div className="fixed bottom-16 left-0 right-0 p-4 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg lg:hidden z-50">
        <Button
          onClick={handleSubmit}
          variant="primary"
          size="md"
          fullWidth
          disabled={!isValid}
          loading={loading}
          className="!py-3 sm:!py-4 text-sm sm:text-base font-semibold shadow-lg"
        >
          Save Lead
        </Button>
      </div>

      {/* Desktop Save Button */}
      <div className="hidden lg:flex justify-center mt-8">
        <Button
          onClick={handleSubmit}
          variant="primary"
          size="lg"
          disabled={!isValid}
          loading={loading}
          className="!py-4 px-12 text-base font-semibold shadow-lg"
        >
          Save Lead
        </Button>
      </div>
    </div>
  );
};

export default AddLead;
