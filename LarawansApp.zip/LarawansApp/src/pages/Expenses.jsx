import { useState, useEffect, useMemo } from 'react';
import { Plus, Search, Filter, Calendar, TrendingUp, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PageContainer from '../components/layout/PageContainer';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import Modal from '../components/ui/Modal';
import FloatingActionButton from '../components/layout/FloatingActionButton';
import BalanceCard from '../components/expenses/BalanceCard';
import ExpenseCard from '../components/expenses/ExpenseCard';
import AddExpense from '../components/expenses/AddExpense';
import EmptyState from '../components/ui/EmptyState';
import { subscribeToExpenses, subscribeToCompanyBalance, deleteExpense, resetAllExpensesAndBalance } from '../services/expenseService';
import { useToast } from '../hooks/useToast';

const Expenses = () => {
  const navigate = useNavigate();
  const { success, error: showError } = useToast();
  const [expenses, setExpenses] = useState([]);
  const [balance, setBalance] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);
  const [showDeleteAllModal, setShowDeleteAllModal] = useState(false);
  const [isDeletingAll, setIsDeletingAll] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  
  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [paymentMethodFilter, setPaymentMethodFilter] = useState('');
  const [dateFilter, setDateFilter] = useState('all');

  // Fetch expenses and balance
  useEffect(() => {
    const unsubscribeExpenses = subscribeToExpenses((expensesData) => {
      const processed = expensesData.map(expense => ({
        ...expense,
        expenseDate: expense.expenseDate || (expense.createdAt?.toDate?.()?.toISOString().split('T')[0] || new Date().toISOString().split('T')[0]),
      }));
      setExpenses(processed);
      setLoading(false);
    });

    const unsubscribeBalance = subscribeToCompanyBalance((balanceData) => {
      setBalance(balanceData);
    });

    return () => {
      unsubscribeExpenses();
      unsubscribeBalance();
    };
  }, []);

  const categories = [
    { value: '', label: 'All Categories' },
    { value: 'Home', label: 'Home' },
    { value: 'Company', label: 'Company' },
    { value: 'Travel', label: 'Travel' },
    { value: 'Salary', label: 'Salary' },
    { value: 'Marketing', label: 'Marketing' },
    { value: 'Office Supplies', label: 'Office Supplies' },
    { value: 'Utilities', label: 'Utilities' },
    { value: 'Maintenance', label: 'Maintenance' },
    { value: 'Food & Beverages', label: 'Food & Beverages' },
    { value: 'Other', label: 'Other' },
  ];

  const paymentMethods = [
    { value: '', label: 'All Payment Methods' },
    { value: 'Cash', label: 'Cash' },
    { value: 'UPI', label: 'UPI' },
    { value: 'Bank Transfer', label: 'Bank Transfer' },
    { value: 'Credit Card', label: 'Credit Card' },
    { value: 'Debit Card', label: 'Debit Card' },
  ];

  const dateFilterOptions = [
    { value: 'all', label: 'All Time' },
    { value: 'today', label: 'Today' },
    { value: 'yesterday', label: 'Yesterday' },
    { value: 'thisWeek', label: 'This Week' },
    { value: 'thisMonth', label: 'This Month' },
  ];

  // Filter and group expenses
  const { filteredExpenses, groupedExpenses } = useMemo(() => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    
    const today = new Date(now);
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    const thisWeekStart = new Date(now);
    thisWeekStart.setDate(now.getDate() - now.getDay());
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    let filtered = expenses.filter((expense) => {
      // Search filter
      const matchesSearch = 
        !searchTerm ||
        expense.reason?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        expense.amount?.toString().includes(searchTerm);

      // Category filter
      const matchesCategory = !categoryFilter || expense.category === categoryFilter;

      // Payment method filter
      const matchesPayment = !paymentMethodFilter || expense.paymentMethod === paymentMethodFilter;

      // Date filter
      let matchesDate = true;
      if (dateFilter !== 'all') {
        const expenseDate = new Date(expense.expenseDate);
        expenseDate.setHours(0, 0, 0, 0);
        
        switch (dateFilter) {
          case 'today':
            matchesDate = expenseDate.getTime() === today.getTime();
            break;
          case 'yesterday':
            matchesDate = expenseDate.getTime() === yesterday.getTime();
            break;
          case 'thisWeek':
            matchesDate = expenseDate >= thisWeekStart;
            break;
          case 'thisMonth':
            matchesDate = expenseDate >= thisMonthStart;
            break;
        }
      }

      return matchesSearch && matchesCategory && matchesPayment && matchesDate;
    });

    // Group expenses
    const grouped = {
      today: [],
      yesterday: [],
      thisWeek: [],
      thisMonth: [],
      older: [],
    };

    filtered.forEach((expense) => {
      const expenseDate = new Date(expense.expenseDate);
      expenseDate.setHours(0, 0, 0, 0);
      
      if (expenseDate.getTime() === today.getTime()) {
        grouped.today.push(expense);
      } else if (expenseDate.getTime() === yesterday.getTime()) {
        grouped.yesterday.push(expense);
      } else if (expenseDate >= thisWeekStart) {
        grouped.thisWeek.push(expense);
      } else if (expenseDate >= thisMonthStart) {
        grouped.thisMonth.push(expense);
      } else {
        grouped.older.push(expense);
      }
    });

    return { filteredExpenses: filtered, groupedExpenses: grouped };
  }, [expenses, searchTerm, categoryFilter, paymentMethodFilter, dateFilter]);

  const handleAddSuccess = () => {
    setShowAddModal(false);
    success('Expense added successfully!');
  };

  const handleEdit = (expense) => {
    setEditingExpense(expense);
    setShowAddModal(true);
  };

  const handleDelete = (expenseId) => {
    setExpenses(prev => prev.filter(e => e.id !== expenseId));
  };

  const handleDeleteAll = async () => {
    if (expenses.length === 0) return;
    
    setIsDeletingAll(true);
    try {
      // Delete all expenses
      const deletePromises = expenses.map(expense => deleteExpense(expense.id));
      await Promise.all(deletePromises);
      
      success(`Successfully deleted ${expenses.length} expense${expenses.length > 1 ? 's' : ''}. All amounts have been added back to balance.`);
      setShowDeleteAllModal(false);
    } catch (error) {
      console.error('Error deleting all expenses:', error);
      showError('Failed to delete some expenses. Please try again.');
    } finally {
      setIsDeletingAll(false);
    }
  };

  const handleResetAll = async () => {
    setIsResetting(true);
    try {
      const result = await resetAllExpensesAndBalance();
      success(`Successfully reset! Deleted ${result.deletedCount} expense${result.deletedCount !== 1 ? 's' : ''} and reset balance to ₹0.`);
      setShowResetModal(false);
    } catch (error) {
      console.error('Error resetting expenses and balance:', error);
      showError('Failed to reset. Please try again.');
    } finally {
      setIsResetting(false);
    }
  };

  const getGroupTitle = (group) => {
    const titles = {
      today: 'Today',
      yesterday: 'Yesterday',
      thisWeek: 'This Week',
      thisMonth: 'This Month',
      older: 'Older',
    };
    return titles[group] || group;
  };

  const getTotalForGroup = (groupExpenses) => {
    return groupExpenses.reduce((sum, exp) => sum + (exp.amount || 0), 0);
  };

  return (
    <>
      <PageContainer
        title="Expenses"
        subtitle="Track and manage your company expenses"
        actions={
          <div className="flex gap-2">
            {(expenses.length > 0 || balance?.totalExpenses > 0 || balance?.totalRevenue > 0) && (
              <Button
                variant="danger"
                size="sm"
                onClick={() => setShowResetModal(true)}
                icon={<Trash2 size={16} />}
              >
                Reset All
              </Button>
            )}
            {expenses.length > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDeleteAllModal(true)}
                icon={<Trash2 size={16} />}
              >
                Delete All
              </Button>
            )}
            <Button
              variant="primary"
              size="sm"
              onClick={() => {
                setEditingExpense(null);
                setShowAddModal(true);
              }}
              icon={<Plus size={16} />}
            >
              Add Expense
            </Button>
          </div>
        }
      >
        <div className="space-y-6 pb-24">
          {/* Balance Card */}
          {balance && (
            <BalanceCard
              balance={balance}
              onClick={() => navigate('/expenses')}
            />
          )}

          {/* Filters */}
          <Card>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Input
                placeholder="Search expenses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                icon={<Search size={18} />}
              />
              <Select
                placeholder="Category"
                options={categories}
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              />
              <Select
                placeholder="Payment Method"
                options={paymentMethods}
                value={paymentMethodFilter}
                onChange={(e) => setPaymentMethodFilter(e.target.value)}
              />
              <Select
                placeholder="Date Range"
                options={dateFilterOptions}
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                icon={<Calendar size={16} />}
              />
            </div>
          </Card>

          {/* Expenses List */}
          {loading ? (
            <div className="flex justify-center items-center py-12">
              <div className="text-gray-500 dark:text-gray-400">Loading expenses...</div>
            </div>
          ) : filteredExpenses.length === 0 ? (
            <EmptyState
              title="No expenses found"
              description={searchTerm || categoryFilter || paymentMethodFilter || dateFilter !== 'all' 
                ? "Try adjusting your filters" 
                : "Add your first expense to get started"}
              actionLabel="Add Expense"
              onAction={() => setShowAddModal(true)}
            />
          ) : (
            <div className="space-y-6">
              {/* Today */}
              {groupedExpenses.today.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Today ({groupedExpenses.today.length})
                    </h3>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      ₹{getTotalForGroup(groupedExpenses.today).toLocaleString('en-IN')}
                    </p>
                  </div>
                  <div className="space-y-3">
                    {groupedExpenses.today.map((expense) => (
                      <ExpenseCard
                        key={expense.id}
                        expense={expense}
                        onEdit={handleEdit}
                        onDelete={handleDelete}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Yesterday */}
              {groupedExpenses.yesterday.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Yesterday ({groupedExpenses.yesterday.length})
                    </h3>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      ₹{getTotalForGroup(groupedExpenses.yesterday).toLocaleString('en-IN')}
                    </p>
                  </div>
                  <div className="space-y-3">
                    {groupedExpenses.yesterday.map((expense) => (
                      <ExpenseCard
                        key={expense.id}
                        expense={expense}
                        onEdit={handleEdit}
                        onDelete={handleDelete}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* This Week */}
              {groupedExpenses.thisWeek.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      This Week ({groupedExpenses.thisWeek.length})
                    </h3>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      ₹{getTotalForGroup(groupedExpenses.thisWeek).toLocaleString('en-IN')}
                    </p>
                  </div>
                  <div className="space-y-3">
                    {groupedExpenses.thisWeek.map((expense) => (
                      <ExpenseCard
                        key={expense.id}
                        expense={expense}
                        onEdit={handleEdit}
                        onDelete={handleDelete}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* This Month */}
              {groupedExpenses.thisMonth.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      This Month ({groupedExpenses.thisMonth.length})
                    </h3>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      ₹{getTotalForGroup(groupedExpenses.thisMonth).toLocaleString('en-IN')}
                    </p>
                  </div>
                  <div className="space-y-3">
                    {groupedExpenses.thisMonth.map((expense) => (
                      <ExpenseCard
                        key={expense.id}
                        expense={expense}
                        onEdit={handleEdit}
                        onDelete={handleDelete}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Older */}
              {groupedExpenses.older.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Older ({groupedExpenses.older.length})
                    </h3>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      ₹{getTotalForGroup(groupedExpenses.older).toLocaleString('en-IN')}
                    </p>
                  </div>
                  <div className="space-y-3">
                    {groupedExpenses.older.map((expense) => (
                      <ExpenseCard
                        key={expense.id}
                        expense={expense}
                        onEdit={handleEdit}
                        onDelete={handleDelete}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </PageContainer>

      <FloatingActionButton
        onClick={() => {
          setEditingExpense(null);
          setShowAddModal(true);
        }}
        icon={Plus}
        label="Add Expense"
      />

      {/* Add/Edit Expense Modal */}
      <AddExpense
        isOpen={showAddModal}
        onClose={() => {
          setShowAddModal(false);
          setEditingExpense(null);
        }}
        onSuccess={handleAddSuccess}
      />

      {/* Delete All Confirmation Modal */}
      <Modal
        isOpen={showDeleteAllModal}
        onClose={() => !isDeletingAll && setShowDeleteAllModal(false)}
        title="Delete All Expenses"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-gray-700 dark:text-gray-300">
            Are you sure you want to delete <strong>all {expenses.length} expense{expenses.length > 1 ? 's' : ''}</strong>? 
            This action cannot be undone.
          </p>
          <div className="p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
            <p className="text-sm font-medium text-gray-900 dark:text-white mb-1">
              This will:
            </p>
            <ul className="text-sm text-gray-600 dark:text-gray-400 list-disc list-inside space-y-1">
              <li>Delete all expense records</li>
              <li>Add all expense amounts back to your balance</li>
              <li>Reset your expense history</li>
            </ul>
            <p className="text-sm font-semibold text-gray-900 dark:text-white mt-2">
              Total Amount: ₹{expenses.reduce((sum, e) => sum + (e.amount || 0), 0).toLocaleString('en-IN')}
            </p>
          </div>
          <div className="flex items-center gap-3 pt-2">
            <Button
              variant="outline"
              fullWidth
              onClick={() => setShowDeleteAllModal(false)}
              disabled={isDeletingAll}
            >
              Cancel
            </Button>
            <Button
              variant="danger"
              fullWidth
              onClick={handleDeleteAll}
              disabled={isDeletingAll}
              icon={isDeletingAll ? null : <Trash2 size={16} />}
            >
              {isDeletingAll ? 'Deleting...' : 'Delete All'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Reset All Confirmation Modal */}
      <Modal
        isOpen={showResetModal}
        onClose={() => !isResetting && setShowResetModal(false)}
        title="Reset Everything to Zero"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-gray-700 dark:text-gray-300">
            Are you sure you want to <strong>reset everything to zero</strong>? 
            This action cannot be undone.
          </p>
          <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
            <p className="text-sm font-medium text-red-900 dark:text-red-100 mb-2">
              ⚠️ This will permanently:
            </p>
            <ul className="text-sm text-red-800 dark:text-red-200 list-disc list-inside space-y-1">
              <li>Delete <strong>all expense records</strong></li>
              <li>Reset <strong>Current Balance</strong> to ₹0</li>
              <li>Reset <strong>Total Revenue</strong> to ₹0</li>
              <li>Reset <strong>Total Expenses</strong> to ₹0</li>
            </ul>
            <p className="text-sm font-semibold text-red-900 dark:text-red-100 mt-3 pt-2 border-t border-red-200 dark:border-red-800">
              This will start your account completely fresh!
            </p>
          </div>
          <div className="flex items-center gap-3 pt-2">
            <Button
              variant="outline"
              fullWidth
              onClick={() => setShowResetModal(false)}
              disabled={isResetting}
            >
              Cancel
            </Button>
            <Button
              variant="danger"
              fullWidth
              onClick={handleResetAll}
              disabled={isResetting}
              icon={isResetting ? null : <Trash2 size={16} />}
            >
              {isResetting ? 'Resetting...' : 'Reset to Zero'}
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default Expenses;

