import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  TrendingUp, 
  Users, 
  Target, 
  DollarSign, 
  Percent,
  Calendar,
  CheckCircle,
  Clock,
  XCircle,
  ArrowRight
} from 'lucide-react';
import PageContainer from '../components/layout/PageContainer';
import Card from '../components/ui/Card';
import Spinner from '../components/ui/Spinner';
import { subscribeToLeads } from '../services/leadsService';
import { subscribeToDeals } from '../services/dealsService';

const Analytics = () => {
  const navigate = useNavigate();
  const [leads, setLeads] = useState([]);
  const [deals, setDeals] = useState([]);
  const [loading, setLoading] = useState(true);

  // Subscribe to real-time data
  useEffect(() => {
    let unsubscribeLeads = null;
    let unsubscribeDeals = null;
    let loadingTimeout = null;

    try {
      unsubscribeLeads = subscribeToLeads((leadsData) => {
        setLeads(leadsData || []);
        setLoading(false);
        if (loadingTimeout) {
          clearTimeout(loadingTimeout);
          loadingTimeout = null;
        }
      });

      unsubscribeDeals = subscribeToDeals((dealsData) => {
        setDeals(dealsData || []);
      });

      // Safety timeout - ensure loading state doesn't get stuck
      loadingTimeout = setTimeout(() => {
        setLoading(false);
      }, 10000); // 10 seconds max loading time
    } catch (error) {
      console.error('Error setting up subscriptions:', error);
      setLoading(false);
    }

    return () => {
      if (loadingTimeout) {
        clearTimeout(loadingTimeout);
      }
      if (unsubscribeLeads && typeof unsubscribeLeads === 'function') {
        unsubscribeLeads();
      }
      if (unsubscribeDeals && typeof unsubscribeDeals === 'function') {
        unsubscribeDeals();
      }
    };
  }, []);

  // Calculate conversion funnel (lead status distribution)
  const conversionFunnel = useMemo(() => {
    const statusCounts = {
      'new': 0,
      'interested': 0,
      'scheduled': 0,
      'converted': 0,
      'rejected': 0,
    };

    leads.forEach(lead => {
      const status = (lead.status || 'new').toLowerCase();
      if (statusCounts.hasOwnProperty(status)) {
        statusCounts[status]++;
      } else {
        statusCounts['new']++;
      }
    });

    return [
      { label: 'New', count: statusCounts['new'], color: 'bg-green-500', status: 'new' },
      { label: 'Interested', count: statusCounts['interested'], color: 'bg-yellow-500', status: 'interested' },
      { label: 'Scheduled', count: statusCounts['scheduled'], color: 'bg-blue-500', status: 'scheduled' },
      { label: 'Converted', count: statusCounts['converted'], color: 'bg-purple-500', status: 'converted' },
      { label: 'Rejected', count: statusCounts['rejected'], color: 'bg-red-500', status: 'rejected' },
    ];
  }, [leads]);

  // Calculate key metrics
  const metrics = useMemo(() => {
    const totalLeads = leads.length;
    const totalDeals = deals.length;
    const convertedLeads = leads.filter(l => (l.status || '').toLowerCase() === 'converted').length;
    const conversionRate = totalLeads > 0 ? ((convertedLeads / totalLeads) * 100).toFixed(1) : 0;
    
    const totalRevenue = deals.reduce((sum, d) => sum + (parseFloat(d.totalAmount) || 0), 0);
    const totalPaid = deals.reduce((sum, d) => sum + (parseFloat(d.paidAmount) || 0), 0);
    const totalPending = deals.reduce((sum, d) => sum + (parseFloat(d.pendingAmount) || 0), 0);

    return {
      totalLeads,
      totalDeals,
      conversionRate: parseFloat(conversionRate),
      totalRevenue,
      totalPaid,
      totalPending,
    };
  }, [leads, deals]);

  // Calculate time-based trends
  const timeTrends = useMemo(() => {
    const now = new Date();
    const thisWeekStart = new Date(now);
    thisWeekStart.setDate(now.getDate() - now.getDay());
    thisWeekStart.setHours(0, 0, 0, 0);
    
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const leadsThisWeek = leads.filter(lead => {
      const leadDate = lead.createdAt?.toDate?.() || new Date(lead.createdAt || 0);
      return leadDate >= thisWeekStart;
    }).length;

    const leadsThisMonth = leads.filter(lead => {
      const leadDate = lead.createdAt?.toDate?.() || new Date(lead.createdAt || 0);
      return leadDate >= thisMonthStart;
    }).length;

    const dealsThisWeek = deals.filter(deal => {
      const dealDate = deal.createdAt?.toDate?.() || new Date(deal.createdAt || 0);
      return dealDate >= thisWeekStart;
    }).length;

    const dealsThisMonth = deals.filter(deal => {
      const dealDate = deal.createdAt?.toDate?.() || new Date(deal.createdAt || 0);
      return dealDate >= thisMonthStart;
    }).length;

    const revenueThisWeek = deals
      .filter(deal => {
        const dealDate = deal.createdAt?.toDate?.() || new Date(deal.createdAt || 0);
        return dealDate >= thisWeekStart;
      })
      .reduce((sum, d) => sum + (parseFloat(d.totalAmount) || 0), 0);

    const revenueThisMonth = deals
      .filter(deal => {
        const dealDate = deal.createdAt?.toDate?.() || new Date(deal.createdAt || 0);
        return dealDate >= thisMonthStart;
      })
      .reduce((sum, d) => sum + (parseFloat(d.totalAmount) || 0), 0);

    return {
      leadsThisWeek,
      leadsThisMonth,
      dealsThisWeek,
      dealsThisMonth,
      revenueThisWeek,
      revenueThisMonth,
    };
  }, [leads, deals]);

  // Calculate deal status distribution
  const dealStatusDistribution = useMemo(() => {
    const statusCounts = {
      'active': 0,
      'completed': 0,
      'on-hold': 0,
      'cancelled': 0,
    };

    deals.forEach(deal => {
      const status = (deal.status || 'active').toLowerCase();
      if (statusCounts.hasOwnProperty(status)) {
        statusCounts[status]++;
      } else {
        statusCounts['active']++;
      }
    });

    return [
      { label: 'Active', count: statusCounts['active'], color: 'bg-blue-500', icon: Clock },
      { label: 'Completed', count: statusCounts['completed'], color: 'bg-green-500', icon: CheckCircle },
      { label: 'On Hold', count: statusCounts['on-hold'], color: 'bg-yellow-500', icon: Clock },
      { label: 'Cancelled', count: statusCounts['cancelled'], color: 'bg-red-500', icon: XCircle },
    ];
  }, [deals]);

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Handle funnel click - navigate to filtered leads
  const handleFunnelClick = (status) => {
    navigate(`/leads?status=${status}`);
  };

  // Handle deal status click - navigate to filtered deals
  const handleDealStatusClick = (status) => {
    navigate(`/deals?status=${status}`);
  };

  if (loading) {
    return (
      <PageContainer title="Analytics" subtitle="Track your lead generation and conversion metrics">
        <div className="flex items-center justify-center py-12">
          <Spinner size="lg" />
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer
      title="Analytics"
      subtitle="Track your lead generation and conversion metrics"
    >
      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card 
          className="p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98]"
          onClick={() => navigate('/leads')}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Total Leads</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{metrics.totalLeads}</p>
            </div>
            <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
              <Users className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
          </div>
        </Card>

        <Card 
          className="p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98]"
          onClick={() => navigate('/deals')}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Total Deals</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{metrics.totalDeals}</p>
            </div>
            <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
              <Target className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
          </div>
        </Card>

        <Card 
          className="p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98]"
          onClick={() => navigate('/leads')}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Conversion Rate</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{metrics.conversionRate}%</p>
            </div>
            <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
              <Percent className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
          </div>
        </Card>

        <Card 
          className="p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98]"
          onClick={() => navigate('/deals')}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{formatCurrency(metrics.totalRevenue)}</p>
            </div>
            <div className="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
              <DollarSign className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
            </div>
          </div>
        </Card>
      </div>

      {/* Conversion Funnel & Deal Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card title="Conversion Funnel" subtitle="Lead status distribution - Click to filter">
          <div className="space-y-3 mt-4">
            {conversionFunnel.map((item) => {
              const total = conversionFunnel.reduce((sum, i) => sum + i.count, 0);
              const percentage = total > 0 ? ((item.count / total) * 100).toFixed(1) : 0;
              
              return (
                <div 
                  key={item.label}
                  onClick={() => item.count > 0 && handleFunnelClick(item.status)}
                  className={`cursor-pointer p-3 rounded-lg transition-all duration-200 ${
                    item.count > 0 
                      ? 'hover:bg-gray-50 dark:hover:bg-gray-700/50 hover:shadow-md active:scale-[0.98]' 
                      : 'opacity-50 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 ${item.color} rounded-full`} />
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {item.label}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-gray-900 dark:text-white">
                        {item.count}
                      </span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        ({percentage}%)
                      </span>
                      {item.count > 0 && (
                        <ArrowRight size={14} className="text-gray-400 dark:text-gray-500" />
                      )}
                    </div>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${item.color} rounded-full transition-all duration-300`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card title="Deal Status Distribution" subtitle="Current deal status breakdown - Click to filter">
          <div className="space-y-3 mt-4">
            {dealStatusDistribution.map((item) => {
              const total = dealStatusDistribution.reduce((sum, i) => sum + i.count, 0);
              const percentage = total > 0 ? ((item.count / total) * 100).toFixed(1) : 0;
              const Icon = item.icon;
              
              // Map label to status value
              const statusMap = {
                'Active': 'active',
                'Completed': 'completed',
                'On Hold': 'on-hold',
                'Cancelled': 'cancelled',
              };
              const status = statusMap[item.label] || 'active';
              
              return (
                <div 
                  key={item.label}
                  onClick={() => item.count > 0 && handleDealStatusClick(status)}
                  className={`cursor-pointer p-3 rounded-lg transition-all duration-200 ${
                    item.count > 0 
                      ? 'hover:bg-gray-50 dark:hover:bg-gray-700/50 hover:shadow-md active:scale-[0.98]' 
                      : 'opacity-50 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Icon className={`w-4 h-4 ${item.color.replace('bg-', 'text-')}`} />
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {item.label}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-gray-900 dark:text-white">
                        {item.count}
                      </span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        ({percentage}%)
                      </span>
                      {item.count > 0 && (
                        <ArrowRight size={14} className="text-gray-400 dark:text-gray-500" />
                      )}
                    </div>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${item.color} rounded-full transition-all duration-300`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Revenue Analytics */}
      <Card title="Revenue Analytics" subtitle="Payment breakdown and trends - Click to view deals" className="mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
          <div 
            className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800 cursor-pointer hover:shadow-md transition-all duration-200 active:scale-[0.98]"
            onClick={() => navigate('/deals')}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-green-700 dark:text-green-300">Total Paid</span>
              <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
            </div>
            <p className="text-2xl font-bold text-green-900 dark:text-green-100">
              {formatCurrency(metrics.totalPaid)}
            </p>
            <p className="text-xs text-green-600 dark:text-green-400 mt-1">
              {metrics.totalRevenue > 0 
                ? `${((metrics.totalPaid / metrics.totalRevenue) * 100).toFixed(1)}% of total`
                : '0% of total'}
            </p>
          </div>

          <div 
            className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800 cursor-pointer hover:shadow-md transition-all duration-200 active:scale-[0.98]"
            onClick={() => navigate('/deals')}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-yellow-700 dark:text-yellow-300">Pending Amount</span>
              <Clock className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
            </div>
            <p className="text-2xl font-bold text-yellow-900 dark:text-yellow-100">
              {formatCurrency(metrics.totalPending)}
            </p>
            <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">
              {metrics.totalRevenue > 0 
                ? `${((metrics.totalPending / metrics.totalRevenue) * 100).toFixed(1)}% of total`
                : '0% of total'}
            </p>
          </div>

          <div 
            className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800 cursor-pointer hover:shadow-md transition-all duration-200 active:scale-[0.98]"
            onClick={() => navigate('/deals')}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-blue-700 dark:text-blue-300">Total Revenue</span>
              <DollarSign className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            </div>
            <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
              {formatCurrency(metrics.totalRevenue)}
            </p>
            <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
              From {metrics.totalDeals} {metrics.totalDeals === 1 ? 'deal' : 'deals'}
            </p>
          </div>
        </div>
      </Card>

      {/* Time-Based Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card title="This Week" subtitle="Activity in the last 7 days - Click to view">
          <div className="space-y-4 mt-4">
            <div 
              className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors active:scale-[0.98]"
              onClick={() => navigate('/leads')}
            >
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                <span className="text-sm text-gray-700 dark:text-gray-300">New Leads</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-gray-900 dark:text-white">
                  {timeTrends.leadsThisWeek}
                </span>
                <ArrowRight size={14} className="text-gray-400 dark:text-gray-500" />
              </div>
            </div>

            <div 
              className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors active:scale-[0.98]"
              onClick={() => navigate('/deals')}
            >
              <div className="flex items-center gap-3">
                <Target className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                <span className="text-sm text-gray-700 dark:text-gray-300">New Deals</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-gray-900 dark:text-white">
                  {timeTrends.dealsThisWeek}
                </span>
                <ArrowRight size={14} className="text-gray-400 dark:text-gray-500" />
              </div>
            </div>

            <div 
              className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors active:scale-[0.98]"
              onClick={() => navigate('/deals')}
            >
              <div className="flex items-center gap-3">
                <DollarSign className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                <span className="text-sm text-gray-700 dark:text-gray-300">Revenue</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-gray-900 dark:text-white">
                  {formatCurrency(timeTrends.revenueThisWeek)}
                </span>
                <ArrowRight size={14} className="text-gray-400 dark:text-gray-500" />
              </div>
            </div>
          </div>
        </Card>

        <Card title="This Month" subtitle="Activity in the current month - Click to view">
          <div className="space-y-4 mt-4">
            <div 
              className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors active:scale-[0.98]"
              onClick={() => navigate('/leads')}
            >
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                <span className="text-sm text-gray-700 dark:text-gray-300">New Leads</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-gray-900 dark:text-white">
                  {timeTrends.leadsThisMonth}
                </span>
                <ArrowRight size={14} className="text-gray-400 dark:text-gray-500" />
              </div>
            </div>

            <div 
              className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors active:scale-[0.98]"
              onClick={() => navigate('/deals')}
            >
              <div className="flex items-center gap-3">
                <Target className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                <span className="text-sm text-gray-700 dark:text-gray-300">New Deals</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-gray-900 dark:text-white">
                  {timeTrends.dealsThisMonth}
                </span>
                <ArrowRight size={14} className="text-gray-400 dark:text-gray-500" />
              </div>
            </div>

            <div 
              className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors active:scale-[0.98]"
              onClick={() => navigate('/deals')}
            >
              <div className="flex items-center gap-3">
                <DollarSign className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                <span className="text-sm text-gray-700 dark:text-gray-300">Revenue</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-gray-900 dark:text-white">
                  {formatCurrency(timeTrends.revenueThisMonth)}
                </span>
                <ArrowRight size={14} className="text-gray-400 dark:text-gray-500" />
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Performance Metrics */}
      <Card title="Performance Metrics" subtitle="Key performance indicators">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-green-600 dark:text-green-400" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Avg Deal Value</span>
            </div>
            <p className="text-xl font-bold text-gray-900 dark:text-white">
              {metrics.totalDeals > 0 
                ? formatCurrency(metrics.totalRevenue / metrics.totalDeals)
                : formatCurrency(0)}
            </p>
          </div>

          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Percent className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Payment Collection</span>
            </div>
            <p className="text-xl font-bold text-gray-900 dark:text-white">
              {metrics.totalRevenue > 0 
                ? `${((metrics.totalPaid / metrics.totalRevenue) * 100).toFixed(1)}%`
                : '0%'}
            </p>
          </div>

          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Lead to Deal</span>
            </div>
            <p className="text-xl font-bold text-gray-900 dark:text-white">
              {metrics.totalLeads > 0 
                ? `${((metrics.totalDeals / metrics.totalLeads) * 100).toFixed(1)}%`
                : '0%'}
            </p>
          </div>

          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-4 h-4 text-orange-600 dark:text-orange-400" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Active Deals</span>
            </div>
            <p className="text-xl font-bold text-gray-900 dark:text-white">
              {dealStatusDistribution.find(d => d.label === 'Active')?.count || 0}
            </p>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
};

export default Analytics;
