import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  TrendingUp,
  Users,
  UserPlus,
  CheckCircle,
  Clock,
  AlertCircle,
  Phone,
  Calendar,
  MapPin,
  Target,
  DollarSign,
  Plus,
  Zap,
  ChevronRight,
  Check,
  X,
  Flame,
} from 'lucide-react';
import PageContainer from '../components/layout/PageContainer';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import EmptyState from '../components/ui/EmptyState';
import { FloatingActionButton } from '../components/layout';
import { subscribeToLeads } from '../services/leadsService';
import { subscribeToDeals } from '../services/dealsService';
import { subscribeToFollowUps } from '../services/callHistoryService';
import { markFollowUpDone } from '../services/callHistoryService';
import { subscribeToCompanyBalance } from '../services/expenseService';
import BalanceCard from '../components/expenses/BalanceCard';
import { useToast } from '../hooks/useToast';

const Dashboard = () => {
  const navigate = useNavigate();
  const { success, showError } = useToast();
  const [leads, setLeads] = useState([]);
  const [deals, setDeals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [followUpModal, setFollowUpModal] = useState({ isOpen: false, type: null, leads: [] });
  const [todayFollowUps, setTodayFollowUps] = useState([]);
  const [tomorrowFollowUps, setTomorrowFollowUps] = useState([]);
  const [companyBalance, setCompanyBalance] = useState(null);

  // Fetch leads and deals from Firebase
  useEffect(() => {
    const unsubscribeLeads = subscribeToLeads((leadsData) => {
      const processedLeads = leadsData.map(lead => ({
        ...lead,
        createdAt: lead.createdAt?.toDate?.()?.toISOString() || lead.createdAt || new Date().toISOString(),
        updatedAt: lead.updatedAt?.toDate?.()?.toISOString() || lead.updatedAt || new Date().toISOString(),
        nextFollowUp: lead.nextFollowUp?.toDate?.()?.toISOString() || lead.nextFollowUp || null,
      }));
      setLeads(processedLeads);
      setLoading(false);
    });

    const unsubscribeDeals = subscribeToDeals((dealsData) => {
      const processedDeals = dealsData.map(deal => ({
        ...deal,
        createdAt: deal.createdAt?.toDate?.()?.toISOString() || deal.createdAt || new Date().toISOString(),
        updatedAt: deal.updatedAt?.toDate?.()?.toISOString() || deal.updatedAt || new Date().toISOString(),
        paymentHistory: deal.paymentHistory?.map(payment => ({
          ...payment,
          timestamp: payment.timestamp?.toDate?.()?.toISOString() || payment.timestamp || new Date().toISOString(),
        })) || [],
      }));
      setDeals(processedDeals);
    }, { status: 'active' });

    // Subscribe to today's follow-ups
    const unsubscribeToday = subscribeToFollowUps((followUpsData) => {
      const processed = followUpsData.map(fu => ({
        ...fu,
        nextFollowUp: fu.nextFollowUp?.toDate?.()?.toISOString() || fu.nextFollowUp || null,
        lastCallDate: fu.lastCallDate?.toDate?.()?.toISOString() || fu.lastCallDate || null,
      }));
      setTodayFollowUps(processed);
    }, 'today');

    // Subscribe to tomorrow's follow-ups
    const unsubscribeTomorrow = subscribeToFollowUps((followUpsData) => {
      const processed = followUpsData.map(fu => ({
        ...fu,
        nextFollowUp: fu.nextFollowUp?.toDate?.()?.toISOString() || fu.nextFollowUp || null,
        lastCallDate: fu.lastCallDate?.toDate?.()?.toISOString() || fu.lastCallDate || null,
      }));
      setTomorrowFollowUps(processed);
    }, 'tomorrow');

    // Subscribe to company balance
    const unsubscribeBalance = subscribeToCompanyBalance((balanceData) => {
      setCompanyBalance(balanceData);
    });

    return () => {
      unsubscribeLeads();
      unsubscribeDeals();
      unsubscribeToday();
      unsubscribeTomorrow();
      unsubscribeBalance();
    };
  }, []);

  // Helper functions
  const formatTime = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
  };


  const getTimeUntil = (dateString) => {
    if (!dateString) return '';
    const now = new Date();
    const followUp = new Date(dateString);
    const diffMs = followUp - now;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    if (diffMs < 0) {
      const diffDays = Math.ceil(Math.abs(diffMs) / (1000 * 60 * 60 * 24));
      return diffDays === 1 ? '1 day ago' : `${diffDays} days ago`;
    }
    if (diffHours < 1) return `In ${diffMins} min`;
    if (diffHours < 2) return `In ${diffHours} hour`;
    return `In ${diffHours} hours`;
  };

  // Categorize follow-ups (for "This Week" section - using leads with nextFollowUp)
  const followUps = useMemo(() => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const nextWeek = new Date(now);
    nextWeek.setDate(nextWeek.getDate() + 7);

    const overdue = [];
    const thisWeek = [];

    leads.forEach(lead => {
      if (!lead.nextFollowUp) return;

      const followUp = new Date(lead.nextFollowUp);
      followUp.setHours(0, 0, 0, 0);

      if (followUp < now) {
        overdue.push(lead);
      } else if (followUp <= nextWeek && followUp.getTime() !== now.getTime() && followUp.getTime() !== tomorrow.getTime()) {
        thisWeek.push(lead);
      }
    });

    return { overdue, today: todayFollowUps, tomorrow: tomorrowFollowUps, thisWeek };
  }, [leads, todayFollowUps, tomorrowFollowUps]);

  // Calculate work days left for deals
  const workDaysWarnings = useMemo(() => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);

    const overdue = [];
    const urgent = []; // 0-3 days left
    const warning = []; // 4-7 days left

    deals.forEach(deal => {
      if (!deal.completionDays || !deal.createdAt) return;

      const createdDate = new Date(deal.createdAt);
      const completionDate = new Date(createdDate);
      completionDate.setDate(completionDate.getDate() + parseInt(deal.completionDays));
      completionDate.setHours(0, 0, 0, 0);

      const diffTime = completionDate - now;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays < 0) {
        overdue.push({ ...deal, daysLeft: diffDays });
      } else if (diffDays <= 3) {
        urgent.push({ ...deal, daysLeft: diffDays });
      } else if (diffDays <= 7) {
        warning.push({ ...deal, daysLeft: diffDays });
      }
    });

    return { overdue, urgent, warning };
  }, [deals]);

  // Calculate stats
  const stats = useMemo(() => {
    const newLeads = leads.filter(l => l.status === 'new').length;
    const activeLeads = leads.filter(l => ['interested', 'scheduled'].includes(l.status)).length;
    const converted = leads.filter(l => l.status === 'converted').length;
    const totalRevenue = deals.reduce((sum, deal) => sum + (deal.paidAmount || 0), 0);

    return {
      new: newLeads,
      active: activeLeads,
      done: converted,
      revenue: totalRevenue,
    };
  }, [leads, deals]);

  // Calculate call status stats
  const callStatusStats = useMemo(() => {
    const interested = leads.filter(l => l.callStatus === 'Interested').length;
    const notInterested = leads.filter(l => l.callStatus === 'Not Interested').length;
    const noAnswer = leads.filter(l => l.callStatus === 'No Answer').length;
    const callBack = leads.filter(l => l.callStatus === 'Call Back').length;
    const busy = leads.filter(l => l.callStatus === 'Busy').length;
    const switchOff = leads.filter(l => l.callStatus === 'Switch Off').length;

    return {
      interested,
      notInterested,
      noAnswer,
      callBack,
      busy,
      switchOff,
    };
  }, [leads]);

  // Active clients with payment info
  const activeClients = useMemo(() => {
    return deals
      .filter(deal => deal.status === 'active')
      .map(deal => ({
        ...deal,
        progress: deal.totalAmount > 0 ? ((deal.paidAmount || 0) / deal.totalAmount) * 100 : 0,
        isFullyPaid: (deal.paidAmount || 0) >= (deal.totalAmount || 0),
        hasPartial: (deal.paidAmount || 0) > 0 && (deal.paidAmount || 0) < (deal.totalAmount || 0),
      }))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .slice(0, 10);
  }, [deals]);

  const clientStats = useMemo(() => {
    const fullyPaid = activeClients.filter(c => c.isFullyPaid).length;
    const partial = activeClients.filter(c => c.hasPartial).length;
    const notStarted = activeClients.filter(c => !c.hasPartial && !c.isFullyPaid).length;
    const totalPending = activeClients.reduce((sum, c) => sum + (c.pendingAmount || 0), 0);
    const totalNotStarted = activeClients
      .filter(c => !c.hasPartial && !c.isFullyPaid)
      .reduce((sum, c) => sum + (c.totalAmount || 0), 0);

    return { fullyPaid, partial, notStarted, totalPending, totalNotStarted };
  }, [activeClients]);

  const handleMarkDone = async (lead) => {
    if (window.confirm('Mark this follow-up as done and convert to deal?')) {
      try {
        await markFollowUpDone(lead.id || lead, null);
        success('Follow-up marked as done! Opening deal form...');
        // Navigate directly to deal conversion form for this lead
        const leadId = typeof lead === 'string' ? lead : lead.id;
        navigate(`/deals/convert/${leadId}`);
      } catch (error) {
        console.error('Error marking follow-up:', error);
        showError('Failed to mark follow-up as done');
      }
    }
  };

  const handleCall = (phone) => {
    window.location.href = `tel:${phone.replace(/\D/g, '')}`;
  };

  const openFollowUpModal = (type) => {
    const leadsList = type === 'today' ? todayFollowUps : tomorrowFollowUps;
    setFollowUpModal({ isOpen: true, type, leads: leadsList });
  };

  const closeFollowUpModal = () => {
    setFollowUpModal({ isOpen: false, type: null, leads: [] });
  };

  // Follow-up Card Component
  const FollowUpCard = ({ lead, variant = 'default' }) => {
    const followUpDate = new Date(lead.nextFollowUp);
    const timeStr = formatTime(lead.nextFollowUp);
    const timeUntil = getTimeUntil(lead.nextFollowUp);
    const isOverdue = followUpDate < new Date();
    const isUrgent = !isOverdue && (followUpDate - new Date()) < 2 * 60 * 60 * 1000; // Within 2 hours

    const borderColor = isOverdue
      ? 'border-red-500 dark:border-red-600'
      : isUrgent
      ? 'border-yellow-500 dark:border-yellow-600'
      : variant === 'tomorrow'
      ? 'border-green-500 dark:border-green-600'
      : 'border-blue-500 dark:border-blue-600';

    const bgColor = isOverdue
      ? 'bg-red-50 dark:bg-red-900/20'
      : isUrgent
      ? 'bg-yellow-50 dark:bg-yellow-900/20'
      : variant === 'tomorrow'
      ? 'bg-green-50 dark:bg-green-900/20'
      : 'bg-blue-50 dark:bg-blue-900/20';

    return (
      <div
        className={`min-w-[140px] sm:min-w-[280px] md:min-w-[320px] rounded-xl border-2 ${borderColor} ${bgColor} p-3 sm:p-4 shadow-sm hover:shadow-md transition-all cursor-pointer`}
        onClick={() => navigate(`/leads/${lead.id}`)}
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            {isOverdue ? (
              <AlertCircle size={18} className="text-red-600 dark:text-red-400" />
            ) : isUrgent ? (
              <Clock size={18} className="text-yellow-600 dark:text-yellow-400" />
            ) : (
              <Calendar size={18} className="text-blue-600 dark:text-blue-400" />
            )}
            <span className="text-sm font-semibold text-gray-900 dark:text-white">
              {isOverdue ? `⚠️ ${timeUntil}` : timeStr}
            </span>
          </div>
          {isUrgent && !isOverdue && (
            <Badge variant="warning" size="sm">Urgent</Badge>
          )}
        </div>

        <h3 className="text-sm sm:text-base font-bold text-gray-900 dark:text-white mb-1">
          {lead.name || 'Unknown'}
        </h3>
        <div className="space-y-1 text-[10px] sm:text-xs md:text-sm text-gray-600 dark:text-gray-400 mb-2 sm:mb-3">
          <div className="flex items-center gap-1">
            <Phone size={10} className="sm:w-3 sm:h-3" />
            <span className="truncate">{lead.phone}</span>
          </div>
          {lead.meetingLocation && (
            <div className="flex items-center gap-1">
              <MapPin size={12} />
              <span>
                {lead.meetingLocation === 'office' ? 'Our Office' : 'Client Place'}
              </span>
            </div>
          )}
          {lead.services && lead.services.length > 0 && (
            <div className="flex items-center gap-1 flex-wrap">
              <Target size={12} />
              <span>{lead.services.join(', ')}</span>
            </div>
          )}
        </div>

        {lead.notes && (
          <div className="mb-3 p-2 bg-white/50 dark:bg-gray-800/50 rounded text-xs text-gray-700 dark:text-gray-300">
            <span className="font-medium">📝 </span>
            {lead.notes.substring(0, 50)}
            {lead.notes.length > 50 && '...'}
          </div>
        )}

        <div className="flex items-center gap-2 mt-3">
          <Button
            size="sm"
            variant="outline"
            onClick={(e) => {
              e.stopPropagation();
              handleCall(lead.phone);
            }}
            className="flex-1 text-xs"
          >
            📞 Call
          </Button>
          <Button
            size="sm"
            variant="primary"
            onClick={(e) => {
              e.stopPropagation();
              handleMarkDone(lead);
            }}
            className="flex-1 text-xs"
          >
            ✓ Done & Convert
          </Button>
        </div>
      </div>
    );
  };

  // Active Client Card Component
  const ActiveClientCard = ({ deal }) => {
    return (
      <div
        className="min-w-[120px] sm:min-w-[240px] md:min-w-[280px] rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-3 sm:p-4 shadow-sm hover:shadow-md transition-all cursor-pointer"
        onClick={() => navigate(`/deals/${deal.id}`)}
      >
        <h3 className="font-bold text-gray-900 dark:text-white mb-1">
          {deal.customerName}
        </h3>
        <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
          Deal #{deal.dealId || deal.id.substring(0, 8)}
        </p>

        {deal.services && deal.services.length > 0 && (
          <div className="mb-3">
            <div className="flex items-center gap-1 flex-wrap">
              <Target size={12} className="text-gray-500" />
              <span className="text-xs text-gray-600 dark:text-gray-400">
                {deal.services.join(' • ')}
              </span>
            </div>
          </div>
        )}

        <div className="space-y-2 mb-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600 dark:text-gray-400">Total:</span>
            <span className="font-bold text-gray-900 dark:text-white">
              ₹{deal.totalAmount?.toLocaleString('en-IN') || '0'}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600 dark:text-gray-400">Paid:</span>
            <span className="font-bold text-green-600 dark:text-green-400">
              ₹{deal.paidAmount?.toLocaleString('en-IN') || '0'} ({Math.round(deal.progress)}%)
            </span>
          </div>
          <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-green-500 to-green-600 rounded-full transition-all"
              style={{ width: `${deal.progress}%` }}
            />
          </div>
          {deal.pendingAmount > 0 && (
            <div className="flex justify-between text-xs">
              <span className="text-gray-500 dark:text-gray-400">Pending:</span>
              <span className="font-semibold text-orange-600 dark:text-orange-400">
                ₹{deal.pendingAmount?.toLocaleString('en-IN') || '0'}
              </span>
            </div>
          )}
        </div>

        <Button
          size="sm"
          variant="outline"
          fullWidth
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/deals/${deal.id}`);
          }}
        >
          View Deal
        </Button>
      </div>
    );
  };

  if (loading) {
    return (
      <PageContainer title="Dashboard" subtitle="Loading...">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </PageContainer>
    );
  }

  return (
    <>
      <PageContainer
        title="Dashboard"
        subtitle="Welcome back! Here's what needs your attention today."
      >
        <div className="space-y-6 pb-24">
          {/* OVERDUE FOLLOW-UPS - Priority Alert */}
          {followUps.overdue.length > 0 && (
            <Card className="border-2 border-red-500 dark:border-red-600 bg-red-50 dark:bg-red-900/20 animate-slide-up">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <AlertCircle size={20} className="text-red-600 dark:text-red-400" />
                  <h2 className="text-lg font-bold text-red-900 dark:text-red-100">
                    ⚠️ OVERDUE FOLLOW-UPS ({followUps.overdue.length})
                  </h2>
                </div>
                <button
                  onClick={() => navigate('/leads')}
                  className="text-sm text-red-700 dark:text-red-300 hover:underline flex items-center gap-1"
                >
                  View All <ChevronRight size={16} />
                </button>
              </div>
              <div className="overflow-x-auto pb-2 -mx-2 px-2">
                <div className="flex gap-3">
                  {followUps.overdue.map((lead) => (
                    <FollowUpCard key={lead.id} lead={lead} variant="overdue" />
                  ))}
                </div>
              </div>
            </Card>
          )}

          {/* TODAY & TOMORROW FOLLOW-UPS - Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 animate-slide-up" style={{ animationDelay: '100ms' }}>
            {/* TODAY'S FOLLOW-UPS - Metric Card */}
            <Card 
              className="p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98]"
              onClick={() => todayFollowUps.length > 0 && openFollowUpModal('today')}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Clock className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                    <Flame className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Today's Follow-Ups</p>
                  </div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{todayFollowUps.length}</p>
                </div>
                <div className="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
                  <Calendar className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
                </div>
              </div>
            </Card>

            {/* TOMORROW'S FOLLOW-UPS - Metric Card */}
            <Card 
              className="p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98]"
              onClick={() => tomorrowFollowUps.length > 0 && openFollowUpModal('tomorrow')}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Calendar className="w-4 h-4 text-green-600 dark:text-green-400" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Tomorrow's Follow-Ups</p>
                  </div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{tomorrowFollowUps.length}</p>
                </div>
                <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                  <Calendar className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </Card>
          </div>

          {/* CALL STATUS QUICK ACTION CARDS */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 animate-slide-up" style={{ animationDelay: '150ms' }}>
            {/* Interested */}
            <Card 
              className="p-3 sm:p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98] border-2 border-green-500 dark:border-green-600 bg-green-50 dark:bg-green-900/20"
              onClick={() => navigate('/leads')}
            >
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <div className="p-2 sm:p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                    <Check className="w-4 h-4 sm:w-5 sm:h-5 text-green-600 dark:text-green-400" />
                  </div>
                </div>
                <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 font-medium mb-1">Interested</p>
                <p className="text-xl sm:text-2xl font-bold text-green-900 dark:text-green-100">{callStatusStats.interested}</p>
              </div>
            </Card>

            {/* Not Interested */}
            <Card 
              className="p-3 sm:p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98] border-2 border-red-500 dark:border-red-600 bg-red-50 dark:bg-red-900/20"
              onClick={() => navigate('/leads')}
            >
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <div className="p-2 sm:p-3 bg-red-100 dark:bg-red-900 rounded-lg">
                    <X className="w-4 h-4 sm:w-5 sm:h-5 text-red-600 dark:text-red-400" />
                  </div>
                </div>
                <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 font-medium mb-1">Not Interested</p>
                <p className="text-xl sm:text-2xl font-bold text-red-900 dark:text-red-100">{callStatusStats.notInterested}</p>
              </div>
            </Card>

            {/* No Answer */}
            <Card 
              className="p-3 sm:p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98] border-2 border-gray-500 dark:border-gray-600 bg-gray-50 dark:bg-gray-900/20"
              onClick={() => navigate('/leads')}
            >
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <div className="p-2 sm:p-3 bg-gray-100 dark:bg-gray-900 rounded-lg">
                    <Phone className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600 dark:text-gray-400" />
                  </div>
                </div>
                <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 font-medium mb-1">No Answer</p>
                <p className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-gray-100">{callStatusStats.noAnswer}</p>
              </div>
            </Card>

            {/* Call Back */}
            <Card 
              className="p-3 sm:p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98] border-2 border-yellow-500 dark:border-yellow-600 bg-yellow-50 dark:bg-yellow-900/20"
              onClick={() => navigate('/leads')}
            >
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <div className="p-2 sm:p-3 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
                    <Phone className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-600 dark:text-yellow-400" />
                  </div>
                </div>
                <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 font-medium mb-1">Call Back</p>
                <p className="text-xl sm:text-2xl font-bold text-yellow-900 dark:text-yellow-100">{callStatusStats.callBack}</p>
              </div>
            </Card>

            {/* Busy */}
            <Card 
              className="p-3 sm:p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98] border-2 border-orange-500 dark:border-orange-600 bg-orange-50 dark:bg-orange-900/20"
              onClick={() => navigate('/leads')}
            >
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <div className="p-2 sm:p-3 bg-orange-100 dark:bg-orange-900 rounded-lg">
                    <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-orange-600 dark:text-orange-400" />
                  </div>
                </div>
                <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 font-medium mb-1">Busy</p>
                <p className="text-xl sm:text-2xl font-bold text-orange-900 dark:text-orange-100">{callStatusStats.busy}</p>
              </div>
            </Card>

            {/* Switch Off */}
            <Card 
              className="p-3 sm:p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98] border-2 border-purple-500 dark:border-purple-600 bg-purple-50 dark:bg-purple-900/20"
              onClick={() => navigate('/leads')}
            >
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <div className="p-2 sm:p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
                    <Zap className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600 dark:text-purple-400" />
                  </div>
                </div>
                <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 font-medium mb-1">Switch Off</p>
                <p className="text-xl sm:text-2xl font-bold text-purple-900 dark:text-purple-100">{callStatusStats.switchOff}</p>
              </div>
            </Card>
          </div>

          {/* WORK DAYS WARNINGS - Metric Cards */}
          {(workDaysWarnings.overdue.length > 0 || workDaysWarnings.urgent.length > 0 || workDaysWarnings.warning.length > 0) && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 animate-slide-up" style={{ animationDelay: '200ms' }}>
              {/* OVERDUE WORK DAYS */}
              {workDaysWarnings.overdue.length > 0 && (
                <Card 
                  className="p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98] border-2 border-red-500 dark:border-red-600 bg-red-50 dark:bg-red-900/20"
                  onClick={() => navigate('/deals')}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
                        <p className="text-sm text-gray-700 dark:text-gray-300 font-semibold">Overdue Work</p>
                      </div>
                      <p className="text-2xl font-bold text-red-900 dark:text-red-100">{workDaysWarnings.overdue.length}</p>
                    </div>
                    <div className="p-3 bg-red-100 dark:bg-red-900 rounded-lg">
                      <AlertCircle className="w-6 h-6 text-red-600 dark:text-red-400" />
                    </div>
                  </div>
                </Card>
              )}

              {/* URGENT WORK DAYS (0-3 days left) */}
              {workDaysWarnings.urgent.length > 0 && (
                <Card 
                  className="p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98] border-2 border-orange-500 dark:border-orange-600 bg-orange-50 dark:bg-orange-900/20"
                  onClick={() => navigate('/deals')}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Clock className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                        <p className="text-sm text-gray-700 dark:text-gray-300 font-semibold">Urgent (0-3 days)</p>
                      </div>
                      <p className="text-2xl font-bold text-orange-900 dark:text-orange-100">{workDaysWarnings.urgent.length}</p>
                    </div>
                    <div className="p-3 bg-orange-100 dark:bg-orange-900 rounded-lg">
                      <Clock className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                    </div>
                  </div>
                </Card>
              )}

              {/* WARNING WORK DAYS (4-7 days left) */}
              {workDaysWarnings.warning.length > 0 && (
                <Card 
                  className="p-4 cursor-pointer hover:shadow-lg transition-all duration-200 active:scale-[0.98] border-2 border-yellow-500 dark:border-yellow-600 bg-yellow-50 dark:bg-yellow-900/20"
                  onClick={() => navigate('/deals')}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <AlertCircle className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                        <p className="text-sm text-gray-700 dark:text-gray-300 font-semibold">Warning (4-7 days)</p>
                      </div>
                      <p className="text-2xl font-bold text-yellow-900 dark:text-yellow-100">{workDaysWarnings.warning.length}</p>
                    </div>
                    <div className="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
                      <AlertCircle className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
                    </div>
                  </div>
                </Card>
              )}
            </div>
          )}

          {/* COMPANY BALANCE */}
          {companyBalance && (
            <div className="animate-slide-up" style={{ animationDelay: '250ms' }}>
              <BalanceCard
                balance={companyBalance}
                onClick={() => navigate('/expenses')}
              />
            </div>
          )}

          {/* ACTIVE CLIENTS */}
          <Card className="animate-slide-up" style={{ animationDelay: '300ms' }}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <DollarSign size={20} className="text-blue-600 dark:text-blue-400" />
                <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                  💼 ACTIVE CLIENTS ({activeClients.length})
                </h2>
              </div>
              <button
                onClick={() => navigate('/deals')}
                className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1"
              >
                View All <ChevronRight size={16} />
              </button>
            </div>

            {/* Status Breakdown */}
            <div className="mb-4 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-700 dark:text-gray-300">✅ Fully Paid:</span>
                    <span className="font-semibold text-gray-900 dark:text-white">
                      {clientStats.fullyPaid} clients
                    </span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-green-500 rounded-full"
                      style={{ width: `${activeClients.length > 0 ? (clientStats.fullyPaid / activeClients.length) * 100 : 0}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-700 dark:text-gray-300">💰 Partial:</span>
                    <span className="font-semibold text-gray-900 dark:text-white">
                      {clientStats.partial} clients
                    </span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-yellow-500 rounded-full"
                      style={{ width: `${activeClients.length > 0 ? (clientStats.partial / activeClients.length) * 100 : 0}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Pending: ₹{clientStats.totalPending.toLocaleString('en-IN')}
                  </p>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-700 dark:text-gray-300">⏳ Not Started:</span>
                    <span className="font-semibold text-gray-900 dark:text-white">
                      {clientStats.notStarted} clients
                    </span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gray-400 rounded-full"
                      style={{ width: `${activeClients.length > 0 ? (clientStats.notStarted / activeClients.length) * 100 : 0}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Total: ₹{clientStats.totalNotStarted.toLocaleString('en-IN')}
                  </p>
                </div>
              </div>
            </div>

            {/* Recent Active Clients */}
            {activeClients.length > 0 ? (
              <div className="overflow-x-auto pb-2 -mx-2 px-2">
                <div className="flex gap-3">
                  {activeClients.map((deal) => (
                    <ActiveClientCard key={deal.id} deal={deal} />
                  ))}
                </div>
              </div>
            ) : (
              <EmptyState
                title="No active clients"
                description="Convert leads to see active clients here"
                icon={Users}
              />
            )}
          </Card>

          {/* QUICK STATS */}
          <Card title="📊 QUICK OVERVIEW" className="animate-slide-up" style={{ animationDelay: '400ms' }}>
            <div className="grid grid-cols-2 gap-4">
              <div 
                className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800 cursor-pointer hover:shadow-md transition-all duration-200 active:scale-[0.98]"
                onClick={() => navigate('/leads?status=new')}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">New</span>
                </div>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.new}</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp size={12} className="text-green-600" />
                  <span className="text-xs text-green-600">+3 ↑</span>
                </div>
              </div>

              <div 
                className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800 cursor-pointer hover:shadow-md transition-all duration-200 active:scale-[0.98]"
                onClick={() => navigate('/leads?status=active')}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Active</span>
                </div>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.active}</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp size={12} className="text-green-600" />
                  <span className="text-xs text-green-600">+5 ↑</span>
                </div>
              </div>

              <div 
                className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800 cursor-pointer hover:shadow-md transition-all duration-200 active:scale-[0.98]"
                onClick={() => navigate('/leads?status=converted')}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Done</span>
                </div>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.done}</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp size={12} className="text-green-600" />
                  <span className="text-xs text-green-600">+2 ↑</span>
                </div>
              </div>

              <div 
                className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800 cursor-pointer hover:shadow-md transition-all duration-200 active:scale-[0.98]"
                onClick={() => navigate('/deals')}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Revenue</span>
                </div>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  ₹{(stats.revenue / 100000).toFixed(1)}L
                </p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp size={12} className="text-green-600" />
                  <span className="text-xs text-green-600">+3L ↑</span>
                </div>
              </div>
            </div>
          </Card>

          {/* UPCOMING THIS WEEK */}
          {followUps.thisWeek.length > 0 && (
            <Card className="animate-slide-up" style={{ animationDelay: '500ms' }}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <Calendar size={16} className="text-blue-600 dark:text-blue-400 sm:w-5 sm:h-5" />
                  <h2 className="text-sm sm:text-base font-bold text-gray-900 dark:text-white">
                    📅 UPCOMING THIS WEEK ({followUps.thisWeek.length})
                  </h2>
                </div>
                <button
                  onClick={() => navigate('/leads')}
                  className="text-xs sm:text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-0.5 sm:gap-1"
                >
                  <span className="hidden sm:inline">View All</span>
                  <span className="sm:hidden">All</span>
                  <ChevronRight size={14} className="sm:w-4 sm:h-4" />
                </button>
              </div>
              <div className="space-y-1.5 sm:space-y-2">
                {Object.entries(
                  followUps.thisWeek.reduce((acc, lead) => {
                    const date = new Date(lead.nextFollowUp);
                    const dateKey = date.toLocaleDateString('en-IN', {
                      weekday: 'short',
                      day: 'numeric',
                      month: 'short',
                    });
                    if (!acc[dateKey]) acc[dateKey] = [];
                    acc[dateKey].push(lead);
                    return acc;
                  }, {})
                ).map(([date, leads]) => (
                  <div key={date} className="p-2 sm:p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
                    <p className="text-xs sm:text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5 sm:mb-2">
                      📅 {date} ({leads.length})
                    </p>
                    <div className="space-y-1 sm:space-y-2">
                      {leads.map((lead) => (
                        <div
                          key={lead.id}
                          onClick={() => navigate(`/leads/${lead.id}`)}
                          className="flex items-center justify-between p-1.5 sm:p-2 bg-white dark:bg-gray-800 rounded hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer"
                        >
                          <div className="flex-1 min-w-0">
                            <p className="text-xs sm:text-sm font-medium text-gray-900 dark:text-white truncate">
                              {lead.name || 'Unknown'}
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              {formatTime(lead.nextFollowUp)}
                            </p>
                          </div>
                          <ChevronRight size={14} className="text-gray-400 flex-shrink-0 ml-2 sm:w-4 sm:h-4" />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* QUICK ACTIONS */}
          <Card title="⚡ QUICK ACTIONS" className="animate-slide-up" style={{ animationDelay: '600ms' }}>
            <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="primary"
                  fullWidth
                  icon={<Plus size={16} />}
                onClick={() => navigate('/leads/new')}
                className="py-4"
              >
                ➕ Add Lead
              </Button>
              <Button
                variant="outline"
                fullWidth
                icon={<Phone size={16} />}
                onClick={() => navigate('/leads')}
                className="py-4"
              >
                📞 Call Lead
              </Button>
              <Button
                variant="outline"
                fullWidth
                icon={<DollarSign size={16} />}
                onClick={() => navigate('/deals')}
                className="py-4"
              >
                💰 Record Payment
              </Button>
              <Button
                variant="outline"
                fullWidth
                icon={<Target size={16} />}
                onClick={() => navigate('/analytics')}
                className="py-4"
              >
                📄 Analytics
              </Button>
            </div>
          </Card>
        </div>
      </PageContainer>

      {/* Floating Action Button */}
      <FloatingActionButton
        icon={Plus}
        onClick={() => navigate('/leads/new')}
        label="Add Lead"
      />

      {/* Follow-Up List Modal */}
      <Modal
        isOpen={followUpModal.isOpen}
        onClose={closeFollowUpModal}
        title={followUpModal.type === 'today' ? "Today's Follow-Ups" : "Tomorrow's Follow-Ups"}
        size="xl"
      >
        {followUpModal.leads.length === 0 ? (
          <EmptyState
            title={`No follow-ups scheduled ${followUpModal.type === 'today' ? 'today' : 'tomorrow'}! 🎉`}
            description={`You're all caught up for ${followUpModal.type === 'today' ? 'today' : 'tomorrow'}.`}
            icon={CheckCircle}
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {followUpModal.leads.map((lead) => {
              const followUpDate = new Date(lead.nextFollowUp);
              const timeStr = formatTime(lead.nextFollowUp);
              const isOverdue = followUpDate < new Date();
              const isUrgent = !isOverdue && (followUpDate - new Date()) < 2 * 60 * 60 * 1000;

              return (
                <div
                  key={lead.id}
                  className="p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer"
                  onClick={() => {
                    closeFollowUpModal();
                    navigate(`/leads/${lead.id}`);
                  }}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <Clock size={14} className="text-gray-500 dark:text-gray-400" />
                      <span className="text-xs font-medium text-gray-700 dark:text-gray-300">
                        {timeStr}
                      </span>
                      {isUrgent && (
                        <Badge variant="warning" size="sm">Urgent</Badge>
                      )}
                      {isOverdue && (
                        <Badge variant="danger" size="sm">Overdue</Badge>
                      )}
                    </div>
                  </div>

                  <h3 className="font-semibold text-sm text-gray-900 dark:text-white mb-1.5">
                    {lead.name || 'Unknown'}
                  </h3>

                  <div className="space-y-1 text-xs text-gray-600 dark:text-gray-400">
                    {lead.phone && (
                      <div className="flex items-center gap-1.5">
                        <Phone size={12} />
                        <span>{lead.phone}</span>
                      </div>
                    )}
                    {lead.lastRemark && (
                      <div className="flex items-center gap-1.5">
                        <span className="line-clamp-2">{lead.lastRemark}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 mt-2.5">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCall(lead.phone);
                      }}
                      className="flex-1 text-xs py-1.5"
                    >
                      <Phone size={12} className="mr-1" />
                      Call
                    </Button>
                    <Button
                      size="sm"
                      variant="primary"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleMarkDone(lead);
                        if (followUpModal.leads.length === 1) {
                          closeFollowUpModal();
                        }
                      }}
                      className="flex-1 text-xs py-1.5"
                    >
                      <Check size={12} className="mr-1" />
                      Done & Convert
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Modal>
    </>
  );
};

export default Dashboard;
