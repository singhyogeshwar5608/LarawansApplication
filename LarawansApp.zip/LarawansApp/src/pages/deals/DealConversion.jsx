import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ChevronRight, ChevronDown, Eye, EyeOff, Copy, Check } from 'lucide-react';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import Textarea from '../../components/ui/Textarea';
import Checkbox from '../../components/ui/Checkbox';
import { RadioGroup } from '../../components/ui/Radio';
import Card from '../../components/ui/Card';
import { useToast } from '../../hooks/useToast';
import { subscribeToLead } from '../../services/leadsService';
import { createDeal } from '../../services/dealsService';

const DealConversion = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { success, error: showError } = useToast();
  const [lead, setLead] = useState(null);
  const [loadingLead, setLoadingLead] = useState(true);

  // Fetch lead from Firebase
  useEffect(() => {
    if (!id) return;

    const unsubscribe = subscribeToLead(id, (leadData) => {
      if (leadData) {
        setLead({
          ...leadData,
          name: leadData.name || 'Unknown',
          phone: leadData.phone || '',
          services: leadData.services || [],
        });
        setLoadingLead(false);
      } else {
        showError('Lead not found');
        navigate('/leads');
      }
    });

    return () => unsubscribe();
  }, [id, navigate, showError]);

  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [showPasswords, setShowPasswords] = useState({});
  const [expandedSections, setExpandedSections] = useState({
    metaAds: true,
    website: true,
    marketplace: true,
    others: true,
  });

  // Always start at step 1 when component mounts or lead ID changes
  useEffect(() => {
    setCurrentStep(1);
  }, [id]);

  // Form data
  const [formData, setFormData] = useState({
    // Step 1: Service Configuration
    metaAds: {
      hasAccount: '',
      fbPageUrl: '',
      fbPassword: '',
      instaHandle: '',
      instaPassword: '',
    },
    website: {
      domainName: '',
      hostingProvider: '',
      websiteType: '',
      additionalRequirements: '',
    },
    marketplace: {
      platforms: {
        amazon: false,
        flipkart: false,
        meesho: false,
        others: false,
      },
      othersText: '',
      hasAccount: '',
      accountEmail: '',
      accountPassword: '',
      manualEntry: '',
    },
    others: {
      description: '',
      credentials: '',
    },
    
    // Step 2: Payment
    totalAmount: '',
    advancePayment: '',
    paymentDate: new Date().toISOString().split('T')[0],
    paymentMode: '',
    paymentNotes: '',
    completionDays: '15', // Default 15 days
    
    // Step 3: Facilities
    facilities: [
      'Campaign Setup & Management',
      'Monthly Performance Reports',
      '3 Months Free Support',
    ],
    dealNotes: '',
  });

  const [errors, setErrors] = useState({});

  const hostingProviders = [
    { value: '', label: 'Select hosting provider' },
    { value: 'godaddy', label: 'GoDaddy' },
    { value: 'hostinger', label: 'Hostinger' },
    { value: 'bluehost', label: 'Bluehost' },
    { value: 'other', label: 'Other' },
  ];

  const websiteTypes = [
    { value: '', label: 'Select website type' },
    { value: 'ecommerce', label: 'E-commerce' },
    { value: 'business', label: 'Business' },
    { value: 'portfolio', label: 'Portfolio' },
    { value: 'blog', label: 'Blog' },
    { value: 'custom', label: 'Custom' },
  ];

  const paymentModes = [
    { value: '', label: 'Select payment mode' },
    { value: 'cash', label: 'Cash' },
    { value: 'online', label: 'Online (UPI/Net Banking)' },
    { value: 'card', label: 'Card (Credit/Debit)' },
    { value: 'cheque', label: 'Cheque' },
    { value: 'bank', label: 'Bank Transfer' },
  ];

  const togglePassword = (field) => {
    setShowPasswords(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text);
    success(`${label} copied to clipboard!`);
  };

  const toggleSection = (section) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const validateStep1 = () => {
    const newErrors = {};
    
    // Check if lead has services
    if (!lead.services || lead.services.length === 0) {
      newErrors.noServices = 'Please add services to the lead before creating a deal';
      setErrors(newErrors);
      return false;
    }
    
    if (lead.services && lead.services.includes('Meta Ads')) {
      if (!formData.metaAds.hasAccount) {
        newErrors.metaAdsAccount = 'Please select if client has accounts';
      } else if (formData.metaAds.hasAccount === 'yes') {
        if (!formData.metaAds.fbPageUrl) newErrors.fbPageUrl = 'Facebook page is required';
        if (!formData.metaAds.fbPassword) newErrors.fbPassword = 'Password is required';
        if (!formData.metaAds.instaHandle) newErrors.instaHandle = 'Instagram handle is required';
        if (!formData.metaAds.instaPassword) newErrors.instaPassword = 'Password is required';
      }
    }

    if (lead.services && lead.services.includes('Website')) {
      if (!formData.website.domainName) newErrors.domainName = 'Domain name is required';
      if (!formData.website.hostingProvider) newErrors.hostingProvider = 'Hosting provider is required';
      if (!formData.website.websiteType) newErrors.websiteType = 'Website type is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors = {};
    
    if (!formData.totalAmount) {
      newErrors.totalAmount = 'Total amount is required';
    } else if (parseFloat(formData.totalAmount) <= 0) {
      newErrors.totalAmount = 'Amount must be greater than 0';
    }

    if (!formData.advancePayment) {
      newErrors.advancePayment = 'Advance payment is required';
    } else if (parseFloat(formData.advancePayment) > parseFloat(formData.totalAmount)) {
      newErrors.advancePayment = 'Cannot exceed total amount';
    }

    if (!formData.paymentMode) {
      newErrors.paymentMode = 'Payment mode is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (currentStep === 1 && !validateStep1()) return;
    if (currentStep === 2 && !validateStep2()) return;
    
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };

  const handleSubmit = async () => {
    if (!lead) return;

    setLoading(true);

    try {
      // Prepare service details
      const serviceDetails = {};
      
      if (lead.services && lead.services.includes('Meta Ads')) {
        serviceDetails.metaAds = {
          fbPassword: formData.metaAds.fbPassword || '',
          instaPassword: formData.metaAds.instaPassword || '',
        };
      }
      
      if (lead.services && lead.services.includes('Website')) {
        serviceDetails.website = {
          domainName: formData.website.domainName || '',
          websiteType: formData.website.websiteType || '',
        };
      }

      // Create initial payment record
      const initialPayment = {
        id: `payment_${Date.now()}`,
        amount: parseFloat(formData.advancePayment) || 0,
        mode: formData.paymentMode || '',
        notes: formData.paymentNotes || '',
        timestamp: new Date(formData.paymentDate || new Date()).toISOString(),
      };

      // Calculate amounts
      const totalAmount = parseFloat(formData.totalAmount) || 0;
      const paidAmount = parseFloat(formData.advancePayment) || 0;
      const pendingAmount = totalAmount - paidAmount;

      // Generate deal ID
      const dealId = `#DL-${Date.now().toString().slice(-6)}`;

      // Create deal object
      const dealData = {
        leadId: lead.id,
        customerName: lead.name,
        customerPhone: lead.phone,
        dealId: dealId,
        services: lead.services,
        totalAmount: totalAmount,
        paidAmount: paidAmount,
        pendingAmount: pendingAmount,
        completionDays: parseInt(formData.completionDays) || 15,
        serviceDetails: serviceDetails,
        paymentHistory: paidAmount > 0 ? [initialPayment] : [],
        facilities: formData.facilities || [],
        dealNotes: formData.dealNotes || '',
        status: 'active',
        createdBy: 'You', // In real app, get from auth
      };

      // Create deal in Firebase
      const newDeal = await createDeal(dealData);

      setLoading(false);
      
      // Show success message with balance update info
      if (newDeal.isBalanceUpdated) {
        // Get updated balance to show in message
        try {
          const { getCompanyBalance } = require('../../services/balanceService');
          const balance = await getCompanyBalance();
          success(`Deal created! ₹${totalAmount.toLocaleString('en-IN')} added to balance. New balance: ₹${balance.currentBalance.toLocaleString('en-IN')}`);
        } catch (balanceError) {
          console.error('Error getting balance:', balanceError);
          success(`Deal created! ₹${totalAmount.toLocaleString('en-IN')} added to balance.`);
        }
      } else {
        success('Deal created successfully!');
      }
      
      navigate(`/deals/success/${newDeal.id}`);
    } catch (error) {
      console.error('Error creating deal:', error);
      setLoading(false);
      showError('Failed to create deal. Please try again.');
    }
  };

  const addFacility = () => {
    const facility = prompt('Enter facility name:');
    if (facility) {
      setFormData({
        ...formData,
        facilities: [...formData.facilities, facility],
      });
    }
  };

  const removeFacility = (index) => {
    setFormData({
      ...formData,
      facilities: formData.facilities.filter((_, i) => i !== index),
    });
  };

  const pendingAmount = formData.totalAmount && formData.advancePayment
    ? (parseFloat(formData.totalAmount) - parseFloat(formData.advancePayment)).toFixed(2)
    : '0.00';

  if (loadingLead) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
        <div className="text-gray-500 dark:text-gray-400">Loading lead...</div>
      </div>
    );
  }

  if (!lead) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
        <div className="text-gray-500 dark:text-gray-400">Lead not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-24">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-4 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(`/leads/${id}`)}
            className="p-2 -ml-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <ArrowLeft size={24} className="text-gray-700 dark:text-gray-300" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">
              Create Deal
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {lead.name} • {lead.phone}
            </p>
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="mt-4 flex items-center justify-between">
          {[1, 2, 3].map((step) => (
            <div key={step} className="flex items-center flex-1">
              <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                step <= currentStep 
                  ? 'bg-primary-600 text-white' 
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-500'
              }`}>
                {step}
              </div>
              {step < 3 && (
                <div className={`flex-1 h-1 mx-2 ${
                  step < currentStep 
                    ? 'bg-primary-600' 
                    : 'bg-gray-200 dark:bg-gray-700'
                }`} />
              )}
            </div>
          ))}
        </div>
        <div className="mt-2 flex justify-between text-xs text-gray-600 dark:text-gray-400">
          <span>Services</span>
          <span>Payment</span>
          <span>Finalize</span>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* STEP 1: Service Configuration */}
        {currentStep === 1 && (
          <div className="space-y-4 animate-slide-up">
            {/* Show message if no services selected */}
            {(!lead.services || lead.services.length === 0) && (
              <Card padding="lg">
                <div className="text-center py-8">
                  <p className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    ⚠️ No Services Selected
                  </p>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    This lead doesn't have any services assigned yet.
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mb-6">
                    Please add services to the lead before converting to a deal.
                  </p>
                  {errors.noServices && (
                    <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                      <p className="text-sm text-red-700 dark:text-red-300">{errors.noServices}</p>
                    </div>
                  )}
                  <Button
                    variant="primary"
                    onClick={() => navigate(`/leads/${id}/edit`)}
                  >
                    Edit Lead & Add Services
                  </Button>
                </div>
              </Card>
            )}

            {lead.services && lead.services.includes('Meta Ads') && (
              <Card padding="none">
                <button
                  onClick={() => toggleSection('metaAds')}
                  className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl sm:text-2xl">📱</span>
                    <h3 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-white">
                      META ADS SETUP
                    </h3>
                  </div>
                  {expandedSections.metaAds ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
                </button>

                {expandedSections.metaAds && (
                  <div className="px-6 pb-6 space-y-4">
                    <RadioGroup
                      label="Does client have Facebook/Instagram pages?"
                      name="metaAdsAccount"
                      options={[
                        { value: 'yes', label: 'Yes' },
                        { value: 'no', label: 'No' },
                      ]}
                      value={formData.metaAds.hasAccount}
                      onChange={(value) => setFormData({
                        ...formData,
                        metaAds: { ...formData.metaAds, hasAccount: value }
                      })}
                      error={errors.metaAdsAccount}
                    />

                    {formData.metaAds.hasAccount === 'yes' && (
                      <div className="space-y-4 pl-6 border-l-2 border-primary-200 dark:border-primary-900">
                        <div>
                          <Input
                            label="📘 Facebook Page URL/ID"
                            placeholder="https://facebook.com/page or Page ID"
                            value={formData.metaAds.fbPageUrl}
                            onChange={(e) => setFormData({
                              ...formData,
                              metaAds: { ...formData.metaAds, fbPageUrl: e.target.value }
                            })}
                            error={errors.fbPageUrl}
                          />
                        </div>

                        <div className="relative">
                          <Input
                            label="🔑 Facebook Password"
                            type={showPasswords.fbPassword ? 'text' : 'password'}
                            placeholder="Enter password"
                            value={formData.metaAds.fbPassword}
                            onChange={(e) => setFormData({
                              ...formData,
                              metaAds: { ...formData.metaAds, fbPassword: e.target.value }
                            })}
                            error={errors.fbPassword}
                          />
                          <button
                            type="button"
                            onClick={() => togglePassword('fbPassword')}
                            className="absolute right-3 top-9 text-gray-400 hover:text-gray-600"
                          >
                            {showPasswords.fbPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                          </button>
                        </div>

                        <div>
                          <Input
                            label="📸 Instagram Handle"
                            placeholder="@username"
                            value={formData.metaAds.instaHandle}
                            onChange={(e) => setFormData({
                              ...formData,
                              metaAds: { ...formData.metaAds, instaHandle: e.target.value }
                            })}
                            error={errors.instaHandle}
                          />
                        </div>

                        <div className="relative">
                          <Input
                            label="🔑 Instagram Password"
                            type={showPasswords.instaPassword ? 'text' : 'password'}
                            placeholder="Enter password"
                            value={formData.metaAds.instaPassword}
                            onChange={(e) => setFormData({
                              ...formData,
                              metaAds: { ...formData.metaAds, instaPassword: e.target.value }
                            })}
                            error={errors.instaPassword}
                          />
                          <button
                            type="button"
                            onClick={() => togglePassword('instaPassword')}
                            className="absolute right-3 top-9 text-gray-400 hover:text-gray-600"
                          >
                            {showPasswords.instaPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                          </button>
                        </div>
                      </div>
                    )}

                    {formData.metaAds.hasAccount === 'no' && (
                      <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <div className="flex items-center gap-2 text-green-700 dark:text-green-300">
                          <Check size={20} />
                          <span className="font-medium">Will create new accounts</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </Card>
            )}

            {lead.services && lead.services.includes('Website') && (
              <Card padding="none">
                <button
                  onClick={() => toggleSection('website')}
                  className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl sm:text-2xl">🌐</span>
                    <h3 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-white">
                      WEBSITE DETAILS
                    </h3>
                  </div>
                  {expandedSections.website ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
                </button>

                {expandedSections.website && (
                  <div className="px-6 pb-6 space-y-4">
                    <Input
                      label="🔗 Domain Name"
                      placeholder="example.com"
                      value={formData.website.domainName}
                      onChange={(e) => setFormData({
                        ...formData,
                        website: { ...formData.website, domainName: e.target.value }
                      })}
                      error={errors.domainName}
                    />

                    <Select
                      label="🏢 Hosting Provider"
                      options={hostingProviders}
                      value={formData.website.hostingProvider}
                      onChange={(e) => setFormData({
                        ...formData,
                        website: { ...formData.website, hostingProvider: e.target.value }
                      })}
                      error={errors.hostingProvider}
                    />

                    <Select
                      label="📋 Website Type"
                      options={websiteTypes}
                      value={formData.website.websiteType}
                      onChange={(e) => setFormData({
                        ...formData,
                        website: { ...formData.website, websiteType: e.target.value }
                      })}
                      error={errors.websiteType}
                    />

                    <Textarea
                      label="📝 Additional Requirements"
                      placeholder="Any specific requirements or features..."
                      value={formData.website.additionalRequirements}
                      onChange={(e) => setFormData({
                        ...formData,
                        website: { ...formData.website, additionalRequirements: e.target.value }
                      })}
                      rows={3}
                    />
                  </div>
                )}
              </Card>
            )}
          </div>
        )}

        {/* STEP 2: Payment Details */}
        {currentStep === 2 && (
          <div className="space-y-6 animate-slide-up">
            <Card title="💰 Payment Information" padding="lg">
              <div className="space-y-4">
                <Input
                  label="Total Deal Amount"
                  type="number"
                  placeholder="50000"
                  value={formData.totalAmount}
                  onChange={(e) => setFormData({ ...formData, totalAmount: e.target.value })}
                  error={errors.totalAmount}
                  required
                  icon={<span className="text-gray-500">₹</span>}
                  className="text-lg sm:text-xl md:text-2xl"
                />

                <Input
                  label="Advance Payment"
                  type="number"
                  placeholder="20000"
                  value={formData.advancePayment}
                  onChange={(e) => setFormData({ ...formData, advancePayment: e.target.value })}
                  error={errors.advancePayment}
                  required
                  icon={<span className="text-gray-500">₹</span>}
                />

                <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                  <div className="flex items-center justify-between text-lg font-semibold">
                    <span className="text-gray-700 dark:text-gray-300">⏳ Pending Amount</span>
                    <span className="text-primary-600 dark:text-primary-400">
                      ₹ {pendingAmount}
                    </span>
                  </div>
                </div>
              </div>
            </Card>

            <Card title="💳 First Payment Details" padding="lg">
              <div className="space-y-4">
                <Input
                  label="Payment Date"
                  type="date"
                  value={formData.paymentDate}
                  onChange={(e) => setFormData({ ...formData, paymentDate: e.target.value })}
                  max={new Date().toISOString().split('T')[0]}
                />

                <Select
                  label="Payment Mode"
                  options={paymentModes}
                  value={formData.paymentMode}
                  onChange={(e) => setFormData({ ...formData, paymentMode: e.target.value })}
                  error={errors.paymentMode}
                  required
                />

                <Input
                  label="⏱️ Task Completion Timeframe (Days)"
                  type="number"
                  placeholder="15"
                  value={formData.completionDays}
                  onChange={(e) => setFormData({ ...formData, completionDays: e.target.value })}
                  min="1"
                  max="365"
                  helpText="Expected number of days to complete the task"
                />

                <Textarea
                  label="📝 Payment Notes"
                  placeholder="Any notes about this payment..."
                  value={formData.paymentNotes}
                  onChange={(e) => setFormData({ ...formData, paymentNotes: e.target.value })}
                  rows={3}
                />
              </div>
            </Card>
          </div>
        )}

        {/* STEP 3: Facilities & Finalize */}
        {currentStep === 3 && (
          <div className="space-y-6 animate-slide-up">
            <Card title="📋 Facilities Provided" padding="lg">
              <div className="space-y-3">
                {formData.facilities.map((facility, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                  >
                    <span className="text-gray-900 dark:text-white">• {facility}</span>
                    <button
                      onClick={() => removeFacility(index)}
                      className="text-red-600 hover:text-red-700 dark:text-red-400"
                    >
                      Remove
                    </button>
                  </div>
                ))}

                <Button
                  type="button"
                  variant="outline"
                  fullWidth
                  onClick={addFacility}
                >
                  + Add Facility
                </Button>
              </div>
            </Card>

            <Card title="📝 Additional Notes" padding="lg">
              <Textarea
                placeholder="Any deal-specific notes, terms, conditions..."
                value={formData.dealNotes}
                onChange={(e) => setFormData({ ...formData, dealNotes: e.target.value })}
                rows={4}
              />
            </Card>

            <Card title="📄 Deal Summary" padding="lg">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Customer:</span>
                  <span className="font-semibold text-gray-900 dark:text-white">{lead.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Services:</span>
                  <span className="font-semibold text-gray-900 dark:text-white">
                    {lead.services.join(', ')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Total:</span>
                  <span className="font-semibold text-gray-900 dark:text-white">
                    ₹ {formData.totalAmount || '0'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Paid:</span>
                  <span className="font-semibold text-green-600 dark:text-green-400">
                    ₹ {formData.advancePayment || '0'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Pending:</span>
                  <span className="font-semibold text-orange-600 dark:text-orange-400">
                    ₹ {pendingAmount}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Facilities:</span>
                  <span className="font-semibold text-gray-900 dark:text-white">
                    {formData.facilities.length} items
                  </span>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg">
        <div className="max-w-2xl mx-auto flex gap-3">
          {currentStep > 1 && (
            <Button
              type="button"
              variant="outline"
              onClick={handlePrevious}
              className="flex-1"
            >
              Previous
            </Button>
          )}
          {currentStep < 3 ? (
            <Button
              type="button"
              variant="primary"
              onClick={handleNext}
              className="flex-1"
            >
              Next: {currentStep === 1 ? 'Payment Details' : 'Facilities'} →
            </Button>
          ) : (
            <Button
              type="button"
              variant="primary"
              onClick={handleSubmit}
              loading={loading}
              className="flex-1"
            >
              💾 Create Deal
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default DealConversion;

