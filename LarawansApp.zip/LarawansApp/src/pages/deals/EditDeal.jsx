import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Save, Eye, EyeOff, Copy } from 'lucide-react';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import Card from '../../components/ui/Card';
import { useToast } from '../../hooks/useToast';
import { subscribeToDeal, updateDeal } from '../../services/dealsService';

const EditDeal = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { success, error: showError } = useToast();
  const [loading, setLoading] = useState(false);
  const [loadingDeal, setLoadingDeal] = useState(true);
  const [showPasswords, setShowPasswords] = useState({});

  const [formData, setFormData] = useState({
    customerName: 'Rajesh Kumar',
    customerPhone: '+91-98765-43212',
    services: ['Meta Ads', 'Website'],
    totalAmount: 50000,
    metaAds: {
      fbPassword: 'fb_pass_123',
      instaPassword: 'insta_pass_456',
    },
    website: {
      domainName: 'clientsite.com',
      websiteType: 'E-commerce',
    },
    facilities: [
      'Facebook Ad Campaign Setup',
      'Instagram Ads Management',
      'Monthly Performance Reports',
      'Responsive Website Design',
      '3 Months Free Support',
    ],
    dealNotes: 'Very interested client. Follow up for website design approval.',
  });

  const websiteTypes = [
    { value: '', label: 'Select website type' },
    { value: 'ecommerce', label: 'E-commerce' },
    { value: 'business', label: 'Business' },
    { value: 'portfolio', label: 'Portfolio' },
    { value: 'blog', label: 'Blog' },
    { value: 'other', label: 'Other' },
  ];

  const togglePassword = (field) => {
    setShowPasswords(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text);
    success(`${label} copied!`);
  };

  // Fetch deal from Firebase
  useEffect(() => {
    if (!id) return;

    const unsubscribe = subscribeToDeal(id, (dealData) => {
      if (dealData) {
        const serviceDetails = dealData.serviceDetails || {};
        
        setFormData({
          customerName: dealData.customerName || '',
          customerPhone: dealData.customerPhone || '',
          services: dealData.services || [],
          totalAmount: dealData.totalAmount || 0,
          metaAds: serviceDetails.metaAds || {
            fbPassword: '',
            instaPassword: '',
          },
          website: serviceDetails.website || {
            domainName: '',
            websiteType: '',
          },
          facilities: dealData.facilities || [],
          dealNotes: dealData.dealNotes || '',
        });
        setLoadingDeal(false);
      } else {
        showError('Deal not found');
        navigate('/deals');
      }
    });

    return () => unsubscribe();
  }, [id, navigate, showError]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!id) return;

    setLoading(true);

    try {
      // Prepare service details
      const serviceDetails = {};
      
      if (formData.services.includes('Meta Ads')) {
        serviceDetails.metaAds = {
          fbPassword: formData.metaAds.fbPassword || '',
          instaPassword: formData.metaAds.instaPassword || '',
        };
      }
      
      if (formData.services.includes('Website')) {
        serviceDetails.website = {
          domainName: formData.website.domainName || '',
          websiteType: formData.website.websiteType || '',
        };
      }

      // Update deal in Firebase
      await updateDeal(id, {
        customerName: formData.customerName.trim(),
        customerPhone: formData.customerPhone.trim(),
        totalAmount: parseFloat(formData.totalAmount) || 0,
        serviceDetails: serviceDetails,
        facilities: formData.facilities || [],
        dealNotes: formData.dealNotes.trim(),
      });

      setLoading(false);
      success('Deal updated successfully!');
      navigate(`/deals/${id}`);
    } catch (error) {
      console.error('Error updating deal:', error);
      setLoading(false);
      showError('Failed to update deal. Please try again.');
    }
  };

  if (loadingDeal) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
        <div className="text-gray-500 dark:text-gray-400">Loading deal...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-24 lg:pb-6">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-4 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(`/deals/${id}`)}
            className="p-2 -ml-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <ArrowLeft size={24} className="text-gray-700 dark:text-gray-300" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white">
              Edit Deal
            </h1>
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">
              Update deal information
            </p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="max-w-2xl mx-auto px-4 py-4 sm:py-6 space-y-3 sm:space-y-4 pb-20 lg:pb-6">
        {/* Customer Information */}
        <Card title="👤 Customer Information" padding="sm" className="sm:p-4">
          <div className="space-y-3">
            <Input
              label="Customer Name"
              value={formData.customerName}
              onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
              required
            />
            <Input
              label="Phone Number"
              value={formData.customerPhone}
              onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
              required
            />
          </div>
        </Card>

        {/* Meta Ads Credentials */}
        {formData.services.includes('Meta Ads') && (
          <Card title="📱 Meta Ads Campaign" padding="sm" className="sm:p-4">
            <div className="space-y-3 sm:space-y-4">
              {/* Facebook Password */}
              <div>
                <label className="block text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                  Facebook Password
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    type={showPasswords.fbPassword ? 'text' : 'password'}
                    value={formData.metaAds.fbPassword}
                    onChange={(e) => setFormData({
                      ...formData,
                      metaAds: { ...formData.metaAds, fbPassword: e.target.value }
                    })}
                    placeholder="Facebook Password"
                    className="text-xs sm:text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 px-3 py-2 rounded-lg flex-1 min-w-0"
                  />
                  <button
                    type="button"
                    onClick={() => togglePassword('fbPassword')}
                    className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  >
                    {showPasswords.fbPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(formData.metaAds.fbPassword, 'Password')}
                    className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  >
                    <Copy size={16} />
                  </button>
                </div>
              </div>

              {/* Instagram Password */}
              <div>
                <label className="block text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                  Instagram Password
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    type={showPasswords.instaPassword ? 'text' : 'password'}
                    value={formData.metaAds.instaPassword}
                    onChange={(e) => setFormData({
                      ...formData,
                      metaAds: { ...formData.metaAds, instaPassword: e.target.value }
                    })}
                    placeholder="Instagram Password"
                    className="text-xs sm:text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 px-3 py-2 rounded-lg flex-1 min-w-0"
                  />
                  <button
                    type="button"
                    onClick={() => togglePassword('instaPassword')}
                    className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  >
                    {showPasswords.instaPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(formData.metaAds.instaPassword, 'Password')}
                    className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  >
                    <Copy size={16} />
                  </button>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Website Details */}
        {formData.services.includes('Website') && (
          <Card title="🌐 Website Development" padding="sm" className="sm:p-4">
            <div className="space-y-3 sm:space-y-4">
              {/* Domain */}
              <Input
                label="Domain"
                value={formData.website.domainName}
                onChange={(e) => setFormData({
                  ...formData,
                  website: { ...formData.website, domainName: e.target.value }
                })}
                placeholder="Domain Name"
              />

              {/* Type */}
              <Select
                label="Type"
                options={websiteTypes}
                value={formData.website.websiteType}
                onChange={(e) => setFormData({
                  ...formData,
                  website: { ...formData.website, websiteType: e.target.value }
                })}
              />
            </div>
          </Card>
        )}

        {/* Deal Notes */}
        <Card title="📝 Deal Notes" padding="sm" className="sm:p-4">
          <textarea
            value={formData.dealNotes}
            onChange={(e) => setFormData({ ...formData, dealNotes: e.target.value })}
            placeholder="Deal Notes"
            rows={4}
            className="w-full text-xs sm:text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
        </Card>
      </form>

      {/* Sticky Bottom Save Button - Above Bottom Nav */}
      <div className="fixed bottom-16 left-0 right-0 p-3 sm:p-4 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg z-50 lg:bottom-0 lg:z-40">
        <div className="max-w-2xl mx-auto flex gap-2 sm:gap-3">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => navigate(`/deals/${id}`)}
            className="flex-1 text-xs sm:text-sm"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            variant="primary"
            size="sm"
            loading={loading}
            onClick={handleSubmit}
            icon={<Save size={16} />}
            className="flex-1 text-xs sm:text-sm"
          >
            <span className="hidden sm:inline">Save Changes</span>
            <span className="sm:hidden">Save</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default EditDeal;

