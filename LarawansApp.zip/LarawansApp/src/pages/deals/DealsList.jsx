import { useState, useEffect } from 'react';
import { Search, Plus, Filter, Download, Trash2, CheckSquare, Square, X } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import Checkbox from '../../components/ui/Checkbox';
import Modal from '../../components/ui/Modal';
import FloatingActionButton from '../../components/layout/FloatingActionButton';
import DealCard from '../../components/deals/DealCard';
import EmptyState from '../../components/ui/EmptyState';
import { subscribeToDeals, deleteDeal } from '../../services/dealsService';
import { useToast } from '../../hooks/useToast';

const DealsList = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { success, error: showError } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [deals, setDeals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDeals, setSelectedDeals] = useState(new Set());
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Read status from URL query params
  useEffect(() => {
    const statusFromUrl = searchParams.get('status');
    if (statusFromUrl) {
      setStatusFilter(statusFromUrl);
    }
  }, [searchParams]);

  // Fetch deals from Firebase with real-time updates
  useEffect(() => {
    const filters = statusFilter !== 'all' && statusFilter !== 'month' 
      ? { status: statusFilter } 
      : {};
    
    const unsubscribe = subscribeToDeals(
      (dealsData) => {
        // Convert Firestore timestamps to ISO strings
        const processedDeals = dealsData.map(deal => ({
          ...deal,
          createdAt: deal.createdAt?.toDate?.()?.toISOString() || deal.createdAt || new Date().toISOString(),
          updatedAt: deal.updatedAt?.toDate?.()?.toISOString() || deal.updatedAt || new Date().toISOString(),
        }));
        setDeals(processedDeals);
        setLoading(false);
      },
      filters
    );

    return () => unsubscribe();
  }, [statusFilter]);

  // Filter chips
  const filterChips = [
    { id: 'all', label: 'All Deals', count: deals.length },
    { id: 'active', label: 'Active', count: deals.filter(d => d.status === 'active').length },
    { id: 'completed', label: 'Completed', count: deals.filter(d => d.status === 'completed').length },
    { id: 'month', label: 'This Month', count: deals.filter(d => {
      const dealDate = new Date(d.createdAt);
      const now = new Date();
      return dealDate.getMonth() === now.getMonth() && dealDate.getFullYear() === now.getFullYear();
    }).length },
  ];

  // Filter deals (client-side search and month filter)
  const filteredDeals = deals.filter((deal) => {
    const matchesSearch = 
      deal.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      deal.customerPhone?.includes(searchTerm);
    
    const matchesStatus = statusFilter === 'all' || 
      (statusFilter === 'month' && new Date(deal.createdAt).getMonth() === new Date().getMonth());
    
    return matchesSearch && matchesStatus;
  });

  // Selection handlers
  const handleSelectDeal = (dealId) => {
    const newSelected = new Set(selectedDeals);
    if (newSelected.has(dealId)) {
      newSelected.delete(dealId);
    } else {
      newSelected.add(dealId);
    }
    setSelectedDeals(newSelected);
  };

  const handleSelectAll = () => {
    if (selectedDeals.size === filteredDeals.length) {
      setSelectedDeals(new Set());
    } else {
      setSelectedDeals(new Set(filteredDeals.map(deal => deal.id)));
    }
  };

  const handleBulkDelete = async () => {
    if (selectedDeals.size === 0) return;
    
    setIsDeleting(true);
    try {
      const deletePromises = Array.from(selectedDeals).map(dealId => deleteDeal(dealId));
      await Promise.all(deletePromises);
      success(`Successfully deleted ${selectedDeals.size} deal${selectedDeals.size > 1 ? 's' : ''}`);
      setSelectedDeals(new Set());
      setShowDeleteModal(false);
    } catch (error) {
      console.error('Error deleting deals:', error);
      showError('Failed to delete some deals. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Calculate stats
  const totalRevenue = deals.reduce((sum, d) => sum + (d.totalAmount || 0), 0);
  const totalPaid = deals.reduce((sum, d) => sum + (d.paidAmount || 0), 0);
  const totalPending = deals.reduce((sum, d) => sum + (d.pendingAmount || 0), 0);

  return (
    <>
      <PageContainer
        title="Deals"
        subtitle={`${deals.length} total deals • ₹${totalRevenue.toLocaleString('en-IN')} revenue`}
        actions={
          <div className="flex gap-2 w-full sm:w-auto">
            <Button 
              variant="outline" 
              size="sm"
              icon={<Download size={16} />}
              className="flex-1 sm:flex-none"
            >
              <span className="hidden sm:inline">Export</span>
              <span className="sm:hidden">📥</span>
            </Button>
          </div>
        }
      >
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Card hoverable>
            <div className="text-center">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Total Revenue</p>
              <p className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
                ₹{totalRevenue.toLocaleString('en-IN')}
              </p>
            </div>
          </Card>
          <Card hoverable>
            <div className="text-center">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Amount Received</p>
              <p className="text-xl sm:text-2xl font-bold text-green-600 dark:text-green-400">
                ₹{totalPaid.toLocaleString('en-IN')}
              </p>
            </div>
          </Card>
          <Card hoverable>
            <div className="text-center">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Pending Amount</p>
              <p className="text-xl sm:text-2xl font-bold text-orange-600 dark:text-orange-400">
                ₹{totalPending.toLocaleString('en-IN')}
              </p>
            </div>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Checkbox
                checked={filteredDeals.length > 0 && selectedDeals.size === filteredDeals.length}
                onChange={handleSelectAll}
                label="Select All"
              />
              {selectedDeals.size > 0 && (
                <div className="flex items-center gap-2 ml-auto">
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    {selectedDeals.size} selected
                  </span>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => setShowDeleteModal(true)}
                    icon={<Trash2 size={16} />}
                  >
                    Delete
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedDeals(new Set())}
                    icon={<X size={16} />}
                  >
                    Clear
                  </Button>
                </div>
              )}
            </div>
            <Input
              placeholder="Search by customer name or phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              icon={<Search size={18} />}
            />

            {/* Filter Chips */}
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin">
              {filterChips.map((chip) => (
                <button
                  key={chip.id}
                  onClick={() => setStatusFilter(chip.id)}
                  className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-all ${
                    statusFilter === chip.id
                      ? 'bg-primary-600 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  {chip.label} ({chip.count})
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* Deals List */}
        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="text-gray-500 dark:text-gray-400">Loading deals...</div>
          </div>
        ) : filteredDeals.length === 0 ? (
          <EmptyState
            title="No deals found"
            description={
              searchTerm || statusFilter !== 'all'
                ? "Try adjusting your filters"
                : "Convert a lead to create your first deal!"
            }
            actionLabel="Go to Leads"
            onAction={() => navigate('/leads')}
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredDeals.map((deal, index) => (
              <div key={deal.id} style={{ animationDelay: `${index * 50}ms` }}>
                <DealCard 
                  deal={deal} 
                  isSelected={selectedDeals.has(deal.id)}
                  onSelect={handleSelectDeal}
                />
              </div>
            ))}
          </div>
        )}

        {/* Bulk Delete Confirmation Modal */}
        <Modal
          isOpen={showDeleteModal}
          onClose={() => !isDeleting && setShowDeleteModal(false)}
          title="Delete Deals"
          size="sm"
        >
          <div className="space-y-4">
            <p className="text-gray-700 dark:text-gray-300">
              Are you sure you want to delete {selectedDeals.size} deal{selectedDeals.size > 1 ? 's' : ''}? This action cannot be undone.
            </p>
            <div className="p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
              <p className="text-sm font-medium text-gray-900 dark:text-white">
                Selected deals will be permanently deleted
              </p>
            </div>
            <div className="flex items-center gap-3 pt-2">
              <Button
                variant="outline"
                fullWidth
                onClick={() => setShowDeleteModal(false)}
                disabled={isDeleting}
              >
                Cancel
              </Button>
              <Button
                variant="danger"
                fullWidth
                onClick={handleBulkDelete}
                disabled={isDeleting}
                icon={isDeleting ? null : <Trash2 size={16} />}
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </Button>
            </div>
          </div>
        </Modal>
      </PageContainer>

      <FloatingActionButton
        onClick={() => navigate('/leads')}
        label="Go to Leads"
      />
    </>
  );
};

export default DealsList;

