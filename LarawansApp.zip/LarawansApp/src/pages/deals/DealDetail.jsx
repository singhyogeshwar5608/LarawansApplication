import { useState, useMemo, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Phone, Edit2, Eye, EyeOff, Copy, ExternalLink, Filter, MessageCircle } from 'lucide-react';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';
import AddPaymentModal from '../../components/deals/AddPaymentModal';
import PaymentHistoryFilter from '../../components/deals/PaymentHistoryFilter';
import { useToast } from '../../hooks/useToast';
import { useAuth } from '../../context/AuthContext';
import { subscribeToDeal, addPayment } from '../../services/dealsService';
import { formatIndianPhone, getWhatsAppLink } from '../../utils/phoneFormat';
import { generateInvoiceWithLogo, generateAndShareInvoice } from '../../utils/invoiceGenerator';

const DealDetail = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { user } = useAuth();
  const { success, error: showError } = useToast();
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showPasswords, setShowPasswords] = useState({});
  const [loadingDeal, setLoadingDeal] = useState(true);
  const [filters, setFilters] = useState({
    period: '',
    startDate: '',
    endDate: '',
    status: '',
  });

  // Fetch deal from Firebase with real-time updates
  const [deal, setDeal] = useState(null);

  useEffect(() => {
    if (!id) {
      showError('Invalid deal ID');
      navigate('/deals');
      return;
    }

    setLoadingDeal(true);
    setDeal(null);

    const unsubscribe = subscribeToDeal(
      id,
      (dealData) => {
        if (dealData) {
          // Convert Firestore timestamps to ISO strings
          const processedDeal = {
            ...dealData,
            id: dealData.id || id,
            createdAt: dealData.createdAt?.toDate?.()?.toISOString() || dealData.createdAt || new Date().toISOString(),
            updatedAt: dealData.updatedAt?.toDate?.()?.toISOString() || dealData.updatedAt || new Date().toISOString(),
            paymentHistory: (dealData.paymentHistory || []).map(payment => ({
              ...payment,
              timestamp: payment.timestamp?.toDate?.()?.toISOString() || payment.timestamp || new Date().toISOString(),
            })),
          };
          setDeal(processedDeal);
          setLoadingDeal(false);
        } else {
          setLoadingDeal(false);
          showError('Deal not found');
          setTimeout(() => navigate('/deals'), 2000);
        }
      },
      (error) => {
        // Error callback for subscription errors
        console.error('Error subscribing to deal:', error);
        setLoadingDeal(false);
        if (error.code === 'permission-denied') {
          showError('You do not have permission to view this deal. Please check Firestore rules.');
        } else {
          showError('Failed to load deal. Please check your connection and try again.');
        }
      }
    );

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [id, navigate, showError]);

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const togglePassword = (field) => {
    setShowPasswords(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text);
    success(`${label} copied!`);
  };

  const handlePaymentAdded = async (payment) => {
    if (!deal) return;

    try {
      // Add payment to Firebase
      await addPayment(deal.id, {
        amount: payment.amount,
        mode: payment.mode,
        notes: payment.notes || '',
        date: payment.date || new Date().toISOString().split('T')[0],
      });
      
      success('Payment added successfully!');
      // The deal will be updated automatically via the real-time listener
    } catch (error) {
      console.error('Error adding payment:', error);
      showError('Failed to add payment. Please try again.');
    }
  };

  const handleCall = () => {
    window.location.href = `tel:${deal.customerPhone.replace(/\D/g, '')}`;
  };

  const handleWhatsApp = () => {
    window.open(getWhatsAppLink(deal.customerPhone), '_blank');
  };

  // Filter payment history
  const filteredPayments = useMemo(() => {
    if (!deal || !deal.paymentHistory) return [];
    let payments = [...deal.paymentHistory];

    // Filter by date range
    if (filters.startDate || filters.endDate) {
      const start = filters.startDate ? new Date(filters.startDate) : null;
      const end = filters.endDate ? new Date(filters.endDate) : null;
      
      payments = payments.filter((payment) => {
        const paymentDate = new Date(payment.timestamp);
        if (start && paymentDate < start) return false;
        if (end) {
          const endDate = new Date(end);
          endDate.setHours(23, 59, 59, 999);
          if (paymentDate > endDate) return false;
        }
        return true;
      });
    }

    // Filter by status (for now, all payments are "paid", but we can add status field later)
    // if (filters.status && filters.status !== 'all') {
    //   payments = payments.filter(p => p.status === filters.status);
    // }

    return payments;
  }, [deal, filters]);

  const handleFilterApply = (newFilters) => {
    setFilters(newFilters);
  };

  const hasActiveFilters = filters.period || filters.startDate || filters.endDate || filters.status;

  if (loadingDeal) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <div className="text-gray-500 dark:text-gray-400">Loading deal...</div>
        </div>
      </div>
    );
  }

  if (!deal) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="text-gray-500 dark:text-gray-400 mb-4">Deal not found</div>
          <Button variant="primary" onClick={() => navigate('/deals')}>
            Back to Deals
          </Button>
        </div>
      </div>
    );
  }

  const progressPercentage = deal && deal.totalAmount > 0 
    ? (((deal.paidAmount || 0) / deal.totalAmount) * 100).toFixed(0)
    : 0;

  return (
    <>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-20 lg:pb-6">
        {/* Header */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate('/deals')}
                className="p-2 -ml-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <ArrowLeft size={24} className="text-gray-700 dark:text-gray-300" />
              </button>
              <div>
                <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white">
                  Deal Details
                </h1>
                <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">
                  {deal.dealId}
                </p>
              </div>
            </div>
            <button
              onClick={() => navigate(`/deals/${id}/edit`)}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              <Edit2 size={20} className="text-gray-700 dark:text-gray-300" />
            </button>
          </div>
        </div>

        <div className="max-w-2xl mx-auto px-4 py-4 sm:py-6 space-y-3 sm:space-y-4 lg:space-y-6">
          {/* Customer Info */}
          <Card padding="sm" className="sm:p-4">
            <div className="space-y-2">
              <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-gray-900 dark:text-white">
                {deal.customerName}
              </h2>
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2 text-sm sm:text-base text-gray-700 dark:text-gray-300">
                  <Phone size={14} />
                  <span>{formatIndianPhone(deal.customerPhone)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={handleCall} 
                    className="text-xs sm:text-sm flex items-center gap-1.5"
                  >
                    <Phone size={14} />
                    Call
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={handleWhatsApp} 
                    className="text-xs sm:text-sm flex items-center gap-1.5 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 border-green-200 dark:border-green-800 hover:bg-green-100 dark:hover:bg-green-900/30"
                  >
                    <MessageCircle size={14} />
                    WhatsApp
                  </Button>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
                Created: {formatDateTime(deal.createdAt)}
              </p>
              {/* Days Left */}
              {deal.completionDays && (
                <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                  {(() => {
                    const createdDate = new Date(deal.createdAt);
                    const completionDate = new Date(createdDate);
                    completionDate.setDate(completionDate.getDate() + parseInt(deal.completionDays));
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    completionDate.setHours(0, 0, 0, 0);
                    const diffTime = completionDate - today;
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    
                    return (
                      <div className={`p-2 rounded-lg ${
                        diffDays < 0 
                          ? 'bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-400'
                          : diffDays <= 3
                          ? 'bg-orange-100 dark:bg-orange-900/20 text-orange-700 dark:text-orange-400'
                          : 'bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400'
                      }`}>
                        <p className="text-xs sm:text-sm font-semibold">
                          {diffDays < 0 
                            ? `⚠️ Overdue by ${Math.abs(diffDays)} day${Math.abs(diffDays) > 1 ? 's' : ''}`
                            : diffDays === 0
                            ? '⚠️ Due Today'
                            : `⏱️ ${diffDays} day${diffDays > 1 ? 's' : ''} left to complete`
                          }
                        </p>
                        <p className="text-xs mt-1 opacity-75">
                          Completion date: {completionDate.toLocaleDateString('en-IN', {
                            day: 'numeric',
                            month: 'long',
                            year: 'numeric',
                          })}
                        </p>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
          </Card>

          {/* Payment Status */}
          <Card title="💰 Payment Status" padding="sm" className="sm:p-4">
            <div className="space-y-2 sm:space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Total:</span>
                <span className="text-base sm:text-lg md:text-xl font-bold text-gray-900 dark:text-white">
                  ₹{deal.totalAmount.toLocaleString('en-IN')}
                </span>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Paid:</span>
                  <span className="text-base sm:text-lg font-bold text-green-600 dark:text-green-400">
                    ₹{deal.paidAmount.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="w-full h-2 sm:h-2.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-green-500 to-green-600 rounded-full transition-all duration-500"
                    style={{ width: `${progressPercentage}%` }}
                  />
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 text-right">
                  {progressPercentage}%
                </p>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Pending:</span>
                <span className="text-base sm:text-lg font-bold text-orange-600 dark:text-orange-400">
                  ₹{deal.pendingAmount.toLocaleString('en-IN')}
                </span>
              </div>

              {deal.pendingAmount > 0 && (
                <Button
                  variant="primary"
                  size="sm"
                  fullWidth
                  onClick={() => setShowPaymentModal(true)}
                  className="mt-2 text-xs sm:text-sm"
                >
                  💳 Add Payment
                </Button>
              )}
            </div>
          </Card>

          {/* Payment History */}
          <Card 
            title={
              <div className="flex items-center justify-between w-full gap-2">
                <span className="flex-1">💳 Payment History ({filteredPayments.length})</span>
                <button
                  onClick={() => setShowFilterModal(true)}
                  className={`p-1.5 sm:p-2 rounded-lg transition-colors flex-shrink-0 ${
                    hasActiveFilters
                      ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  <Filter size={14} className="sm:w-4 sm:h-4" />
                </button>
              </div>
            }
            padding="sm" 
            className="sm:p-4"
          >
            {/* Active Filters */}
            {hasActiveFilters && (
              <div className="mb-3 flex flex-wrap gap-1.5 items-center">
                <span className="text-xs text-gray-500 dark:text-gray-400">Filters:</span>
                {filters.period && (
                  <span className="px-2 py-0.5 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-xs rounded-full">
                    {filters.period === 'today' ? 'Today' :
                     filters.period === 'thisWeek' ? 'This week' :
                     filters.period === 'thisMonth' ? 'This month' :
                     filters.period === 'previousMonth' ? 'Previous month' :
                     filters.period === 'thisYear' ? 'This year' : filters.period}
                  </span>
                )}
                {(filters.startDate || filters.endDate) && (
                  <span className="px-2 py-0.5 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-xs rounded-full">
                    {filters.startDate && filters.endDate 
                      ? `${new Date(filters.startDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })} - ${new Date(filters.endDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`
                      : filters.startDate 
                      ? `From ${new Date(filters.startDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`
                      : `Until ${new Date(filters.endDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`}
                  </span>
                )}
                {filters.status && filters.status !== 'all' && (
                  <span className="px-2 py-0.5 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-xs rounded-full">
                    {filters.status}
                  </span>
                )}
                <button
                  onClick={() => {
                    setFilters({ period: '', startDate: '', endDate: '', status: '' });
                  }}
                  className="text-xs text-primary-600 dark:text-primary-400 hover:underline"
                >
                  Clear all
                </button>
              </div>
            )}
            <div className="space-y-1.5 sm:space-y-2">
              {filteredPayments.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    No payments found matching the filters
                  </p>
                  {hasActiveFilters && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setFilters({ period: '', startDate: '', endDate: '', status: '' });
                        setShowFilterModal(false);
                      }}
                      className="mt-3 text-xs"
                    >
                      Clear Filters
                    </Button>
                  )}
                </div>
              ) : (
                filteredPayments.map((payment) => (
                <div
                  key={payment.id}
                  className="p-2 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700"
                >
                  {/* Date and Amount - Top Row */}
                  <div className="flex justify-between items-start gap-2 mb-1">
                    <p className="text-xs text-gray-600 dark:text-gray-400">
                      {formatDateTime(payment.timestamp)}
                    </p>
                    <p className="text-base sm:text-lg font-bold text-gray-900 dark:text-white">
                      ₹{payment.amount.toLocaleString('en-IN')}
                    </p>
                  </div>
                  
                  {/* Details - Horizontal Layout - Bottom Row */}
                  {payment.mode || payment.notes ? (
                    <div className="flex flex-wrap items-center gap-x-2 sm:gap-x-3 gap-y-0.5 text-xs">
                      {payment.mode && (
                        <span className="text-gray-700 dark:text-gray-300 whitespace-nowrap">
                          {payment.mode}
                        </span>
                      )}
                      {payment.notes && (
                        <span className="text-gray-600 dark:text-gray-400 truncate max-w-[150px] sm:max-w-[250px]">
                          {payment.notes}
                        </span>
                      )}
                    </div>
                  ) : null}
                </div>
                ))
              )}

              {filteredPayments.length > 0 && (
                <div className="pt-2 sm:pt-3 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex justify-between text-xs sm:text-sm font-semibold">
                    <span>Total: {filteredPayments.length}</span>
                    <span>
                      ₹{filteredPayments.reduce((sum, p) => sum + p.amount, 0).toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </Card>

          {/* Services & Credentials */}
          <Card title="🎯 Services & Access" padding="sm" className="sm:p-4">
            <div className="space-y-4 sm:space-y-5">
              {deal.services?.includes('Meta Ads') && deal.serviceDetails?.metaAds && (
                <div>
                  <h4 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-white mb-2">
                    📱 Meta Ads Campaign
                  </h4>
                  <div className="space-y-3 sm:space-y-4 pl-2 sm:pl-4">
                    {/* Facebook Password */}
                    <div>
                      <label className="block text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                        Facebook Password
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type={showPasswords.fbPassword ? 'text' : 'password'}
                          value={deal.serviceDetails?.metaAds?.fbPassword || ''}
                          readOnly
                          placeholder="Enter Facebook password"
                          className="text-xs sm:text-sm bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 px-3 py-2 rounded-lg flex-1 min-w-0"
                        />
                        <button 
                          onClick={() => togglePassword('fbPassword')}
                          className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
                          aria-label="Toggle password visibility"
                        >
                          {showPasswords.fbPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                        <button 
                          onClick={() => copyToClipboard(deal.serviceDetails?.metaAds?.fbPassword || '', 'Password')}
                          className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
                          aria-label="Copy password"
                        >
                          <Copy size={16} />
                        </button>
                      </div>
                    </div>

                    {/* Instagram Password */}
                    <div>
                      <label className="block text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                        Instagram Password
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type={showPasswords.instaPassword ? 'text' : 'password'}
                        value={deal.serviceDetails?.metaAds?.instaPassword || ''}
                        readOnly
                        placeholder="Enter Instagram password"
                          className="text-xs sm:text-sm bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 px-3 py-2 rounded-lg flex-1 min-w-0"
                        />
                        <button 
                          onClick={() => togglePassword('instaPassword')}
                          className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
                          aria-label="Toggle password visibility"
                        >
                          {showPasswords.instaPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                        <button 
                          onClick={() => copyToClipboard(deal.serviceDetails?.metaAds?.instaPassword || '', 'Password')}
                          className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
                          aria-label="Copy password"
                        >
                          <Copy size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {deal.services.includes('Website') && (
                <div>
                  <h4 className="text-sm sm:text-base font-semibold text-gray-900 dark:text-white mb-2">
                    🌐 Website Development
                  </h4>
                  <div className="space-y-3 sm:space-y-4 pl-2 sm:pl-4">
                    {/* Domain Field */}
                    <div>
                      <label className="block text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                        Domain
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          value={deal.serviceDetails?.website?.domainName || ''}
                          readOnly
                          placeholder="Enter domain name"
                          className="text-xs sm:text-sm bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 px-3 py-2 rounded-lg flex-1 min-w-0"
                        />
                        <button
                          onClick={() => window.open(`https://${deal.serviceDetails?.website?.domainName || ''}`, '_blank')}
                          className="p-2 text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-900/20 rounded-lg transition-colors"
                          aria-label="Open domain"
                        >
                          <ExternalLink size={16} />
                        </button>
                      </div>
                    </div>

                    {/* Type Field */}
                    <div>
                      <label className="block text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                        Type
                      </label>
                      <input
                        type="text"
                        value={deal.serviceDetails?.website?.websiteType || ''}
                        readOnly
                        placeholder="Enter website type"
                        className="text-xs sm:text-sm bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 px-3 py-2 rounded-lg w-full"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </Card>

          {/* Facilities */}
          <Card title="📋 Facilities Included" padding="sm" className="sm:p-4">
            <ul className="space-y-1.5 sm:space-y-2">
              {deal.facilities && deal.facilities.length > 0 && deal.facilities.map((facility, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-green-600 mt-0.5 text-xs">✓</span>
                  <span className="text-xs sm:text-sm text-gray-700 dark:text-gray-300">{facility}</span>
                </li>
              ))}
            </ul>
          </Card>

          {/* Deal Notes */}
          {deal.dealNotes && (
            <Card title="📝 Deal Notes" padding="sm" className="sm:p-4">
              <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                {deal.dealNotes}
              </p>
            </Card>
          )}

          {/* Quick Actions */}
          <Card title="Quick Actions" padding="sm" className="sm:p-4 mb-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                fullWidth 
                className="text-xs sm:text-sm !py-2.5 min-h-[44px]"
                onClick={async () => {
                  try {
                    await generateInvoiceWithLogo(deal, user?.uid);
                    success('Invoice generated successfully!');
                  } catch (error) {
                    console.error('Error generating invoice:', error);
                    showError('Failed to generate invoice. Please try again.');
                  }
                }}
              >
                📄 Invoice
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                fullWidth 
                className="text-xs sm:text-sm !py-2.5 min-h-[44px] flex items-center justify-center gap-1.5"
                onClick={async () => {
                  try {
                    await generateAndShareInvoice(deal, user?.uid);
                    success('Invoice generated! Please attach the downloaded PDF to your WhatsApp message.');
                  } catch (error) {
                    console.error('Error sharing invoice:', error);
                    showError('Failed to generate invoice. Please try again.');
                  }
                }}
              >
                <MessageCircle size={14} />
                WhatsApp
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                fullWidth 
                className="text-xs sm:text-sm !py-2.5 min-h-[44px]"
                onClick={() => setShowPaymentModal(true)}
              >
                💳 Payment
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                fullWidth 
                className="text-xs sm:text-sm !py-2.5 min-h-[44px]"
                onClick={() => {
                  // Email details
                  success('Email feature coming soon!');
                }}
              >
                📧 Email
              </Button>
            </div>
          </Card>
        </div>
      </div>

      {/* Add Payment Modal */}
      <AddPaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        deal={deal}
        onPaymentAdded={handlePaymentAdded}
      />

      {/* Payment History Filter Modal */}
      <PaymentHistoryFilter
        isOpen={showFilterModal}
        onClose={() => setShowFilterModal(false)}
        onApply={handleFilterApply}
        totalPaymentCount={deal.paymentHistory?.length || 0}
        initialFilters={filters}
      />
    </>
  );
};

export default DealDetail;

