import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Check, FileText, Share2, Home } from 'lucide-react';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';
import Spinner from '../../components/ui/Spinner';
import { subscribeToDeal } from '../../services/dealsService';
import { useToast } from '../../hooks/useToast';

const DealSuccess = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { showError } = useToast();
  const [deal, setDeal] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) {
      showError('Invalid deal ID');
      navigate('/deals');
      return;
    }

    const unsubscribe = subscribeToDeal(
      id,
      (dealData) => {
        if (dealData) {
          setDeal({
            ...dealData,
            dealId: dealData.dealId || `#DL-${id.substring(0, 8).toUpperCase()}`,
          });
          setLoading(false);
        } else {
          setLoading(false);
          showError('Deal not found');
          setTimeout(() => navigate('/deals'), 2000);
        }
      },
      (error) => {
        console.error('Error loading deal:', error);
        setLoading(false);
        showError('Failed to load deal details');
      }
    );

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [id, navigate, showError]);

  const shareOnWhatsApp = () => {
    if (!deal) return;
    const message = `Hi ${deal.customerName || 'there'}! 👋\n\nYour deal has been created successfully!\n\nDeal ID: ${deal.dealId}\n\nWe'll share the invoice and details shortly.\n\nThank you for choosing us!`;
    const phone = deal.customerPhone?.replace(/\D/g, '') || '';
    if (phone) {
      window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-100 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 flex items-center justify-center p-4">
        <div className="text-center">
          <Spinner size="lg" />
          <p className="mt-4 text-gray-600 dark:text-gray-400">Loading deal details...</p>
        </div>
      </div>
    );
  }

  if (!deal) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-100 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 flex items-center justify-center p-4">
        <Card className="text-center">
          <p className="text-gray-600 dark:text-gray-400 mb-4">Deal not found</p>
          <Button variant="primary" onClick={() => navigate('/deals')}>
            Back to Deals
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-100 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="text-center animate-slide-up">
          {/* Success Animation */}
          <div className="mb-6">
            <div className="inline-flex items-center justify-center w-24 h-24 bg-green-100 dark:bg-green-900/30 rounded-full mb-4 animate-fade-in">
              <Check size={48} className="text-green-600 dark:text-green-400" />
            </div>
            <div className="space-y-2">
              <div className="flex justify-center gap-2 text-2xl sm:text-3xl md:text-4xl animate-fade-in">
                ✨ 🎉 ✨
              </div>
            </div>
          </div>

          {/* Success Message */}
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Deal Created Successfully!
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Your deal has been created and saved
          </p>

          {/* Deal ID */}
          <div className="p-4 bg-primary-50 dark:bg-primary-900/20 rounded-lg mb-6">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Deal ID</p>
            <p className="text-xl sm:text-2xl font-bold text-primary-600 dark:text-primary-400">
              {deal.dealId}
            </p>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <Button
              variant="primary"
              size="md"
              fullWidth
              icon={<FileText size={18} />}
              onClick={() => navigate(`/deals/${id}`)}
              className="text-sm sm:text-base"
            >
              📄 View Deal Details
            </Button>

            <Button
              variant="outline"
              size="md"
              fullWidth
              icon={<Share2 size={18} />}
              onClick={shareOnWhatsApp}
              className="text-sm sm:text-base"
            >
              📤 Share on WhatsApp
            </Button>

            <Button
              variant="ghost"
              size="md"
              fullWidth
              icon={<Home size={18} />}
              onClick={() => navigate('/')}
              className="text-sm sm:text-base"
            >
              ← Back to Dashboard
            </Button>
          </div>

          {/* Confetti-style decoration */}
          <div className="mt-6 text-center text-sm text-gray-500 dark:text-gray-400">
            🎊 Congratulations! 🎊
          </div>
        </Card>
      </div>
    </div>
  );
};

export default DealSuccess;

