import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Phone, Calendar, MapPin, Briefcase, Target, Edit2, Trash2, CheckCircle, Plus } from 'lucide-react';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';
import CallHistory from '../components/leads/CallHistory';
import AddCallRecord from '../components/leads/AddCallRecord';
import FollowUpBadge from '../components/leads/FollowUpBadge';
import { useToast } from '../hooks/useToast';
import { subscribeToLead, updateLead, deleteLead } from '../services/leadsService';

const LeadDetail = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { success, warning, error: showError } = useToast();
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showConvertModal, setShowConvertModal] = useState(false);
  const [lead, setLead] = useState(null);
  const [loadingLead, setLoadingLead] = useState(true);
  const [showAddCallModal, setShowAddCallModal] = useState(false);

  // Fetch lead from Firebase with real-time updates
  useEffect(() => {
    if (!id) return;

    const unsubscribe = subscribeToLead(id, (leadData) => {
      if (leadData) {
        // Convert Firestore timestamps to ISO strings
        const processedLead = {
          ...leadData,
          createdAt: leadData.createdAt?.toDate?.()?.toISOString() || leadData.createdAt || new Date().toISOString(),
          updatedAt: leadData.updatedAt?.toDate?.()?.toISOString() || leadData.updatedAt || new Date().toISOString(),
          followUpDate: leadData.followUpDate?.toDate?.()?.toISOString() || leadData.followUpDate || null,
        };
        setLead(processedLead);
      } else {
        showError('Lead not found');
        navigate('/leads');
      }
      setLoadingLead(false);
    });

    return () => unsubscribe();
  }, [id, navigate, showError]);

  const formatDateTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleCall = async () => {
    if (!lead) return;
    
    try {
      // Track call in history using Firebase
      await addCallHistory(lead.id, {
        phone: lead.phone,
        leadId: lead.id,
      });
    } catch (error) {
      console.error('Error adding call history:', error);
    }
    
    window.location.href = `tel:${lead.phone.replace(/\D/g, '')}`;
  };


  const handleStatusChange = (newStatus) => {
    setSelectedStatus(newStatus);
    setShowStatusModal(true);
  };

  const confirmStatusChange = async () => {
    if (!lead) return;
    
    setLoading(true);

    try {
      // Update status in Firebase
      await updateLead(lead.id, { status: selectedStatus });

      setLoading(false);
      setShowStatusModal(false);

      // Update status
      const statusLabels = {
        interested: 'Interested',
        rejected: 'Not Interested',
      };

      success(`Status updated to ${statusLabels[selectedStatus]}!`);

      // If status changed to "Interested", navigate to edit form
      if (selectedStatus === 'interested') {
        setTimeout(() => {
          navigate(`/leads/${lead.id}/edit`);
        }, 500);
      } else if (selectedStatus === 'rejected') {
        // Just go back to list for rejected
        setTimeout(() => {
          navigate('/leads');
        }, 500);
      }
    } catch (error) {
      console.error('Error updating status:', error);
      setLoading(false);
      showError('Failed to update status. Please try again.');
    }
  };

  const handleEdit = () => {
    navigate(`/leads/${lead.id}/edit`);
  };

  const handleDelete = async () => {
    if (!lead) return;
    
    if (window.confirm('Are you sure you want to delete this lead?')) {
      try {
        await deleteLead(lead.id);
        warning('Lead deleted');
        navigate('/leads');
      } catch (error) {
        console.error('Error deleting lead:', error);
        showError('Failed to delete lead. Please try again.');
      }
    }
  };

  if (loadingLead) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
        <div className="text-gray-500 dark:text-gray-400">Loading lead...</div>
      </div>
    );
  }

  if (!lead) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
        <div className="text-gray-500 dark:text-gray-400">Lead not found</div>
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-6">
        {/* Header */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate('/leads')}
                className="p-2 -ml-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <ArrowLeft size={24} className="text-gray-700 dark:text-gray-300" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                  Lead Details
                </h1>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {lead.name || lead.phone}
                </p>
              </div>
            </div>
            {lead.status !== 'new' && (
              <button
                onClick={handleEdit}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <Edit2 size={20} className="text-gray-700 dark:text-gray-300" />
              </button>
            )}
          </div>
        </div>

        <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
          {/* Contact Card */}
          <Card>
            <div className="flex items-start justify-between mb-4">
              <Badge status={lead.status} size="lg" />
              <Button
                onClick={handleCall}
                variant="primary"
                size="sm"
                icon={<Phone size={16} />}
              >
                Call
              </Button>
            </div>

            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Phone Number</p>
                <p className="text-lg sm:text-xl md:text-2xl font-bold text-gray-900 dark:text-white">
                  {lead.phone}
                </p>
              </div>

              {lead.name && (
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Name</p>
                  <p className="text-base sm:text-lg font-semibold text-gray-900 dark:text-white">
                    {lead.name}
                  </p>
                </div>
              )}

              <div className="pt-3 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Calendar size={14} />
                  <span>Added on {formatDateTime(lead.createdAt)}</span>
                </div>
              </div>
            </div>
          </Card>

          {/* Status Change Section - Only for "New" leads */}
          {lead.status === 'new' && (
            <Card>
              <h3 className="text-base sm:text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Change Status
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Update the lead status after your first interaction
              </p>
              <div className="space-y-3">
                <Button
                  variant="primary"
                  fullWidth
                  size="md"
                  onClick={() => handleStatusChange('interested')}
                  className="justify-start !py-3 sm:!py-4 text-sm sm:text-base"
                >
                  <span className="mr-2">🟡</span>
                  <span>Mark as Interested</span>
                </Button>
                <Button
                  variant="outline"
                  fullWidth
                  size="md"
                  onClick={() => handleStatusChange('rejected')}
                  className="justify-start !py-3 sm:!py-4 border-red-300 text-red-600 hover:bg-red-50 dark:border-red-900 dark:text-red-400 dark:hover:bg-red-900/20 text-sm sm:text-base"
                >
                  <span className="mr-2">❌</span>
                  <span>Mark as Not Interested</span>
                </Button>
              </div>
            </Card>
          )}

          {/* Convert to Deal - For interested leads */}
          {lead.status === 'interested' && (
            <Card className="bg-gradient-to-r from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-green-200 dark:border-green-900">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    Ready to Convert? 🎉
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Convert this lead to a deal and start tracking payments
                  </p>
                </div>
              </div>
              <Button
                variant="primary"
                fullWidth
                size="lg"
                icon={<CheckCircle size={20} />}
                onClick={() => setShowConvertModal(true)}
                className="mt-4"
              >
                ✅ Convert to Deal
              </Button>
            </Card>
          )}

          {/* Follow-up Badge */}
          {lead.nextFollowUp && (
            <Card>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Calendar size={20} className="text-primary-600 dark:text-primary-400" />
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Next Follow-up</p>
                    <p className="text-base font-semibold text-gray-900 dark:text-white">
                      {new Date(lead.nextFollowUp).toLocaleDateString('en-IN', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </p>
                  </div>
                </div>
                <FollowUpBadge followUpDate={lead.nextFollowUp} />
              </div>
            </Card>
          )}

          {/* Call History */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Call History</h2>
              <Button
                variant="primary"
                size="sm"
                icon={<Plus size={16} />}
                onClick={() => setShowAddCallModal(true)}
              >
                Add Call Record
              </Button>
            </div>
            <CallHistory leadId={lead.id} leadPhone={lead.phone} />
          </div>

          {/* Additional Details - Only show if lead has details */}
          {lead.status !== 'new' && (
            <>
              {(lead.city || lead.district || lead.businessDetails) && (
                <Card title="Business Information">
                  <div className="space-y-3">
                    {(lead.city || lead.district) && (
                      <div className="flex items-start gap-3">
                        <MapPin size={18} className="text-gray-600 dark:text-gray-400 mt-0.5" />
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Location</p>
                          <p className="text-gray-900 dark:text-white">
                            {[lead.city, lead.district].filter(Boolean).join(', ')}
                          </p>
                        </div>
                      </div>
                    )}

                    {lead.businessDetails && (
                      <div className="flex items-start gap-3">
                        <Briefcase size={18} className="text-gray-600 dark:text-gray-400 mt-0.5" />
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Business Details</p>
                          <p className="text-gray-900 dark:text-white">{lead.businessDetails}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </Card>
              )}

              {lead.services && lead.services.length > 0 && (
                <Card title="Services Required">
                  <div className="flex items-start gap-3">
                    <Target size={18} className="text-gray-600 dark:text-gray-400 mt-1" />
                    <div className="flex flex-wrap gap-2">
                      {lead.services.map((service, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-sm rounded-full font-medium"
                        >
                          {service}
                        </span>
                      ))}
                    </div>
                  </div>
                </Card>
              )}

              {lead.followUpDate && (
                <Card title="Follow-up Scheduled">
                  <div className="flex items-center gap-3 text-primary-600 dark:text-primary-400">
                    <Calendar size={20} />
                    <div>
                      <p className="font-semibold">
                        {new Date(lead.followUpDate).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'long',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {lead.meetingLocation === 'office' ? 'At Our Office' : "At Client's Place"}
                      </p>
                    </div>
                  </div>
                </Card>
              )}

              {lead.notes && (
                <Card title="Notes">
                  <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                    {lead.notes}
                  </p>
                </Card>
              )}
            </>
          )}

          {/* Danger Zone */}
          <Card>
            <h3 className="text-sm font-semibold text-red-600 dark:text-red-400 mb-3">
              Danger Zone
            </h3>
            <Button
              variant="outline"
              onClick={handleDelete}
              icon={<Trash2 size={16} />}
              className="border-red-300 text-red-600 hover:bg-red-50 dark:border-red-900 dark:text-red-400 dark:hover:bg-red-900/20"
            >
              Delete Lead
            </Button>
          </Card>
        </div>
      </div>

      {/* Status Change Confirmation Modal */}
      <Modal
        isOpen={showStatusModal}
        onClose={() => setShowStatusModal(false)}
        title={`Mark as ${selectedStatus === 'interested' ? 'Interested' : 'Not Interested'}?`}
        footer={
          <>
            <Button variant="outline" onClick={() => setShowStatusModal(false)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={confirmStatusChange}
              loading={loading}
            >
              {selectedStatus === 'interested' ? 'Yes, Continue →' : 'Confirm'}
            </Button>
          </>
        }
      >
        <p className="text-gray-700 dark:text-gray-300">
          {selectedStatus === 'interested' ? (
            <>
              Mark this lead as <strong>Interested</strong>?
              <br />
              <br />
              You'll be able to add complete details next.
            </>
          ) : (
            <>
              Mark this lead as <strong>Not Interested</strong>?
              <br />
              <br />
              This lead will be moved to rejected status.
            </>
          )}
        </p>
      </Modal>

      {/* Convert to Deal Confirmation Modal */}
      <Modal
        isOpen={showConvertModal}
        onClose={() => setShowConvertModal(false)}
        title="Convert to Deal?"
        footer={
          <>
            <Button variant="outline" onClick={() => setShowConvertModal(false)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={() => navigate(`/deals/convert/${lead.id}`)}
            >
              Yes, Create Deal →
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <p className="text-gray-700 dark:text-gray-300">
            Convert <strong>{lead.name || lead.phone}</strong> to a deal?
          </p>
          {lead.services && lead.services.length > 0 && (
            <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-lg">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Services selected:</p>
              <div className="flex flex-wrap gap-2">
                {lead.services.map((service, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-sm rounded-full"
                  >
                    {service}
                  </span>
                ))}
              </div>
            </div>
          )}
          <p className="text-sm text-gray-600 dark:text-gray-400">
            You'll configure service details and payment information in the next steps.
          </p>
        </div>
      </Modal>

      {/* Add Call Record Modal */}
      {lead && (
        <AddCallRecord
          isOpen={showAddCallModal}
          onClose={() => setShowAddCallModal(false)}
          leadId={lead.id}
          leadName={lead.name || lead.phone}
          onSuccess={() => {
            // Refresh will happen automatically via subscription
          }}
        />
      )}
    </>
  );
};

export default LeadDetail;

