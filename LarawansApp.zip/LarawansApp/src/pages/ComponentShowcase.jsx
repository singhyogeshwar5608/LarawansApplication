import { useState } from 'react';
import { Check, X, AlertCircle, Download, Plus, Trash2 } from 'lucide-react';
import PageContainer from '../components/layout/PageContainer';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import Badge from '../components/ui/Badge';
import Modal from '../components/ui/Modal';
import Toggle from '../components/ui/Toggle';
import Checkbox from '../components/ui/Checkbox';
import { RadioGroup } from '../components/ui/Radio';
import Textarea from '../components/ui/Textarea';
import Spinner from '../components/ui/Spinner';
import Avatar, { AvatarGroup } from '../components/ui/Avatar';
import EmptyState from '../components/ui/EmptyState';
import DatePicker from '../components/ui/DatePicker';
import { useToast } from '../hooks/useToast';
import { ToastContainer } from '../components/ui/Toast';

const ComponentShowcase = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [toggleState, setToggleState] = useState(false);
  const [checkboxState, setCheckboxState] = useState(false);
  const [radioValue, setRadioValue] = useState('option1');
  const { toasts, removeToast, success, error, warning, info } = useToast();

  const selectOptions = [
    { value: 'option1', label: 'Option 1' },
    { value: 'option2', label: 'Option 2' },
    { value: 'option3', label: 'Option 3' },
  ];

  const radioOptions = [
    { value: 'option1', label: 'Option 1' },
    { value: 'option2', label: 'Option 2' },
    { value: 'option3', label: 'Option 3' },
  ];

  const avatars = [
    { name: 'John Doe' },
    { name: 'Jane Smith' },
    { name: 'Bob Wilson' },
    { name: 'Alice Brown' },
  ];

  return (
    <>
      <PageContainer
        title="Component Showcase"
        subtitle="Explore all available UI components in the design system"
      >
        <div className="space-y-8">
          {/* Buttons */}
          <Card title="Buttons" subtitle="Various button styles and sizes">
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Variants
                </h4>
                <div className="flex flex-wrap gap-3">
                  <Button variant="primary">Primary</Button>
                  <Button variant="secondary">Secondary</Button>
                  <Button variant="outline">Outline</Button>
                  <Button variant="danger">Danger</Button>
                  <Button variant="success">Success</Button>
                  <Button variant="ghost">Ghost</Button>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Sizes
                </h4>
                <div className="flex flex-wrap items-center gap-3">
                  <Button size="xs">Extra Small</Button>
                  <Button size="sm">Small</Button>
                  <Button size="md">Medium</Button>
                  <Button size="lg">Large</Button>
                  <Button size="xl">Extra Large</Button>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  With Icons
                </h4>
                <div className="flex flex-wrap gap-3">
                  <Button icon={<Plus size={16} />}>Add New</Button>
                  <Button icon={<Download size={16} />} variant="outline">
                    Download
                  </Button>
                  <Button icon={<Trash2 size={16} />} variant="danger">
                    Delete
                  </Button>
                  <Button loading>Loading...</Button>
                </div>
              </div>
            </div>
          </Card>

          {/* Inputs */}
          <Card title="Input Fields" subtitle="Various input types and states">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input label="Text Input" placeholder="Enter text" />
              <Input
                label="Email Input"
                type="email"
                placeholder="Enter email"
              />
              <Input
                label="Password Input"
                type="password"
                placeholder="Enter password"
              />
              <Input
                label="With Icon"
                placeholder="Search..."
                icon={<AlertCircle size={18} />}
              />
              <Input
                label="With Error"
                placeholder="Enter value"
                error="This field is required"
              />
              <Input
                label="Disabled"
                placeholder="Disabled input"
                disabled
              />
            </div>
          </Card>

          {/* Badges */}
          <Card title="Badges" subtitle="Status indicators and labels">
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Variants
                </h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="default">Default</Badge>
                  <Badge variant="primary">Primary</Badge>
                  <Badge variant="success">Success</Badge>
                  <Badge variant="warning">Warning</Badge>
                  <Badge variant="danger">Danger</Badge>
                  <Badge variant="info">Info</Badge>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Lead Status
                </h4>
                <div className="flex flex-wrap gap-2">
                  <Badge status="new">New</Badge>
                  <Badge status="interested">Interested</Badge>
                  <Badge status="scheduled">Scheduled</Badge>
                  <Badge status="converted">Converted</Badge>
                  <Badge status="rejected">Rejected</Badge>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Sizes
                </h4>
                <div className="flex flex-wrap items-center gap-2">
                  <Badge size="sm">Small</Badge>
                  <Badge size="md">Medium</Badge>
                  <Badge size="lg">Large</Badge>
                </div>
              </div>
            </div>
          </Card>

          {/* Form Controls */}
          <Card title="Form Controls" subtitle="Checkboxes, radios, toggles, and more">
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Toggle Switch
                </h4>
                <Toggle
                  checked={toggleState}
                  onChange={() => setToggleState(!toggleState)}
                  label="Enable notifications"
                />
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Checkbox
                </h4>
                <Checkbox
                  checked={checkboxState}
                  onChange={(e) => setCheckboxState(e.target.checked)}
                  label="I agree to the terms and conditions"
                />
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Radio Group
                </h4>
                <RadioGroup
                  options={radioOptions}
                  value={radioValue}
                  onChange={setRadioValue}
                  orientation="vertical"
                />
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Select Dropdown
                </h4>
                <Select
                  options={selectOptions}
                  placeholder="Choose an option"
                />
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Date Picker
                </h4>
                <DatePicker label="Select date" />
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Textarea
                </h4>
                <Textarea
                  placeholder="Enter your comments..."
                  rows={3}
                  maxLength={200}
                />
              </div>
            </div>
          </Card>

          {/* Avatars */}
          <Card title="Avatars" subtitle="User profile pictures and groups">
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Sizes
                </h4>
                <div className="flex flex-wrap items-center gap-4">
                  <Avatar name="John Doe" size="xs" />
                  <Avatar name="Jane Smith" size="sm" />
                  <Avatar name="Bob Wilson" size="md" />
                  <Avatar name="Alice Brown" size="lg" />
                  <Avatar name="Mike Davis" size="xl" />
                  <Avatar name="Sarah Jones" size="2xl" />
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  With Status
                </h4>
                <div className="flex flex-wrap items-center gap-4">
                  <Avatar name="Online User" status="online" size="lg" />
                  <Avatar name="Offline User" status="offline" size="lg" />
                  <Avatar name="Busy User" status="busy" size="lg" />
                  <Avatar name="Away User" status="away" size="lg" />
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Avatar Group
                </h4>
                <AvatarGroup avatars={avatars} max={3} size="md" />
              </div>
            </div>
          </Card>

          {/* Spinner */}
          <Card title="Loading Spinners" subtitle="Loading indicators">
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Sizes
                </h4>
                <div className="flex flex-wrap items-center gap-6">
                  <Spinner size="xs" />
                  <Spinner size="sm" />
                  <Spinner size="md" />
                  <Spinner size="lg" />
                  <Spinner size="xl" />
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Colors
                </h4>
                <div className="flex flex-wrap items-center gap-6">
                  <Spinner color="primary" />
                  <Spinner color="success" />
                  <Spinner color="warning" />
                  <Spinner color="danger" />
                </div>
              </div>
            </div>
          </Card>

          {/* Modal & Toast */}
          <Card title="Modal & Notifications" subtitle="Dialogs and toast messages">
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Modal Dialog
                </h4>
                <Button onClick={() => setModalOpen(true)}>Open Modal</Button>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Toast Notifications
                </h4>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="success"
                    onClick={() => success('Success! Operation completed.')}
                  >
                    Success Toast
                  </Button>
                  <Button
                    variant="danger"
                    onClick={() => error('Error! Something went wrong.')}
                  >
                    Error Toast
                  </Button>
                  <Button
                    onClick={() => warning('Warning! Please review this.')}
                  >
                    Warning Toast
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => info('Info: New update available.')}
                  >
                    Info Toast
                  </Button>
                </div>
              </div>
            </div>
          </Card>

          {/* Empty State */}
          <Card title="Empty State" subtitle="Placeholder for no data">
            <EmptyState
              title="No items found"
              description="Get started by creating your first item"
              actionLabel="Create New"
              onAction={() => alert('Create new item')}
            />
          </Card>
        </div>
      </PageContainer>

      {/* Modal Component */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Example Modal"
        size="md"
        footer={
          <>
            <Button variant="outline" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={() => setModalOpen(false)}>
              Confirm
            </Button>
          </>
        }
      >
        <p className="text-gray-700 dark:text-gray-300">
          This is an example modal dialog. You can put any content here including
          forms, images, or other components.
        </p>
      </Modal>

      {/* Toast Container */}
      <ToastContainer toasts={toasts} removeToast={removeToast} />
    </>
  );
};

export default ComponentShowcase;

