import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Phone, Calendar, MessageSquare, CheckCircle, Clock, ArrowRight, Filter } from 'lucide-react';
import PageContainer from '../components/layout/PageContainer';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Badge from '../components/ui/Badge';
import EmptyState from '../components/ui/EmptyState';
import AddCallRecord from '../components/leads/AddCallRecord';
import FollowUpBadge from '../components/leads/FollowUpBadge';
import { useToast } from '../hooks/useToast';
import { subscribeToFollowUps, markFollowUpDone, rescheduleFollowUp } from '../services/callHistoryService';
import { formatIndianPhone } from '../utils/phoneFormat';

const FollowUps = () => {
  const navigate = useNavigate();
  const { success, showError } = useToast();
  const [followUps, setFollowUps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLead, setSelectedLead] = useState(null);
  const [showCallModal, setShowCallModal] = useState(false);
  const [showRescheduleModal, setShowRescheduleModal] = useState(false);
  const [rescheduleDate, setRescheduleDate] = useState('');

  useEffect(() => {
    const unsubscribe = subscribeToFollowUps((data) => {
      setFollowUps(data);
      setLoading(false);
    }, filter);

    return () => unsubscribe();
  }, [filter]);

  const handleCall = (phone) => {
    if (phone) {
      const phoneNumber = phone.replace(/\D/g, '');
      const cleanPhone = phoneNumber.startsWith('91') ? phoneNumber.slice(2) : phoneNumber;
      window.location.href = `tel:+91${cleanPhone}`;
    }
  };

  const handleMarkDone = async (lead) => {
    if (window.confirm('Mark this follow-up as done and convert to deal?')) {
      try {
        await markFollowUpDone(lead.id);
        success('Follow-up marked as done! Opening deal form...');
        // Navigate directly to deal conversion form for this lead
        navigate(`/deals/convert/${lead.id}`);
      } catch (error) {
        console.error('Error marking follow-up done:', error);
        showError('Failed to mark follow-up as done');
      }
    }
  };

  const handleReschedule = async (leadId) => {
    if (!rescheduleDate) {
      showError('Please select a date');
      return;
    }

    const selectedDate = new Date(rescheduleDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    selectedDate.setHours(0, 0, 0, 0);

    if (selectedDate.getTime() < today.getTime()) {
      showError('Date cannot be in the past');
      return;
    }

    try {
      await rescheduleFollowUp(leadId, rescheduleDate);
      success('Follow-up rescheduled!');
      setShowRescheduleModal(false);
      setRescheduleDate('');
      setSelectedLead(null);
    } catch (error) {
      console.error('Error rescheduling:', error);
      showError('Failed to reschedule follow-up');
    }
  };

  const handleConvertToDeal = (leadId) => {
    navigate(`/deals/convert/${leadId}`);
  };

  const filteredFollowUps = followUps.filter((fu) => {
    const matchesSearch = 
      fu.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      fu.phone?.includes(searchTerm);
    return matchesSearch;
  });

  const groupedFollowUps = {
    overdue: [],
    today: [],
    tomorrow: [],
    thisWeek: [],
    later: [],
  };

  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const weekEnd = new Date(now);
  weekEnd.setDate(weekEnd.getDate() + 7);

  filteredFollowUps.forEach((fu) => {
    const followUpDate = fu.followUpDate?.toDate 
      ? fu.followUpDate.toDate() 
      : new Date(fu.followUpDate);
    followUpDate.setHours(0, 0, 0, 0);

    const diffTime = followUpDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      groupedFollowUps.overdue.push(fu);
    } else if (diffDays === 0) {
      groupedFollowUps.today.push(fu);
    } else if (diffDays === 1) {
      groupedFollowUps.tomorrow.push(fu);
    } else if (diffDays <= 7) {
      groupedFollowUps.thisWeek.push(fu);
    } else {
      groupedFollowUps.later.push(fu);
    }
  });

  const renderFollowUpCard = (lead) => {
    const followUpDate = lead.followUpDate?.toDate 
      ? lead.followUpDate.toDate() 
      : new Date(lead.followUpDate);

    return (
      <Card key={lead.id} className="hover:shadow-md transition-shadow">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-gray-900 dark:text-white truncate">
                {lead.name || 'Unknown'}
              </h3>
              <FollowUpBadge followUpDate={lead.nextFollowUp} />
            </div>
            
            <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400 mb-3">
              <div className="flex items-center gap-2">
                <Phone size={14} />
                <span>{formatIndianPhone(lead.phone)}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar size={14} />
                <span>
                  {followUpDate.toLocaleDateString('en-IN', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                  })}
                </span>
              </div>
              {lead.lastRemark && (
                <div className="flex items-start gap-2 mt-2">
                  <MessageSquare size={14} className="mt-0.5 flex-shrink-0" />
                  <span className="text-xs line-clamp-2">{lead.lastRemark}</span>
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-2 mt-3">
              <Button
                variant="primary"
                size="sm"
                icon={<Phone size={14} />}
                onClick={() => handleCall(lead.phone)}
                className="text-xs"
              >
                Call Now
              </Button>
              <Button
                variant="outline"
                size="sm"
                icon={<MessageSquare size={14} />}
                onClick={() => {
                  setSelectedLead(lead);
                  setShowCallModal(true);
                }}
                className="text-xs"
              >
                Add Call
              </Button>
              <Button
                variant="primary"
                size="sm"
                icon={<CheckCircle size={14} />}
                onClick={() => handleMarkDone(lead)}
                className="text-xs"
              >
                Done & Convert
              </Button>
              <Button
                variant="outline"
                size="sm"
                icon={<Calendar size={14} />}
                onClick={() => {
                  setSelectedLead(lead);
                  setRescheduleDate(followUpDate.toISOString().split('T')[0]);
                  setShowRescheduleModal(true);
                }}
                className="text-xs"
              >
                Reschedule
              </Button>
              <Button
                variant="outline"
                size="sm"
                icon={<ArrowRight size={14} />}
                onClick={() => handleConvertToDeal(lead.id)}
                className="text-xs"
              >
                Convert
              </Button>
            </div>
          </div>
        </div>
      </Card>
    );
  };

  const renderGroup = (title, leads, color) => {
    if (leads.length === 0) return null;

    return (
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-4">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white">{title}</h2>
          <Badge variant={color}>{leads.length}</Badge>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {leads.map(renderFollowUpCard)}
        </div>
      </div>
    );
  };

  return (
    <PageContainer
      title="Follow-ups"
      subtitle="Manage your pending follow-ups"
      actions={
        <div className="flex gap-2">
          <Input
            placeholder="Search leads..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full sm:w-64"
          />
        </div>
      }
    >
      <div className="space-y-6">
        {/* Filters */}
        <Card>
          <div className="flex flex-wrap gap-2">
            {['all', 'overdue', 'today', 'tomorrow', 'thisWeek'].map((filterType) => (
              <Button
                key={filterType}
                variant={filter === filterType ? 'primary' : 'outline'}
                size="sm"
                onClick={() => setFilter(filterType)}
                icon={<Filter size={14} />}
              >
                {filterType === 'all' ? 'All' :
                 filterType === 'overdue' ? 'Overdue' :
                 filterType === 'today' ? 'Today' :
                 filterType === 'tomorrow' ? 'Tomorrow' :
                 'This Week'}
              </Button>
            ))}
          </div>
        </Card>

        {loading ? (
          <Card>
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
            </div>
          </Card>
        ) : filteredFollowUps.length === 0 ? (
          <Card>
            <EmptyState
              icon={Calendar}
              title="No Follow-ups"
              description={
                filter === 'all'
                  ? "You don't have any follow-ups scheduled"
                  : `No ${filter} follow-ups found`
              }
            />
          </Card>
        ) : (
          <div>
            {renderGroup('Overdue', groupedFollowUps.overdue, 'danger')}
            {renderGroup('Today', groupedFollowUps.today, 'warning')}
            {renderGroup('Tomorrow', groupedFollowUps.tomorrow, 'warning')}
            {renderGroup('This Week', groupedFollowUps.thisWeek, 'info')}
            {renderGroup('Later', groupedFollowUps.later, 'secondary')}
          </div>
        )}
      </div>

      {/* Add Call Record Modal */}
      {selectedLead && (
        <AddCallRecord
          isOpen={showCallModal}
          onClose={() => {
            setShowCallModal(false);
            setSelectedLead(null);
          }}
          leadId={selectedLead.id}
          leadName={selectedLead.name}
          onSuccess={() => {
            // Refresh will happen automatically via subscription
          }}
        />
      )}

      {/* Reschedule Modal */}
      {showRescheduleModal && selectedLead && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Reschedule Follow-up</h3>
            <div className="space-y-4">
              <Input
                label="New Follow-up Date"
                type="date"
                value={rescheduleDate}
                onChange={(e) => setRescheduleDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                required
              />
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  fullWidth
                  onClick={() => {
                    setShowRescheduleModal(false);
                    setRescheduleDate('');
                    setSelectedLead(null);
                  }}
                >
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  fullWidth
                  onClick={() => handleReschedule(selectedLead.id)}
                >
                  Reschedule
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </PageContainer>
  );
};

export default FollowUps;

