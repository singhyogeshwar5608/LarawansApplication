import jsPDF from 'jspdf';
import { getBusinessProfile } from '../services/settingsService';

/**
 * Load logo image as base64
 */
const loadLogoAsBase64 = async () => {
  try {
    // Try to load logo from public/assets or assets folder
    const logoPath = '/src/assets/Logo.png';
    const response = await fetch(logoPath);
    if (response.ok) {
      const blob = await response.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = () => resolve(null);
        reader.readAsDataURL(blob);
      });
    }
  } catch (error) {
    // Try alternative path
    try {
      const altPath = '/assets/Logo.png';
      const response = await fetch(altPath);
      if (response.ok) {
        const blob = await response.blob();
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.onerror = () => resolve(null);
          reader.readAsDataURL(blob);
        });
      }
    } catch (err) {
      console.log('Logo not found, using text');
    }
  }
  return null;
};

/**
 * Generate PDF Invoice for a deal (matches sample format)
 */
export const generateInvoice = (deal) => {
  const doc = new jsPDF();
  
  // Company details
  const companyName = 'Larawans Digital Agency';
  const address = [
    'Build #02, Opposite: District Court Kaithal',
    'Subash Market, Karnal Rd. Kaithal',
    'Haryana-136027',
    '+917015150181'
  ];
  
  // Invoice details
  const invoiceNumber = deal.dealId || `LWNS${deal.id.substring(0, 5).toUpperCase()}`;
  const invoiceDate = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
  
  // Customer details
  const customerName = deal.customerName || 'Customer';
  const customerPhone = deal.customerPhone || '';
  const customerAddress = deal.customerAddress || '';
  
  // Payment terms
  const paymentTerms = 'Online | Offline';
  
  // Helper function to format currency with INR format
  const formatCurrency = (amount) => {
    if (amount === null || amount === undefined) return '0.00';
    const num = typeof amount === 'string' ? parseFloat(amount.replace(/[₹,\s]/g, '')) : Number(amount);
    if (isNaN(num) || num === 0) return '0.00';
    // Format with Indian number system (commas)
    const formatted = num.toFixed(2);
    // Add commas for thousands
    const parts = formatted.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.join('.');
  };
  
  // Header section
  let yPos = 20;
  
  // Logo and company name (left side)
  // Try to load logo synchronously (will be added in async version)
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(companyName, 20, yPos + 10);
  
  // Company address
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  yPos = 35;
  address.forEach((line) => {
    doc.text(line, 20, yPos);
    yPos += 4.5;
  });
  
  // Invoice title and details (right side)
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('INVOICE', 150, 25);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Invoice # ${invoiceNumber}`, 150, 35);
  doc.text(`Date: ${invoiceDate}`, 150, 40);
  
  // BILL TO section
  yPos = 60;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('BILL TO', 20, yPos);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(customerName, 20, yPos + 6);
  
  if (customerAddress) {
    const addressLines = customerAddress.split(',').map(line => line.trim());
    addressLines.forEach((line, index) => {
      doc.text(line, 20, yPos + 11 + (index * 4.5));
    });
    yPos += addressLines.length * 4.5;
  }
  
  if (customerPhone) {
    doc.text(customerPhone, 20, yPos + 11);
  }
  
  // PAYMENT section
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('PAYMENT', 150, 60);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Payment Terms: ${paymentTerms}`, 150, 66);
  
  // Items table
  yPos = 85;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  
  // Table header
  doc.setFillColor(240, 240, 240);
  doc.rect(20, yPos - 5, 170, 8, 'F');
  
  doc.text('ITEM', 22, yPos);
  doc.text('QUANTITY', 100, yPos, { align: 'center' });
  doc.text('RATE', 140, yPos, { align: 'center' });
  doc.text('AMOUNT', 190, yPos, { align: 'right' });
  
  // Services/Items
  yPos += 10;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  
  if (deal.services && deal.services.length > 0) {
    deal.services.forEach((service, index) => {
      const quantity = 1; // Default quantity
      const rate = deal.totalAmount / deal.services.length; // Distribute amount
      const amount = rate;
      
      // Service name with includes if available
      let serviceLines = [service];
      if (deal.facilities && deal.facilities.length > 0 && index === 0) {
        serviceLines.push('Include:');
        deal.facilities.slice(0, 3).forEach(facility => {
          serviceLines.push(facility);
        });
      }
      
      // Print service name and includes with proper alignment
      let currentY = yPos;
      serviceLines.forEach((line, lineIndex) => {
        doc.text(line, 22, currentY);
        if (lineIndex === 0) {
          // Only show quantity, rate, amount on first line - properly aligned
          doc.text(quantity.toString(), 100, currentY, { align: 'center' });
          doc.text(`₹${formatCurrency(rate)}`, 140, currentY, { align: 'center' });
          doc.text(`₹${formatCurrency(amount)}`, 190, currentY, { align: 'right' });
        }
        currentY += 4.5;
      });
      
      yPos = currentY + 2;
    });
  } else {
    // Single item
    const quantity = 1;
    const rate = deal.totalAmount;
    doc.text('Services', 22, yPos);
    doc.text(quantity.toString(), 100, yPos, { align: 'center' });
    doc.text(`₹${formatCurrency(rate)}`, 140, yPos, { align: 'center' });
    doc.text(`₹${formatCurrency(rate)}`, 190, yPos, { align: 'right' });
    yPos += 8;
  }
  
  // Summary section
  yPos += 5;
  const lineY = yPos;
  doc.line(20, lineY, 190, lineY);
  
  yPos += 8;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text('Subtotal', 140, yPos, { align: 'right' });
  doc.text(`₹${formatCurrency(deal.totalAmount)}`, 190, yPos, { align: 'right' });
  
  // Calculate discount if any
  const discount = deal.discount || 0;
  if (discount > 0) {
    yPos += 6;
    doc.text('Discount', 140, yPos, { align: 'right' });
    doc.text(`₹${formatCurrency(discount)}`, 190, yPos, { align: 'right' });
  }
  
  // Tax
  const tax = deal.tax || 0;
  const taxPercent = deal.taxPercent || 0;
  yPos += 6;
  doc.text(`Tax (${taxPercent}%)`, 140, yPos, { align: 'right' });
  doc.text(`₹${formatCurrency(tax)}`, 190, yPos, { align: 'right' });
  
  // Total
  yPos += 8;
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Total', 140, yPos, { align: 'right' });
  const finalTotal = deal.totalAmount - discount + tax;
  doc.text(`₹${formatCurrency(finalTotal)}`, 190, yPos, { align: 'right' });
  
  // Notes section
  yPos += 15;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('NOTES', 20, yPos);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  if (deal.dealNotes) {
    const notesLines = doc.splitTextToSize(deal.dealNotes, 170);
    notesLines.forEach((line, index) => {
      doc.text(line, 20, yPos + 7 + (index * 5));
    });
  }
  
  // Terms section
  yPos += 20;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('TERMS', 20, yPos);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const terms = 'Please submit some token money so that we can proceed. You can pay via Google Pay, PhonePe, or UPI. Taxes are included.';
  const termsLines = doc.splitTextToSize(terms, 170);
  termsLines.forEach((line, index) => {
    doc.text(line, 20, yPos + 7 + (index * 5));
  });
  
  // Save PDF
  const fileName = `Invoice # ${invoiceNumber}.pdf`;
  doc.save(fileName);
  
  // Return PDF as blob for WhatsApp sharing
  return doc.output('blob');
};

/**
 * Generate invoice with logo (async version)
 */
export const generateInvoiceWithLogo = async (deal, userId = null) => {
  const doc = new jsPDF();
  
  // Fetch business profile settings if userId provided
  let businessSettings = null;
  if (userId) {
    try {
      businessSettings = await getBusinessProfile(userId);
    } catch (error) {
      console.error('Error loading business settings:', error);
    }
  }
  
  // Company details - use from settings or defaults
  const companyName = businessSettings?.companyName || 'Larawans Digital Agency';
  const address = businessSettings?.address 
    ? [
        businessSettings.address,
        businessSettings.city ? `${businessSettings.city}, ${businessSettings.state || ''}`.trim() : '',
        businessSettings.pincode || '',
        businessSettings.phone || '+917015150181'
      ].filter(Boolean)
    : [
        'Build #02, Opposite: District Court Kaithal',
        'Subash Market, Karnal Rd. Kaithal',
        'Haryana-136027',
        '+917015150181'
      ];
  
  // Invoice details
  const invoicePrefix = businessSettings?.invoicePrefix || 'INV-';
  const invoiceNumber = deal.dealId || `${invoicePrefix}${deal.id.substring(0, 5).toUpperCase()}`;
  const invoiceDate = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
  
  // Customer details
  const customerName = deal.customerName || 'Customer';
  const customerPhone = deal.customerPhone || '';
  const customerAddress = deal.customerAddress || '';
  
  // Payment terms
  const paymentTerms = 'Online | Offline';
  
  // Helper function to format currency with INR format (no currency symbol in format, we add ₹ separately)
  const formatCurrency = (amount) => {
    if (amount === null || amount === undefined) return '0.00';
    const num = typeof amount === 'string' ? parseFloat(amount.replace(/[₹,\s]/g, '')) : Number(amount);
    if (isNaN(num) || num === 0) return '0.00';
    // Format with Indian number system (commas)
    const formatted = num.toFixed(2);
    // Add commas for thousands
    const parts = formatted.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.join('.');
  };
  
  // Try to load logo
  const logoBase64 = await loadLogoAsBase64();
  
  // Header section
  let yPos = 20;
  
  // Logo and company name (left side)
  if (logoBase64) {
    try {
      doc.addImage(logoBase64, 'PNG', 20, yPos, 15, 15);
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(companyName, 38, yPos + 10);
    } catch (error) {
      // Fallback to text if image fails
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(companyName, 20, yPos + 10);
    }
  } else {
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text(companyName, 20, yPos + 10);
  }
  
  // Company address
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  yPos = 35;
  address.forEach((line) => {
    doc.text(line, 20, yPos);
    yPos += 4.5;
  });
  
  // Invoice title and details (right side)
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('INVOICE', 150, 25);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Invoice # ${invoiceNumber}`, 150, 35);
  doc.text(`Date: ${invoiceDate}`, 150, 40);
  
  // BILL TO section
  yPos = 60;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('BILL TO', 20, yPos);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(customerName, 20, yPos + 6);
  
  if (customerAddress) {
    const addressLines = customerAddress.split(',').map(line => line.trim());
    addressLines.forEach((line, index) => {
      doc.text(line, 20, yPos + 11 + (index * 4.5));
    });
    yPos += addressLines.length * 4.5;
  }
  
  if (customerPhone) {
    doc.text(customerPhone, 20, yPos + 11);
  }
  
  // PAYMENT section
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('PAYMENT', 150, 60);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Payment Terms: ${paymentTerms}`, 150, 66);
  
  // Items table
  yPos = 85;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  
  // Table header
  doc.setFillColor(240, 240, 240);
  doc.rect(20, yPos - 5, 170, 8, 'F');
  
  doc.text('ITEM', 22, yPos);
  doc.text('QUANTITY', 100, yPos, { align: 'center' });
  doc.text('RATE', 140, yPos, { align: 'center' });
  doc.text('AMOUNT', 190, yPos, { align: 'right' });
  
  // Services/Items
  yPos += 10;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  
  if (deal.services && deal.services.length > 0) {
    deal.services.forEach((service, index) => {
      const quantity = 1; // Default quantity
      const rate = deal.totalAmount / deal.services.length; // Distribute amount
      const amount = rate;
      
      // Service name with includes if available
      let serviceLines = [service];
      if (deal.facilities && deal.facilities.length > 0 && index === 0) {
        serviceLines.push('Include:');
        deal.facilities.slice(0, 3).forEach(facility => {
          serviceLines.push(facility);
        });
      }
      
      // Print service name and includes with proper alignment
      let currentY = yPos;
      serviceLines.forEach((line, lineIndex) => {
        doc.text(line, 22, currentY);
        if (lineIndex === 0) {
          // Only show quantity, rate, amount on first line - properly aligned
          doc.text(quantity.toString(), 100, currentY, { align: 'center' });
          doc.text(`₹${formatCurrency(rate)}`, 140, currentY, { align: 'center' });
          doc.text(`₹${formatCurrency(amount)}`, 190, currentY, { align: 'right' });
        }
        currentY += 4.5;
      });
      
      yPos = currentY + 2;
    });
  } else {
    // Single item
    const quantity = 1;
    const rate = deal.totalAmount;
    doc.text('Services', 22, yPos);
    doc.text(quantity.toString(), 100, yPos, { align: 'center' });
    doc.text(`₹${formatCurrency(rate)}`, 140, yPos, { align: 'center' });
    doc.text(`₹${formatCurrency(rate)}`, 190, yPos, { align: 'right' });
    yPos += 8;
  }
  
  // Summary section
  yPos += 5;
  const lineY = yPos;
  doc.line(20, lineY, 190, lineY);
  
  yPos += 8;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text('Subtotal', 140, yPos, { align: 'right' });
  doc.text(`₹${formatCurrency(deal.totalAmount)}`, 190, yPos, { align: 'right' });
  
  // Calculate discount if any
  const discount = deal.discount || 0;
  if (discount > 0) {
    yPos += 6;
    doc.text('Discount', 140, yPos, { align: 'right' });
    doc.text(`₹${formatCurrency(discount)}`, 190, yPos, { align: 'right' });
  }
  
  // Tax
  const tax = deal.tax || 0;
  const taxPercent = deal.taxPercent || 0;
  yPos += 6;
  doc.text(`Tax (${taxPercent}%)`, 140, yPos, { align: 'right' });
  doc.text(`₹${formatCurrency(tax)}`, 190, yPos, { align: 'right' });
  
  // Total
  yPos += 8;
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Total', 140, yPos, { align: 'right' });
  const finalTotal = deal.totalAmount - discount + tax;
  doc.text(`₹${formatCurrency(finalTotal)}`, 190, yPos, { align: 'right' });
  
  // Notes section
  yPos += 15;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('NOTES', 20, yPos);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  if (deal.dealNotes) {
    const notesLines = doc.splitTextToSize(deal.dealNotes, 170);
    notesLines.forEach((line, index) => {
      doc.text(line, 20, yPos + 7 + (index * 5));
    });
  }
  
  // Terms section
  yPos += 20;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('TERMS', 20, yPos);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const terms = 'Please submit some token money so that we can proceed. You can pay via Google Pay, PhonePe, or UPI. Taxes are included.';
  const termsLines = doc.splitTextToSize(terms, 170);
  termsLines.forEach((line, index) => {
    doc.text(line, 20, yPos + 7 + (index * 5));
  });
  
  // Save PDF
  const fileName = `Invoice # ${invoiceNumber}.pdf`;
  doc.save(fileName);
  
  // Return PDF as blob for WhatsApp sharing
  return doc.output('blob');
};

/**
 * Generate invoice and share via WhatsApp
 */
export const generateAndShareInvoice = async (deal, userId = null) => {
  try {
    // Generate PDF with logo
    const pdfBlob = await generateInvoiceWithLogo(deal, userId);
    
    // Create message
    const invoiceNumber = deal.dealId || `LWNS${deal.id.substring(0, 5).toUpperCase()}`;
    const message = `Hi ${deal.customerName}! 👋

Your invoice has been generated:
📄 Invoice #${invoiceNumber}

💰 Payment Summary:
Total: ₹${deal.totalAmount.toLocaleString('en-IN')}
Paid: ₹${deal.paidAmount.toLocaleString('en-IN')} ✅
Pending: ₹${deal.pendingAmount.toLocaleString('en-IN')} ⏳

Services: ${deal.services?.join(', ') || 'N/A'}

Please find the invoice PDF attached.

Thank you for your business!`;

    // Get WhatsApp link
    const phoneNumber = deal.customerPhone.replace(/\D/g, '');
    const cleanPhone = phoneNumber.startsWith('91') ? phoneNumber.slice(2) : phoneNumber;
    const whatsappUrl = `https://wa.me/91${cleanPhone}?text=${encodeURIComponent(message)}`;
    
    // Open WhatsApp
    window.open(whatsappUrl, '_blank');
    
    // Note: User will need to manually attach the PDF as browser WhatsApp doesn't support programmatic file attachment
    // The PDF is already downloaded, user can attach it manually
    
    return { success: true, message: 'Invoice generated! Please attach the downloaded PDF to your WhatsApp message.' };
  } catch (error) {
    console.error('Error generating and sharing invoice:', error);
    throw error;
  }
};
