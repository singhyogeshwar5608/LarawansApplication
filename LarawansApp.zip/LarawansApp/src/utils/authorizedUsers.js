// Authorized Users - Users who can see each other's data
// All other users will have isolated data

const AUTHORIZED_USER_EMAILS = [
  'ravinder@larawans.com',
  'yogeshwar@larwans.com', // Note: user provided this exact spelling
  'pardeep@larawans.com',
];

/**
 * Check if a user email is authorized (can see shared data)
 */
export const isAuthorizedUser = (userEmail) => {
  if (!userEmail) return false;
  return AUTHORIZED_USER_EMAILS.includes(userEmail.toLowerCase());
};

/**
 * Get authorized user emails list
 */
export const getAuthorizedEmails = () => {
  return [...AUTHORIZED_USER_EMAILS];
};

/**
 * Check if current user should see all data (authorized) or only their own
 */
export const shouldSeeAllData = (userEmail) => {
  return isAuthorizedUser(userEmail);
};

