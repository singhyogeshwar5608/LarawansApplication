/**
 * Format phone number to Indian format: +91-XXXXX-XXXXX
 */
export const formatIndianPhone = (phone) => {
  if (!phone) return '';
  
  // If already formatted correctly, return as is
  if (phone.match(/^\+91-\d{5}-\d{5}$/)) {
    return phone;
  }
  
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, '');
  
  // If it starts with 91, remove it (we'll add it back)
  const cleanDigits = digits.startsWith('91') ? digits.slice(2) : digits;
  
  // Ensure it's 10 digits
  if (cleanDigits.length !== 10) {
    return phone; // Return original if not 10 digits
  }
  
  // Format as +91-XXXXX-XXXXX
  return `+91-${cleanDigits.slice(0, 5)}-${cleanDigits.slice(5)}`;
};

/**
 * Get clean phone number for tel: links
 */
export const getCleanPhone = (phone) => {
  if (!phone) return '';
  return phone.replace(/\D/g, '');
};

/**
 * Get WhatsApp link for phone number
 */
export const getWhatsAppLink = (phone) => {
  const cleanPhone = getCleanPhone(phone);
  // Remove leading 91 if present, we'll add it in the link
  const phoneNumber = cleanPhone.startsWith('91') ? cleanPhone.slice(2) : cleanPhone;
  return `https://wa.me/91${phoneNumber}`;
};

