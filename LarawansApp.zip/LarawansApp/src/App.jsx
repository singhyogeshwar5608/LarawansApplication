import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { useToast } from './hooks/useToast';
import { ToastContainer } from './components/ui/Toast';
import MainLayout from './components/layout/MainLayout';
import ProtectedRoute from './components/auth/ProtectedRoute';
import Dashboard from './pages/Dashboard';
import Leads from './pages/Leads';
import AddLead from './pages/AddLead';
import LeadDetail from './pages/LeadDetail';
import EditLead from './pages/EditLead';
import Analytics from './pages/Analytics';
import Settings from './pages/Settings';
import SettingsMain from './pages/settings/SettingsMain';
import ProfileSettings from './pages/settings/ProfileSettings';
import TeamManagement from './pages/settings/TeamManagement';
import BusinessProfile from './pages/settings/BusinessProfile';
import AdminPanel from './pages/settings/AdminPanel';
import DataManagement from './pages/settings/DataManagement';
import Preferences from './pages/settings/Preferences';
import ChangePassword from './pages/settings/ChangePassword';
import FollowUps from './pages/FollowUps';
import Expenses from './pages/Expenses';
import ComponentShowcase from './pages/ComponentShowcase';
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';
import ForgotPassword from './pages/auth/ForgotPassword';
import DealsList from './pages/deals/DealsList';
import DealConversion from './pages/deals/DealConversion';
import DealDetail from './pages/deals/DealDetail';
import EditDeal from './pages/deals/EditDeal';
import DealSuccess from './pages/deals/DealSuccess';

function App() {
  const { toasts, removeToast } = useToast();

  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            {/* Auth Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            
            {/* Main App Routes - Protected */}
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <MainLayout />
                </ProtectedRoute>
              }
            >
              <Route index element={<Dashboard />} />
              <Route path="leads" element={<Leads />} />
              <Route path="leads/new" element={<AddLead />} />
              <Route path="leads/:id" element={<LeadDetail />} />
              <Route path="leads/:id/edit" element={<EditLead />} />
              <Route path="deals" element={<DealsList />} />
              <Route path="deals/convert/:id" element={<DealConversion />} />
              <Route path="deals/success/:id" element={<DealSuccess />} />
              <Route path="deals/:id" element={<DealDetail />} />
              <Route path="deals/:id/edit" element={<EditDeal />} />
              <Route path="analytics" element={<Analytics />} />
              <Route path="followups" element={<FollowUps />} />
              <Route path="expenses" element={<Expenses />} />
              <Route path="settings" element={<Settings />} />
              <Route path="settings/profile" element={<ProfileSettings />} />
              <Route path="settings/team" element={<TeamManagement />} />
              <Route path="settings/business" element={<BusinessProfile />} />
              <Route path="settings/admin" element={<AdminPanel />} />
              <Route path="settings/data" element={<DataManagement />} />
              <Route path="settings/preferences" element={<Preferences />} />
              <Route path="settings/password" element={<ChangePassword />} />
              <Route path="showcase" element={<ComponentShowcase />} />
            </Route>
            
            {/* Redirect unknown routes */}
            <Route path="*" element={<Navigate to="/" replace />} />
            
            {/* Redirect root to dashboard if authenticated, else to login */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
          <ToastContainer toasts={toasts} removeToast={removeToast} />
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;

