// Call History Service - Firebase operations for call tracking and follow-ups

import {
  collection,
  doc,
  updateDoc,
  getDoc,
  serverTimestamp,
  Timestamp,
  query,
  where,
  getDocs,
  onSnapshot,
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { getCurrentUser } from './authService';
import { isAuthorizedUser } from '../utils/authorizedUsers';

const LEADS_COLLECTION = 'leads';

/**
 * Add a new call record to a lead's call history
 */
export const addCallRecord = async (leadId, callData) => {
  try {
    const leadRef = doc(db, LEADS_COLLECTION, leadId);
    const leadSnap = await getDoc(leadRef);

    if (!leadSnap.exists()) {
      throw new Error('Lead not found');
    }

    const leadData = leadSnap.data();
    const existingHistory = leadData.callHistory || [];

    // Convert calledAt to Firestore Timestamp
    const callDate = callData.calledAt instanceof Date 
      ? callData.calledAt 
      : new Date(callData.calledAt || Date.now());
    const callTimestamp = Timestamp.fromDate(callDate);
    
    // Convert followUpDate to proper format - keep as string (YYYY-MM-DD) for Firestore
    let followUpDateValue = callData.followUpDate || null;
    if (followUpDateValue) {
      // If it's a Date object, convert to YYYY-MM-DD string
      if (followUpDateValue instanceof Date) {
        const year = followUpDateValue.getFullYear();
        const month = String(followUpDateValue.getMonth() + 1).padStart(2, '0');
        const day = String(followUpDateValue.getDate()).padStart(2, '0');
        followUpDateValue = `${year}-${month}-${day}`;
      } else if (typeof followUpDateValue === 'string' && followUpDateValue.includes('T')) {
        // If it's an ISO string, extract just the date part
        followUpDateValue = followUpDateValue.split('T')[0];
      }
      // If it's already in YYYY-MM-DD format, keep it as is
    }
    
    const newCall = {
      id: `call_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      calledAt: callTimestamp,
      remark: callData.remark || '',
      followUpDate: followUpDateValue,
      followUpTime: callData.followUpTime || null,
      calledBy: callData.calledBy || 'User',
      duration: callData.duration || 'N/A',
    };

    const updatedHistory = [newCall, ...existingHistory];
    const totalCalls = updatedHistory.length;
    
    // Convert lastCallDate to Firestore Timestamp
    const lastCallDate = Timestamp.fromDate(callDate);
    
    const nextFollowUp = followUpDateValue || leadData.nextFollowUp || null;
    const lastRemark = newCall.remark;

    await updateDoc(leadRef, {
      callHistory: updatedHistory,
      lastCallDate: lastCallDate,
      nextFollowUp: nextFollowUp,
      totalCalls: totalCalls,
      lastRemark: lastRemark,
      updatedAt: serverTimestamp(),
    });

    return { success: true, callId: newCall.id };
  } catch (error) {
    console.error('Error adding call record:', error);
    throw error;
  }
};

/**
 * Get call history for a lead
 */
export const getCallHistory = async (leadId) => {
  try {
    const leadRef = doc(db, LEADS_COLLECTION, leadId);
    const leadSnap = await getDoc(leadRef);

    if (!leadSnap.exists()) {
      return [];
    }

    const leadData = leadSnap.data();
    return leadData.callHistory || [];
  } catch (error) {
    console.error('Error getting call history:', error);
    throw error;
  }
};

/**
 * Update follow-up date for a lead
 */
export const updateFollowUp = async (leadId, followUpDate) => {
  try {
    const leadRef = doc(db, LEADS_COLLECTION, leadId);
    await updateDoc(leadRef, {
      nextFollowUp: followUpDate || null,
      updatedAt: serverTimestamp(),
    });
    return { success: true };
  } catch (error) {
    console.error('Error updating follow-up:', error);
    throw error;
  }
};

/**
 * Get all leads with pending follow-ups
 * Filters data based on user authorization
 */
export const getFollowUps = async (filterType = 'all') => {
  try {
    const currentUser = getCurrentUser();
    const userEmail = currentUser?.email || '';
    const userId = currentUser?.uid || '';
    const isAuthorized = isAuthorizedUser(userEmail);
    
    const leadsRef = collection(db, LEADS_COLLECTION);
    const querySnapshot = await getDocs(leadsRef);
    
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const weekEnd = new Date(now);
    weekEnd.setDate(weekEnd.getDate() + 7);

    const followUps = [];

    querySnapshot.forEach((doc) => {
      const lead = { id: doc.id, ...doc.data() };
      
      // Filter based on authorization
      if (!isAuthorized) {
        // Other users see only their own leads
        if (lead.userId !== userId && lead.userId && lead.userEmail) {
          return; // Skip this lead
        }
      }
      // Authorized users see all leads (continue processing)
      
      if (!lead.nextFollowUp) return;

      const followUpDate = lead.nextFollowUp?.toDate 
        ? lead.nextFollowUp.toDate() 
        : new Date(lead.nextFollowUp);
      
      followUpDate.setHours(0, 0, 0, 0);

      let include = false;

      switch (filterType) {
        case 'today':
          include = followUpDate.getTime() === now.getTime();
          break;
        case 'tomorrow':
          include = followUpDate.getTime() === tomorrow.getTime();
          break;
        case 'overdue':
          include = followUpDate.getTime() < now.getTime();
          break;
        case 'thisWeek':
          include = followUpDate.getTime() >= now.getTime() && 
                   followUpDate.getTime() <= weekEnd.getTime();
          break;
        default:
          include = true;
      }

      if (include) {
        followUps.push({
          ...lead,
          followUpDate: followUpDate,
        });
      }
    });

    // Sort by follow-up date (overdue first, then by date)
    followUps.sort((a, b) => {
      const dateA = a.followUpDate.getTime();
      const dateB = b.followUpDate.getTime();
      const nowTime = now.getTime();
      
      // Overdue items first
      if (dateA < nowTime && dateB >= nowTime) return -1;
      if (dateA >= nowTime && dateB < nowTime) return 1;
      
      // Then sort by date
      return dateA - dateB;
    });

    return followUps;
  } catch (error) {
    console.error('Error getting follow-ups:', error);
    throw error;
  }
};

/**
 * Subscribe to follow-ups (real-time)
 * Filters data based on user authorization
 */
export const subscribeToFollowUps = (callback, filterType = 'all') => {
  const leadsRef = collection(db, LEADS_COLLECTION);
  const currentUser = getCurrentUser();
  const userEmail = currentUser?.email || '';
  const userId = currentUser?.uid || '';
  const isAuthorized = isAuthorizedUser(userEmail);
  
  return onSnapshot(leadsRef, async (querySnapshot) => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const weekEnd = new Date(now);
    weekEnd.setDate(weekEnd.getDate() + 7);

    const followUps = [];

    querySnapshot.forEach((doc) => {
      const lead = { id: doc.id, ...doc.data() };
      
      // Filter based on authorization
      if (!isAuthorized) {
        // Other users see only their own leads
        if (lead.userId !== userId && lead.userId && lead.userEmail) {
          return; // Skip this lead
        }
      }
      // Authorized users see all leads (continue processing)
      
      if (!lead.nextFollowUp) return;

      const followUpDate = lead.nextFollowUp?.toDate 
        ? lead.nextFollowUp.toDate() 
        : new Date(lead.nextFollowUp);
      
      followUpDate.setHours(0, 0, 0, 0);

      let include = false;

      switch (filterType) {
        case 'today':
          include = followUpDate.getTime() === now.getTime();
          break;
        case 'tomorrow':
          include = followUpDate.getTime() === tomorrow.getTime();
          break;
        case 'overdue':
          include = followUpDate.getTime() < now.getTime();
          break;
        case 'thisWeek':
          include = followUpDate.getTime() >= now.getTime() && 
                   followUpDate.getTime() <= weekEnd.getTime();
          break;
        default:
          include = true;
      }

      if (include) {
        followUps.push({
          ...lead,
          followUpDate: followUpDate,
        });
      }
    });

    // Sort by follow-up date
    followUps.sort((a, b) => {
      const dateA = a.followUpDate.getTime();
      const dateB = b.followUpDate.getTime();
      const nowTime = now.getTime();
      
      if (dateA < nowTime && dateB >= nowTime) return -1;
      if (dateA >= nowTime && dateB < nowTime) return 1;
      
      return dateA - dateB;
    });

    callback(followUps);
  });
};

/**
 * Mark follow-up as done
 * Also updates lead status to "interested" and clears nextFollowUp
 */
export const markFollowUpDone = async (leadId, nextFollowUpDate = null) => {
  try {
    const leadRef = doc(db, LEADS_COLLECTION, leadId);
    await updateDoc(leadRef, {
      status: 'interested', // Mark as interested when follow-up is done
      nextFollowUp: nextFollowUpDate || null, // Clear follow-up date
      updatedAt: serverTimestamp(),
    });
    return { success: true };
  } catch (error) {
    console.error('Error marking follow-up done:', error);
    throw error;
  }
};

/**
 * Reschedule follow-up
 */
export const rescheduleFollowUp = async (leadId, newDate) => {
  try {
    const leadRef = doc(db, LEADS_COLLECTION, leadId);
    await updateDoc(leadRef, {
      nextFollowUp: newDate || null,
      updatedAt: serverTimestamp(),
    });
    return { success: true };
  } catch (error) {
    console.error('Error rescheduling follow-up:', error);
    throw error;
  }
};

/**
 * Get pending follow-ups count
 */
export const getPendingFollowUpsCount = async () => {
  try {
    const followUps = await getFollowUps('all');
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    
    return followUps.filter(fu => {
      const followUpDate = fu.followUpDate?.toDate 
        ? fu.followUpDate.toDate() 
        : new Date(fu.followUpDate);
      followUpDate.setHours(0, 0, 0, 0);
      return followUpDate.getTime() >= now.getTime();
    }).length;
  } catch (error) {
    console.error('Error getting pending count:', error);
    return 0;
  }
};

