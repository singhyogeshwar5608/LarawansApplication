// Balance Service - Firebase Firestore operations for Company Balance Management
// Uses Firebase transactions to ensure data consistency

import {
  doc,
  getDoc,
  setDoc,
  runTransaction,
  serverTimestamp,
  onSnapshot,
  updateDoc,
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { getCurrentUser } from './authService';
import { isAuthorizedUser } from '../utils/authorizedUsers';

const COMPANY_COLLECTION = 'companies';
const COMPANY_ID = 'main'; // For authorized users

/**
 * Get company ID based on user authorization
 * - Authorized users: use 'main' (shared balance)
 * - Other users: use their userId (isolated balance)
 */
const getCompanyId = () => {
  const currentUser = getCurrentUser();
  const userEmail = currentUser?.email || '';
  const userId = currentUser?.uid || '';
  
  if (isAuthorizedUser(userEmail)) {
    return COMPANY_ID; // Shared balance for authorized users
  }
  
  return userId || COMPANY_ID; // User-specific balance for others
};

/**
 * Initialize company balance (one-time setup)
 */
export const initializeCompanyBalance = async (startingBalance = 0) => {
  try {
    const companyId = getCompanyId();
    const companyRef = doc(db, COMPANY_COLLECTION, companyId);
    const companySnap = await getDoc(companyRef);
    
    if (companySnap.exists()) {
      // Already initialized
      const data = companySnap.data();
      return {
        companyId: data.companyId || companyId,
        companyName: data.companyName || 'Larawans',
        currentBalance: parseFloat(data.currentBalance || 0),
        totalRevenue: parseFloat(data.totalRevenue || 0),
        totalExpenses: parseFloat(data.totalExpenses || 0),
        currency: data.currency || '₹',
        lastUpdated: data.lastUpdated,
      };
    }
    
    // Initialize with starting balance
    const initialData = {
      companyId: companyId,
      companyName: 'Larawans',
      currentBalance: parseFloat(startingBalance),
      totalRevenue: parseFloat(startingBalance), // Starting balance counts as initial revenue
      totalExpenses: 0,
      currency: '₹',
      lastUpdated: serverTimestamp(),
    };
    
    await setDoc(companyRef, initialData);
    
    return {
      ...initialData,
      lastUpdated: new Date().toISOString(),
    };
  } catch (error) {
    console.error('Error initializing company balance:', error);
    throw error;
  }
};

/**
 * Get company balance
 */
export const getCompanyBalance = async () => {
  try {
    const companyId = getCompanyId();
    const companyRef = doc(db, COMPANY_COLLECTION, companyId);
    const companySnap = await getDoc(companyRef);
    
    if (!companySnap.exists()) {
      // Auto-initialize with 0 if doesn't exist
      return await initializeCompanyBalance(0);
    }
    
    const data = companySnap.data();
    const totalRevenue = parseFloat(data.totalRevenue || 0);
    const totalExpenses = parseFloat(data.totalExpenses || 0);
    const currentBalance = totalRevenue - totalExpenses; // Balance = Revenue - Expenses
    
    return {
      companyId: data.companyId || companyId,
      companyName: data.companyName || 'Larawans',
      currentBalance: currentBalance,
      totalRevenue: totalRevenue,
      totalExpenses: totalExpenses,
      currency: data.currency || '₹',
      lastUpdated: data.lastUpdated,
    };
  } catch (error) {
    console.error('Error getting company balance:', error);
    throw error;
  }
};

/**
 * Update balance using Firebase transaction (universal function)
 * @param {number} amount - Amount to add or deduct
 * @param {string} type - 'add' (for deals/revenue) or 'deduct' (for expenses)
 * @param {string} referenceId - ID of deal/expense (for tracking)
 * @param {string} referenceName - Name/description of deal/expense
 * @returns {Promise<number>} New balance after update
 */
export const updateBalance = async (amount, type, referenceId = null, referenceName = null) => {
  try {
    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      throw new Error('Invalid amount');
    }
    
    const companyId = getCompanyId();
    const companyRef = doc(db, COMPANY_COLLECTION, companyId);
    
    const newBalance = await runTransaction(db, async (transaction) => {
      const companyDoc = await transaction.get(companyRef);
      
      if (!companyDoc.exists()) {
        // Initialize if doesn't exist
        const initialData = {
          companyId: companyId,
          companyName: 'Larawans',
          currentBalance: type === 'add' ? amountNum : -amountNum,
          totalRevenue: type === 'add' ? amountNum : 0,
          totalExpenses: type === 'deduct' ? amountNum : 0,
          currency: '₹',
          lastUpdated: serverTimestamp(),
        };
        transaction.set(companyRef, initialData);
        return type === 'add' ? amountNum : -amountNum;
      }
      
      const currentData = companyDoc.data();
      const currentRevenue = parseFloat(currentData.totalRevenue || 0);
      const currentExpenses = parseFloat(currentData.totalExpenses || 0);
      
      let newRevenue, newExpenses;
      
      if (type === 'add') {
        // Adding revenue (from deals)
        newRevenue = currentRevenue + amountNum;
        newExpenses = currentExpenses;
      } else {
        // Deducting expense
        newRevenue = currentRevenue;
        newExpenses = currentExpenses + amountNum;
      }
      
      const newBalance = newRevenue - newExpenses;
      
      transaction.update(companyRef, {
        currentBalance: newBalance,
        totalRevenue: newRevenue,
        totalExpenses: newExpenses,
        lastUpdated: serverTimestamp(),
      });
      
      return newBalance;
    });
    
    return newBalance;
  } catch (error) {
    console.error('Error updating balance:', error);
    throw error;
  }
};

/**
 * Add revenue from deal (adds to balance)
 * @param {string} dealId - Deal ID
 * @param {number} amount - Deal amount
 * @param {string} dealName - Deal name/description
 * @returns {Promise<number>} New balance
 */
export const addRevenue = async (dealId, amount, dealName = null) => {
  try {
    return await updateBalance(amount, 'add', dealId, dealName);
  } catch (error) {
    console.error('Error adding revenue:', error);
    throw error;
  }
};

/**
 * Deduct expense (reduces balance)
 * @param {string} expenseId - Expense ID
 * @param {number} amount - Expense amount
 * @param {string} reason - Expense reason/description
 * @returns {Promise<number>} New balance
 */
export const deductExpense = async (expenseId, amount, reason = null) => {
  try {
    return await updateBalance(amount, 'deduct', expenseId, reason);
  } catch (error) {
    console.error('Error deducting expense:', error);
    throw error;
  }
};

/**
 * Adjust balance (for edit scenarios)
 * @param {number} oldAmount - Previous amount
 * @param {number} newAmount - New amount
 * @param {string} type - 'add' (for deals) or 'deduct' (for expenses)
 * @param {string} referenceId - ID of deal/expense
 * @returns {Promise<number>} New balance
 */
export const adjustBalance = async (oldAmount, newAmount, type, referenceId = null) => {
  try {
    const oldAmountNum = parseFloat(oldAmount || 0);
    const newAmountNum = parseFloat(newAmount || 0);
    
    if (oldAmountNum === newAmountNum) {
      // No change, return current balance
      const balance = await getCompanyBalance();
      return balance.currentBalance;
    }
    
    const difference = newAmountNum - oldAmountNum;
    
    if (type === 'add') {
      // For deals: if amount increased, add difference; if decreased, deduct difference
      if (difference > 0) {
        return await updateBalance(difference, 'add', referenceId);
      } else {
        return await updateBalance(Math.abs(difference), 'deduct', referenceId);
      }
    } else {
      // For expenses: if amount increased, deduct difference; if decreased, add difference
      if (difference > 0) {
        return await updateBalance(difference, 'deduct', referenceId);
      } else {
        return await updateBalance(Math.abs(difference), 'add', referenceId);
      }
    }
  } catch (error) {
    console.error('Error adjusting balance:', error);
    throw error;
  }
};

/**
 * Revert balance (for delete scenarios)
 * @param {number} amount - Amount to revert
 * @param {string} type - 'add' (revert deal) or 'deduct' (revert expense)
 * @param {string} referenceId - ID of deal/expense
 * @returns {Promise<number>} New balance
 */
export const revertBalance = async (amount, type, referenceId = null) => {
  try {
    // Revert means opposite operation
    const oppositeType = type === 'add' ? 'deduct' : 'add';
    return await updateBalance(amount, oppositeType, referenceId);
  } catch (error) {
    console.error('Error reverting balance:', error);
    throw error;
  }
};

/**
 * Real-time listener for company balance
 */
export const subscribeToCompanyBalance = (callback) => {
  try {
    const companyId = getCompanyId();
    const companyRef = doc(db, COMPANY_COLLECTION, companyId);
    
    return onSnapshot(
      companyRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          const totalRevenue = parseFloat(data.totalRevenue || 0);
          const totalExpenses = parseFloat(data.totalExpenses || 0);
          const currentBalance = totalRevenue - totalExpenses;
          
          callback({
            companyId: data.companyId || companyId,
            companyName: data.companyName || 'Larawans',
            currentBalance: currentBalance,
            totalRevenue: totalRevenue,
            totalExpenses: totalExpenses,
            currency: data.currency || '₹',
            lastUpdated: data.lastUpdated,
          });
        } else {
          // Initialize if doesn't exist
          callback({
            companyId: companyId,
            companyName: 'Larawans',
            currentBalance: 0,
            totalRevenue: 0,
            totalExpenses: 0,
            currency: '₹',
            lastUpdated: null,
          });
        }
      },
      (error) => {
        console.error('Error in subscribeToCompanyBalance:', error);
        callback({
          companyId: companyId,
          companyName: 'Larawans',
          currentBalance: 0,
          totalRevenue: 0,
          totalExpenses: 0,
          currency: '₹',
          lastUpdated: null,
        });
      }
    );
  } catch (error) {
    console.error('Error setting up balance subscription:', error);
    const companyId = getCompanyId();
    callback({
      companyId: companyId,
      companyName: 'Larawans',
      currentBalance: 0,
      totalRevenue: 0,
      totalExpenses: 0,
      currency: '₹',
      lastUpdated: null,
    });
    return () => {}; // Return empty unsubscribe function
  }
};

/**
 * Reset company balance to zero
 * This will reset currentBalance, totalRevenue, and totalExpenses to 0
 */
export const resetCompanyBalance = async () => {
  try {
    const companyId = getCompanyId();
    const companyRef = doc(db, COMPANY_COLLECTION, companyId);
    
    await runTransaction(db, async (transaction) => {
      const companyDoc = await transaction.get(companyRef);
      
      if (!companyDoc.exists()) {
        // Initialize with zeros if doesn't exist
        transaction.set(companyRef, {
          companyId: companyId,
          companyName: 'Larawans',
          currentBalance: 0,
          totalRevenue: 0,
          totalExpenses: 0,
          currency: '₹',
          lastUpdated: serverTimestamp(),
        });
      } else {
        // Reset to zero
        transaction.update(companyRef, {
          currentBalance: 0,
          totalRevenue: 0,
          totalExpenses: 0,
          lastUpdated: serverTimestamp(),
        });
      }
    });
    
    return { success: true };
  } catch (error) {
    console.error('Error resetting company balance:', error);
    throw error;
  }
};

