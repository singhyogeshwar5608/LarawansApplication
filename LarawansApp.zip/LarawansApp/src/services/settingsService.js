// Settings Service - Firebase operations for app settings

import { db } from '../config/firebase';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  onSnapshot,
  query,
  where,
  serverTimestamp,
} from 'firebase/firestore';

const SETTINGS_COLLECTION = 'settings';
const USERS_COLLECTION = 'users';
const BUSINESS_COLLECTION = 'business';
const TEAM_COLLECTION = 'team';

/**
 * Get user settings
 */
export const getUserSettings = async (userId) => {
  try {
    const docRef = doc(db, USERS_COLLECTION, userId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data();
    }
    return null;
  } catch (error) {
    // Handle permission errors gracefully - don't break the app
    if (error.code === 'permission-denied' || error.message?.includes('permission')) {
      console.warn('User settings permission denied. This is normal if the collection doesn\'t exist yet.');
      return null;
    }
    console.error('Error getting user settings:', error);
    // Don't throw - return null to allow app to continue
    return null;
  }
};

/**
 * Update user settings
 */
export const updateUserSettings = async (userId, settings) => {
  try {
    const docRef = doc(db, USERS_COLLECTION, userId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      await updateDoc(docRef, {
        ...settings,
        updatedAt: serverTimestamp(),
      });
    } else {
      // Create document if it doesn't exist
      await setDoc(docRef, {
        ...settings,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    // Handle permission errors gracefully
    if (error.code === 'permission-denied' || error.message?.includes('permission')) {
      console.warn('User settings update permission denied. Please check Firestore rules.');
      throw new Error('Permission denied. Please check your Firestore security rules.');
    }
    console.error('Error updating user settings:', error);
    throw error;
  }
};

/**
 * Get business profile
 */
export const getBusinessProfile = async (businessId) => {
  try {
    const docRef = doc(db, BUSINESS_COLLECTION, businessId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data();
    }
    return null;
  } catch (error) {
    // Handle permission errors gracefully
    if (error.code === 'permission-denied' || error.message?.includes('permission')) {
      console.warn('Business profile permission denied. This is normal if the collection doesn\'t exist yet.');
      return null;
    }
    console.error('Error getting business profile:', error);
    // Don't throw - return null to allow app to continue
    return null;
  }
};

/**
 * Update business profile
 */
export const updateBusinessProfile = async (businessId, profile) => {
  try {
    const docRef = doc(db, BUSINESS_COLLECTION, businessId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      await updateDoc(docRef, {
        ...profile,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(docRef, {
        ...profile,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    console.error('Error updating business profile:', error);
    throw error;
  }
};

/**
 * Get app settings (admin only)
 */
export const getAppSettings = async () => {
  try {
    const docRef = doc(db, SETTINGS_COLLECTION, 'app');
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data();
    }
    return null;
  } catch (error) {
    // Handle permission errors gracefully
    if (error.code === 'permission-denied' || error.message?.includes('permission')) {
      console.warn('App settings permission denied. This is normal if the collection doesn\'t exist yet.');
      return null;
    }
    console.error('Error getting app settings:', error);
    // Don't throw - return null to allow app to continue
    return null;
  }
};

/**
 * Update app settings (admin only)
 */
export const updateAppSettings = async (settings) => {
  try {
    const docRef = doc(db, SETTINGS_COLLECTION, 'app');
    await setDoc(docRef, {
      ...settings,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (error) {
    console.error('Error updating app settings:', error);
    throw error;
  }
};

/**
 * Subscribe to app settings changes
 */
export const subscribeToAppSettings = (callback) => {
  const docRef = doc(db, SETTINGS_COLLECTION, 'app');
  return onSnapshot(docRef, (docSnap) => {
    if (docSnap.exists()) {
      callback(docSnap.data());
    } else {
      callback(null);
    }
  });
};

/**
 * Get team members
 */
export const getTeamMembers = async (userId) => {
  try {
    // For now, use userId as businessId (single business per user)
    // In future, you can add a businessId field to users collection
    const q = query(collection(db, TEAM_COLLECTION), where('businessId', '==', userId));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
    }));
  } catch (error) {
    console.error('Error getting team members:', error);
    throw error;
  }
};

/**
 * Subscribe to team members
 */
export const subscribeToTeamMembers = (userId, callback) => {
  // For now, use userId as businessId (single business per user)
  const q = query(collection(db, TEAM_COLLECTION), where('businessId', '==', userId));
  return onSnapshot(q, (querySnapshot) => {
    const members = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
    }));
    callback(members);
  });
};

