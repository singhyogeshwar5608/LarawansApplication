// Expense Service - Firebase Firestore operations for Expense Management

import {
  collection,
  doc,
  addDoc,
  updateDoc,
  setDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  serverTimestamp,
  writeBatch,
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { deductExpense, adjustBalance, revertBalance, getCompanyBalance as getBalance, resetCompanyBalance } from './balanceService';
import { getCurrentUser } from './authService';
import { isAuthorizedUser } from '../utils/authorizedUsers';

const EXPENSES_COLLECTION = 'expenses';

// Re-export getCompanyBalance from balanceService for backward compatibility
export { getCompanyBalance } from './balanceService';

/**
 * Add a new expense
 */
export const addExpense = async (expenseData) => {
  try {
    const expenseAmount = parseFloat(expenseData.amount);
    
    if (isNaN(expenseAmount) || expenseAmount <= 0) {
      throw new Error('Invalid expense amount');
    }
    
    // Get current user info
    const currentUser = getCurrentUser();
    const userEmail = currentUser?.email || '';
    const userId = currentUser?.uid || '';
    
    // Add expense to collection
    const expenseRef = await addDoc(collection(db, EXPENSES_COLLECTION), {
      ...expenseData,
      amount: expenseAmount,
      expenseDate: expenseData.expenseDate || new Date().toISOString().split('T')[0],
      userId: userId,
      userEmail: userEmail,
      isAuthorizedUser: isAuthorizedUser(userEmail),
      isBalanceUpdated: false, // Will be set to true after balance update
      balanceUpdatedAt: null,
      createdAt: serverTimestamp(),
      status: expenseData.status || 'approved',
      isRecurring: expenseData.isRecurring || false,
      tags: expenseData.tags || [],
    });
    
    const expenseId = expenseRef.id;
    
    // Deduct expense from company balance
    try {
      const newBalance = await deductExpense(
        expenseId,
        expenseAmount,
        expenseData.reason || 'Expense'
      );
      
      // Mark expense as balance updated
      await updateDoc(expenseRef, {
        isBalanceUpdated: true,
        balanceUpdatedAt: serverTimestamp(),
      });
      
      console.log(`Balance updated: ₹${expenseAmount} deducted. New balance: ₹${newBalance}`);
      
      return {
        id: expenseId,
        ...expenseData,
        amount: expenseAmount,
        newBalance: newBalance,
        isBalanceUpdated: true,
      };
    } catch (balanceError) {
      console.error('Balance update failed for expense:', balanceError);
      // Return expense even if balance update fails
      return {
        id: expenseId,
        ...expenseData,
        amount: expenseAmount,
        newBalance: null,
        isBalanceUpdated: false,
      };
    }
  } catch (error) {
    console.error('Error adding expense:', error);
    throw error;
  }
};

/**
 * Update an expense
 */
export const updateExpense = async (expenseId, updatedData) => {
  try {
    const expenseRef = doc(db, EXPENSES_COLLECTION, expenseId);
    const expenseSnap = await getDoc(expenseRef);
    
    if (!expenseSnap.exists()) {
      throw new Error('Expense not found');
    }
    
    const oldExpense = expenseSnap.data();
    const oldAmount = parseFloat(oldExpense.amount || 0);
    const newAmount = parseFloat(updatedData.amount) || oldAmount;
    
    // If amount changed and expense was previously balance updated, adjust balance
    if (oldAmount !== newAmount && oldExpense.isBalanceUpdated) {
      try {
        await adjustBalance(oldAmount, newAmount, 'deduct', expenseId);
        updatedData.balanceUpdatedAt = serverTimestamp();
      } catch (balanceError) {
        console.error('Balance adjustment failed for expense update:', balanceError);
        // Continue with expense update even if balance adjustment fails
      }
    }
    
    // Update expense
    await updateDoc(expenseRef, {
      ...updatedData,
      amount: newAmount,
      updatedAt: serverTimestamp(),
    });
    
    return { success: true };
  } catch (error) {
    console.error('Error updating expense:', error);
    throw error;
  }
};

/**
 * Delete an expense
 */
export const deleteExpense = async (expenseId) => {
  try {
    const expenseRef = doc(db, EXPENSES_COLLECTION, expenseId);
    const expenseSnap = await getDoc(expenseRef);
    
    if (!expenseSnap.exists()) {
      throw new Error('Expense not found');
    }
    
    const expenseData = expenseSnap.data();
    const amount = parseFloat(expenseData.amount || 0);
    
    // If expense was balance updated, revert the balance
    if (expenseData.isBalanceUpdated && amount > 0) {
      try {
        await revertBalance(amount, 'deduct', expenseId);
        console.log(`Balance reverted: ₹${amount} added back.`);
      } catch (balanceError) {
        console.error('Balance revert failed for expense deletion:', balanceError);
        // Continue with deletion even if balance revert fails
      }
    }
    
    // Delete expense
    await deleteDoc(expenseRef);
    
    return { success: true };
  } catch (error) {
    console.error('Error deleting expense:', error);
    throw error;
  }
};

/**
 * Get expenses with filters
 * Filters data based on user authorization
 */
export const getExpenses = async (filters = {}) => {
  try {
    const currentUser = getCurrentUser();
    const userEmail = currentUser?.email || '';
    const userId = currentUser?.uid || '';
    const isAuthorized = isAuthorizedUser(userEmail);
    
    let q = query(collection(db, EXPENSES_COLLECTION));
    
    // Apply filters
    if (filters.category) {
      q = query(q, where('category', '==', filters.category));
    }
    
    if (filters.paymentMethod) {
      q = query(q, where('paymentMethod', '==', filters.paymentMethod));
    }
    
    if (filters.startDate) {
      q = query(q, where('expenseDate', '>=', filters.startDate));
    }
    
    if (filters.endDate) {
      q = query(q, where('expenseDate', '<=', filters.endDate));
    }
    
    // Order by date (newest first)
    q = query(q, orderBy('createdAt', 'desc'));
    
    // Limit for pagination
    if (filters.limit) {
      q = query(q, limit(filters.limit));
    }
    
    const querySnapshot = await getDocs(q);
    const expenses = [];
    
    querySnapshot.forEach((doc) => {
      const expenseData = { id: doc.id, ...doc.data() };
      
      // Filter based on authorization
      if (isAuthorized) {
        // Authorized users see all expenses
        expenses.push(expenseData);
      } else {
        // Other users see only their own expenses
        if (expenseData.userId === userId || (!expenseData.userId && !expenseData.userEmail)) {
          expenses.push(expenseData);
        }
      }
    });
    
    return expenses;
  } catch (error) {
    console.error('Error getting expenses:', error);
    throw error;
  }
};

/**
 * Subscribe to expenses (real-time)
 * Filters data based on user authorization
 */
export const subscribeToExpenses = (callback, filters = {}) => {
  try {
    const currentUser = getCurrentUser();
    const userEmail = currentUser?.email || '';
    const userId = currentUser?.uid || '';
    const isAuthorized = isAuthorizedUser(userEmail);
    
    let q = query(collection(db, EXPENSES_COLLECTION));
    
    // Apply filters
    if (filters.category) {
      q = query(q, where('category', '==', filters.category));
    }
    
    if (filters.paymentMethod) {
      q = query(q, where('paymentMethod', '==', filters.paymentMethod));
    }
    
    // Order by date (newest first)
    q = query(q, orderBy('createdAt', 'desc'));
    
    return onSnapshot(
      q,
      (snapshot) => {
        const expenses = [];
        snapshot.forEach((doc) => {
          const expenseData = { id: doc.id, ...doc.data() };
          
          // Filter based on authorization
          if (isAuthorized) {
            // Authorized users see all expenses (including those without userId for backward compatibility)
            expenses.push(expenseData);
          } else {
            // Other users see only their own expenses
            if (expenseData.userId === userId || (!expenseData.userId && !expenseData.userEmail)) {
              expenses.push(expenseData);
            }
          }
        });
        callback(expenses);
      },
      (error) => {
        console.error('Error in subscribeToExpenses:', error);
        callback([]);
      }
    );
  } catch (error) {
    console.error('Error setting up expenses subscription:', error);
    callback([]);
    return () => {};
  }
};

// Re-export subscribeToCompanyBalance from balanceService for backward compatibility
export { subscribeToCompanyBalance } from './balanceService';

/**
 * Get expense statistics
 */
export const getExpenseStats = async (startDate, endDate) => {
  try {
    let q = query(collection(db, EXPENSES_COLLECTION));
    
    if (startDate) {
      q = query(q, where('expenseDate', '>=', startDate));
    }
    
    if (endDate) {
      q = query(q, where('expenseDate', '<=', endDate));
    }
    
    const querySnapshot = await getDocs(q);
    
    const stats = {
      totalExpenses: 0,
      categoryBreakdown: {},
      paymentMethodBreakdown: {},
      dailyExpenses: {},
      count: 0,
    };
    
    querySnapshot.forEach((doc) => {
      const expense = doc.data();
      const amount = expense.amount || 0;
      
      stats.totalExpenses += amount;
      stats.count += 1;
      
      // Category breakdown
      const category = expense.category || 'Other';
      stats.categoryBreakdown[category] = (stats.categoryBreakdown[category] || 0) + amount;
      
      // Payment method breakdown
      const paymentMethod = expense.paymentMethod || 'Cash';
      stats.paymentMethodBreakdown[paymentMethod] = (stats.paymentMethodBreakdown[paymentMethod] || 0) + amount;
      
      // Daily expenses
      const date = expense.expenseDate || expense.createdAt?.toDate?.()?.toISOString().split('T')[0];
      if (date) {
        stats.dailyExpenses[date] = (stats.dailyExpenses[date] || 0) + amount;
      }
    });
    
    return stats;
  } catch (error) {
    console.error('Error getting expense stats:', error);
    throw error;
  }
};

/**
 * Add income
 */
export const addIncome = async (amount, source, date) => {
  try {
    const newBalance = await updateCompanyBalance(parseFloat(amount), 'add');
    
    // You can create an income collection if needed
    // For now, we just update the balance
    
    return {
      success: true,
      newBalance,
    };
  } catch (error) {
    console.error('Error adding income:', error);
    throw error;
  }
};

/**
 * Delete all expenses and reset balance
 * This will delete all expense records and reset company balance to zero
 */
export const resetAllExpensesAndBalance = async () => {
  try {
    // Get all expenses
    const expensesSnapshot = await getDocs(collection(db, EXPENSES_COLLECTION));
    
    // Delete all expenses using batch
    const batch = writeBatch(db);
    let expenseCount = 0;
    
    expensesSnapshot.forEach((expenseDoc) => {
      batch.delete(expenseDoc.ref);
      expenseCount++;
    });
    
    // Commit batch delete
    await batch.commit();
    
    // Reset company balance to zero
    await resetCompanyBalance();
    
    return {
      success: true,
      deletedCount: expenseCount,
    };
  } catch (error) {
    console.error('Error resetting expenses and balance:', error);
    throw error;
  }
};

