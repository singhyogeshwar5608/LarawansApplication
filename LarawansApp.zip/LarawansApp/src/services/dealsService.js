// Deals Service - Firebase Firestore operations for Deals

import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  where,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { addRevenue, adjustBalance, revertBalance } from './balanceService';
import { getCurrentUser } from './authService';
import { isAuthorizedUser } from '../utils/authorizedUsers';

const COLLECTION_NAME = 'deals';

/**
 * Create a new deal
 */
export const createDeal = async (dealData) => {
  try {
    const currentUser = getCurrentUser();
    const userEmail = currentUser?.email || '';
    const userId = currentUser?.uid || '';
    
    const dealRef = await addDoc(collection(db, COLLECTION_NAME), {
      ...dealData,
      userId: userId,
      userEmail: userEmail,
      isAuthorizedUser: isAuthorizedUser(userEmail),
      isBalanceUpdated: false, // Will be set to true after balance update
      balanceUpdatedAt: null,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      paymentHistory: dealData.paymentHistory || [],
    });
    
    const dealId = dealRef.id;
    
    // Add deal total amount to company balance (revenue)
    const totalAmount = parseFloat(dealData.totalAmount || 0);
    if (totalAmount > 0) {
      try {
        const newBalance = await addRevenue(
          dealId,
          totalAmount,
          dealData.customerName || dealData.dealName || 'Deal'
        );
        
        // Mark deal as balance updated
        await updateDoc(dealRef, {
          isBalanceUpdated: true,
          balanceUpdatedAt: serverTimestamp(),
        });
        
        console.log(`Balance updated: ₹${totalAmount} added. New balance: ₹${newBalance}`);
      } catch (balanceError) {
        console.error('Balance update failed for deal:', balanceError);
        // Don't throw - deal is created, balance update can be retried
      }
    }
    
    return { id: dealId, ...dealData, isBalanceUpdated: totalAmount > 0 };
  } catch (error) {
    console.error('Error creating deal:', error);
    throw error;
  }
};

/**
 * Get a single deal by ID
 */
export const getDealById = async (dealId) => {
  try {
    const dealDoc = await getDoc(doc(db, COLLECTION_NAME, dealId));
    if (dealDoc.exists()) {
      return { id: dealDoc.id, ...dealDoc.data() };
    }
    return null;
  } catch (error) {
    console.error('Error getting deal:', error);
    throw error;
  }
};

/**
 * Alias for getDealById (for convenience)
 */
export const getDeal = getDealById;

/**
 * Get all deals (with optional filters)
 * NOTE: We sort in memory to avoid Firestore index requirements
 * Filters data based on user authorization
 */
export const getAllDeals = async (filters = {}) => {
  try {
    const currentUser = getCurrentUser();
    const userEmail = currentUser?.email || '';
    const userId = currentUser?.uid || '';
    const isAuthorized = isAuthorizedUser(userEmail);
    
    let q = collection(db, COLLECTION_NAME);
    
    // Apply filters (without orderBy to avoid index requirement)
    if (filters.status) {
      q = query(q, where('status', '==', filters.status));
    } else {
      q = query(q);
    }
    
    const querySnapshot = await getDocs(q);
    const deals = [];
    
    querySnapshot.forEach((doc) => {
      const dealData = { id: doc.id, ...doc.data() };
      
      // Filter based on authorization
      if (isAuthorized) {
        // Authorized users see all deals
        deals.push(dealData);
      } else {
        // Other users see only their own deals
        if (dealData.userId === userId || (!dealData.userId && !dealData.userEmail)) {
          deals.push(dealData);
        }
      }
    });
    
    // Sort in memory (newest first)
    deals.sort((a, b) => {
      const dateA = a.createdAt?.toDate?.() || new Date(a.createdAt || 0);
      const dateB = b.createdAt?.toDate?.() || new Date(b.createdAt || 0);
      return dateB - dateA;
    });
    
    return deals;
  } catch (error) {
    console.error('Error getting deals:', error);
    throw error;
  }
};

/**
 * Update a deal
 */
export const updateDeal = async (dealId, updates) => {
  try {
    const dealRef = doc(db, COLLECTION_NAME, dealId);
    
    // If totalAmount changed, adjust balance
    if (updates.totalAmount !== undefined) {
      const currentDeal = await getDealById(dealId);
      if (currentDeal) {
        const oldAmount = parseFloat(currentDeal.totalAmount || 0);
        const newAmount = parseFloat(updates.totalAmount || 0);
        
        if (oldAmount !== newAmount && currentDeal.isBalanceUpdated) {
          try {
            await adjustBalance(oldAmount, newAmount, 'add', dealId);
            updates.balanceUpdatedAt = serverTimestamp();
          } catch (balanceError) {
            console.error('Balance adjustment failed for deal update:', balanceError);
            // Continue with deal update even if balance adjustment fails
          }
        }
      }
    }
    
    await updateDoc(dealRef, {
      ...updates,
      updatedAt: serverTimestamp(),
    });
    return { id: dealId, ...updates };
  } catch (error) {
    console.error('Error updating deal:', error);
    throw error;
  }
};

/**
 * Delete a deal
 */
export const deleteDeal = async (dealId) => {
  try {
    // Get deal before deleting to revert balance
    const deal = await getDealById(dealId);
    
    if (deal && deal.isBalanceUpdated) {
      const dealAmount = parseFloat(deal.totalAmount || 0);
      if (dealAmount > 0) {
        try {
          await revertBalance(dealAmount, 'add', dealId);
          console.log(`Balance reverted: ₹${dealAmount} deducted.`);
        } catch (balanceError) {
          console.error('Balance revert failed for deal deletion:', balanceError);
          // Continue with deletion even if balance revert fails
        }
      }
    }
    
    await deleteDoc(doc(db, COLLECTION_NAME, dealId));
    return true;
  } catch (error) {
    console.error('Error deleting deal:', error);
    throw error;
  }
};

/**
 * Add payment to a deal
 */
export const addPayment = async (dealId, paymentData) => {
  try {
    const deal = await getDealById(dealId);
    if (!deal) throw new Error('Deal not found');
    
    const paymentHistory = deal.paymentHistory || [];
    const newPayment = {
      id: `payment_${Date.now()}`,
      ...paymentData,
      timestamp: serverTimestamp(),
    };
    
    paymentHistory.push(newPayment);
    
    // Update paid and pending amounts
    const paymentAmount = parseFloat(paymentData.amount);
    const newPaidAmount = (deal.paidAmount || 0) + paymentAmount;
    const newPendingAmount = (deal.totalAmount || 0) - newPaidAmount;
    
    // Note: We do NOT add payment to balance here
    // The deal's totalAmount was already added to balance when the deal was created
    // Payments only update the deal's paidAmount/pendingAmount, not the balance
    // Balance = Total Revenue (all deal amounts) - Total Expenses
    
    await updateDeal(dealId, {
      paymentHistory,
      paidAmount: newPaidAmount,
      pendingAmount: Math.max(0, newPendingAmount),
    });
    
    return newPayment;
  } catch (error) {
    console.error('Error adding payment:', error);
    throw error;
  }
};

/**
 * Real-time listener for deals
 * NOTE: We always sort in memory to avoid Firestore index requirements
 * Filters data based on user authorization:
 * - Authorized users see all deals
 * - Other users see only their own deals
 */
export const subscribeToDeals = (callback, filters = {}) => {
  const dealsCollection = collection(db, COLLECTION_NAME);
  const currentUser = getCurrentUser();
  const userEmail = currentUser?.email || '';
  const userId = currentUser?.uid || '';
  const isAuthorized = isAuthorizedUser(userEmail);
  
  try {
    let q;
    
    // Build query without orderBy to avoid index requirement
    // We'll sort in memory instead
    if (filters.status) {
      q = query(dealsCollection, where('status', '==', filters.status));
    } else {
      q = query(dealsCollection);
    }
    
    return onSnapshot(
      q,
      (snapshot) => {
        const deals = [];
        snapshot.forEach((doc) => {
          const dealData = { id: doc.id, ...doc.data() };
          
          // Filter based on authorization
          if (isAuthorized) {
            // Authorized users see all deals (including those without userId for backward compatibility)
            deals.push(dealData);
          } else {
            // Other users see only their own deals
            if (dealData.userId === userId || (!dealData.userId && !dealData.userEmail)) {
              deals.push(dealData);
            }
          }
        });
        
        // Always sort in memory (newest first)
        deals.sort((a, b) => {
          const dateA = a.createdAt?.toDate?.() || new Date(a.createdAt || 0);
          const dateB = b.createdAt?.toDate?.() || new Date(b.createdAt || 0);
          return dateB - dateA; // Descending order (newest first)
        });
        
        callback(deals);
      },
      (error) => {
        console.error('Error in subscribeToDeals:', error);
        // Return empty array on error
        callback([]);
      }
    );
  } catch (error) {
    console.error('Error setting up deals subscription:', error);
    callback([]);
    return () => {}; // Return empty unsubscribe function
  }
};

/**
 * Real-time listener for a single deal
 */
export const subscribeToDeal = (dealId, callback, onError) => {
  const dealRef = doc(db, COLLECTION_NAME, dealId);
  
  return onSnapshot(
    dealRef,
    (docSnapshot) => {
      if (docSnapshot.exists()) {
        callback({ id: docSnapshot.id, ...docSnapshot.data() });
      } else {
        callback(null);
      }
    },
    (error) => {
      console.error('Error in subscribeToDeal:', error);
      if (onError) {
        onError(error);
      } else {
        callback(null);
      }
    }
  );
};

