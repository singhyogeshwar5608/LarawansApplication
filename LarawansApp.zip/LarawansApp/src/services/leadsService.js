// Leads Service - Firebase Firestore operations for Leads

import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  where,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { getCurrentUser } from './authService';
import { isAuthorizedUser } from '../utils/authorizedUsers';

const COLLECTION_NAME = 'leads';

/**
 * Create a new lead
 */
export const createLead = async (leadData) => {
  try {
    const currentUser = getCurrentUser();
    const userEmail = currentUser?.email || '';
    const userId = currentUser?.uid || '';
    
    const leadRef = await addDoc(collection(db, COLLECTION_NAME), {
      ...leadData,
      userId: userId,
      userEmail: userEmail,
      isAuthorizedUser: isAuthorizedUser(userEmail),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      callHistory: leadData.callHistory || [],
    });
    return { id: leadRef.id, ...leadData };
  } catch (error) {
    console.error('Error creating lead:', error);
    throw error;
  }
};

/**
 * Get a single lead by ID
 */
export const getLeadById = async (leadId) => {
  try {
    const leadDoc = await getDoc(doc(db, COLLECTION_NAME, leadId));
    if (leadDoc.exists()) {
      return { id: leadDoc.id, ...leadDoc.data() };
    }
    return null;
  } catch (error) {
    console.error('Error getting lead:', error);
    throw error;
  }
};

/**
 * Alias for getLeadById (for convenience)
 */
export const getLead = getLeadById;

/**
 * Get all leads (with optional filters)
 * NOTE: We sort in memory to avoid Firestore index requirements
 * Filters data based on user authorization
 */
export const getAllLeads = async (filters = {}) => {
  try {
    const currentUser = getCurrentUser();
    const userEmail = currentUser?.email || '';
    const userId = currentUser?.uid || '';
    const isAuthorized = isAuthorizedUser(userEmail);
    
    let q = collection(db, COLLECTION_NAME);
    
    // Apply filters (without orderBy to avoid index requirement)
    if (filters.status) {
      q = query(q, where('status', '==', filters.status));
    } else {
      q = query(q);
    }
    
    const querySnapshot = await getDocs(q);
    const leads = [];
    
    querySnapshot.forEach((doc) => {
      const leadData = { id: doc.id, ...doc.data() };
      
      // Filter based on authorization
      if (isAuthorized) {
        // Authorized users see all leads
        leads.push(leadData);
      } else {
        // Other users see only their own leads
        if (leadData.userId === userId || (!leadData.userId && !leadData.userEmail)) {
          leads.push(leadData);
        }
      }
    });
    
    // Sort in memory (newest first)
    leads.sort((a, b) => {
      const dateA = a.createdAt?.toDate?.() || new Date(a.createdAt || 0);
      const dateB = b.createdAt?.toDate?.() || new Date(b.createdAt || 0);
      return dateB - dateA;
    });
    
    return leads;
  } catch (error) {
    console.error('Error getting leads:', error);
    throw error;
  }
};

/**
 * Update a lead
 */
export const updateLead = async (leadId, updates) => {
  try {
    const leadRef = doc(db, COLLECTION_NAME, leadId);
    await updateDoc(leadRef, {
      ...updates,
      updatedAt: serverTimestamp(),
    });
    return { id: leadId, ...updates };
  } catch (error) {
    console.error('Error updating lead:', error);
    throw error;
  }
};

/**
 * Delete a lead
 */
export const deleteLead = async (leadId) => {
  try {
    await deleteDoc(doc(db, COLLECTION_NAME, leadId));
    return true;
  } catch (error) {
    console.error('Error deleting lead:', error);
    throw error;
  }
};

/**
 * Add call history to a lead
 */
export const addCallHistory = async (leadId, callRecord) => {
  try {
    const lead = await getLeadById(leadId);
    if (!lead) throw new Error('Lead not found');
    
    const callHistory = lead.callHistory || [];
    callHistory.push({
      ...callRecord,
      timestamp: new Date().toISOString(),
    });
    
    await updateLead(leadId, { callHistory });
    return callHistory;
  } catch (error) {
    console.error('Error adding call history:', error);
    throw error;
  }
};

/**
 * Update call history for a lead (alias for addCallHistory)
 */
export const updateLeadCallHistory = async (leadId, callRecord) => {
  return addCallHistory(leadId, callRecord);
};

/**
 * Check if phone number already exists
 * Checks only within user's accessible data (their own or authorized users' data)
 */
export const checkPhoneExists = async (phone) => {
  try {
    const currentUser = getCurrentUser();
    const userEmail = currentUser?.email || '';
    const userId = currentUser?.uid || '';
    const isAuthorized = isAuthorizedUser(userEmail);
    
    const q = query(
      collection(db, COLLECTION_NAME),
      where('phone', '==', phone)
    );
    const querySnapshot = await getDocs(q);
    
    // If authorized, check all leads
    if (isAuthorized) {
      return !querySnapshot.empty;
    }
    
    // Otherwise, check only user's own leads
    let exists = false;
    querySnapshot.forEach((doc) => {
      const leadData = doc.data();
      if (leadData.userId === userId || (!leadData.userId && !leadData.userEmail)) {
        exists = true;
      }
    });
    
    return exists;
  } catch (error) {
    console.error('Error checking phone:', error);
    throw error;
  }
};

/**
 * Real-time listener for leads
 * NOTE: We always sort in memory to avoid Firestore index requirements
 * Filters data based on user authorization:
 * - Authorized users see all leads
 * - Other users see only their own leads
 */
export const subscribeToLeads = (callback, filters = {}) => {
  const leadsCollection = collection(db, COLLECTION_NAME);
  const currentUser = getCurrentUser();
  const userEmail = currentUser?.email || '';
  const userId = currentUser?.uid || '';
  const isAuthorized = isAuthorizedUser(userEmail);
  
  try {
    let q;
    
    // Build query without orderBy to avoid index requirement
    // We'll sort in memory instead
    if (filters.status) {
      q = query(leadsCollection, where('status', '==', filters.status));
    } else {
      q = query(leadsCollection);
    }
    
    return onSnapshot(
      q,
      (snapshot) => {
        const leads = [];
        snapshot.forEach((doc) => {
          const leadData = { id: doc.id, ...doc.data() };
          
          // Filter based on authorization
          if (isAuthorized) {
            // Authorized users see all leads (including those without userId for backward compatibility)
            leads.push(leadData);
          } else {
            // Other users see only their own leads
            if (leadData.userId === userId || (!leadData.userId && !leadData.userEmail)) {
              leads.push(leadData);
            }
          }
        });
        
        // Always sort in memory (newest first)
        leads.sort((a, b) => {
          const dateA = a.createdAt?.toDate?.() || new Date(a.createdAt || 0);
          const dateB = b.createdAt?.toDate?.() || new Date(b.createdAt || 0);
          return dateB - dateA; // Descending order (newest first)
        });
        
        callback(leads);
      },
      (error) => {
        console.error('Error in subscribeToLeads:', error);
        // Return empty array on error
        callback([]);
      }
    );
  } catch (error) {
    console.error('Error setting up leads subscription:', error);
    callback([]);
    return () => {}; // Return empty unsubscribe function
  }
};

/**
 * Real-time listener for a single lead
 */
export const subscribeToLead = (leadId, callback) => {
  return onSnapshot(doc(db, COLLECTION_NAME, leadId), (docSnapshot) => {
    if (docSnapshot.exists()) {
      callback({ id: docSnapshot.id, ...docSnapshot.data() });
    } else {
      callback(null);
    }
  });
};

