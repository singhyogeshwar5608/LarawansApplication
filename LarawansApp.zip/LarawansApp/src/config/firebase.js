// Firebase Configuration
// Replace these values with your actual Firebase config from Firebase Console

import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyC5ORQr5IJCRdpKP0q1TBjNiERiiVwB1Pw",
  authDomain: "navapp-97ea3.firebaseapp.com",
  projectId: "navapp-97ea3",
  storageBucket: "navapp-97ea3.firebasestorage.app",
  messagingSenderId: "643766479514",
  appId: "1:643766479514:web:618d7c7454e8d7e4c68d23",
  measurementId: "G-H2M0YP1E6P"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();

// Configure Google Auth Provider
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

export default app;

