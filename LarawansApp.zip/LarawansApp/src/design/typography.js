// Design System - Typography

export const typography = {
  fontFamily: {
    sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
    mono: ['SF Mono', 'Monaco', 'Cascadia Code', 'Roboto Mono', 'monospace'],
  },

  fontSize: {
    // Display (for hero sections, landing pages)
    display: {
      lg: '4.5rem',      // 72px
      md: '3.75rem',     // 60px
      sm: '3rem',        // 48px
    },
    
    // Headings
    h1: '2.25rem',       // 36px
    h2: '1.875rem',      // 30px
    h3: '1.5rem',        // 24px
    h4: '1.25rem',       // 20px
    h5: '1.125rem',      // 18px
    h6: '1rem',          // 16px

    // Body
    body: {
      lg: '1.125rem',    // 18px
      base: '1rem',      // 16px
      sm: '0.875rem',    // 14px
      xs: '0.75rem',     // 12px
    },
  },

  fontWeight: {
    light: 300,
    regular: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
    extrabold: 800,
    black: 900,
  },

  lineHeight: {
    none: 1,
    tight: 1.25,
    snug: 1.375,
    normal: 1.5,
    relaxed: 1.625,
    loose: 2,
  },

  letterSpacing: {
    tighter: '-0.05em',
    tight: '-0.025em',
    normal: '0',
    wide: '0.025em',
    wider: '0.05em',
    widest: '0.1em',
  },
};

// Typography utility classes
export const typographyClasses = {
  h1: 'text-4xl font-bold tracking-tight',
  h2: 'text-3xl font-semibold tracking-tight',
  h3: 'text-2xl font-semibold tracking-tight',
  h4: 'text-xl font-semibold',
  h5: 'text-lg font-semibold',
  h6: 'text-base font-semibold',
  
  bodyLg: 'text-lg font-normal',
  body: 'text-base font-normal',
  bodySm: 'text-sm font-normal',
  bodyXs: 'text-xs font-normal',
  
  label: 'text-sm font-medium',
  caption: 'text-xs font-normal',
  overline: 'text-xs font-semibold uppercase tracking-wider',
};

