// Design System - Color Palette

export const colors = {
  // Primary colors (Professional Blue)
  primary: {
    50: '#eff6ff',
    100: '#dbeafe',
    200: '#bfdbfe',
    300: '#93c5fd',
    400: '#60a5fa',
    500: '#3b82f6', // Main primary
    600: '#2563eb',
    700: '#1d4ed8',
    800: '#1e40af',
    900: '#1e3a8a',
    950: '#172554',
  },

  // Secondary colors (Neutral gray)
  secondary: {
    50: '#f8fafc',
    100: '#f1f5f9',
    200: '#e2e8f0',
    300: '#cbd5e1',
    400: '#94a3b8',
    500: '#64748b',
    600: '#475569',
    700: '#334155',
    800: '#1e293b',
    900: '#0f172a',
    950: '#020617',
  },

  // Status colors
  status: {
    new: {
      light: '#4CAF50',
      dark: '#66BB6A',
      bg: '#E8F5E9',
      text: '#1B5E20',
    },
    interested: {
      light: '#FFC107',
      dark: '#FFD54F',
      bg: '#FFF9C4',
      text: '#F57F17',
    },
    scheduled: {
      light: '#2196F3',
      dark: '#42A5F5',
      bg: '#E3F2FD',
      text: '#0D47A1',
    },
    converted: {
      light: '#8BC34A',
      dark: '#9CCC65',
      bg: '#F1F8E9',
      text: '#33691E',
    },
    rejected: {
      light: '#F44336',
      dark: '#EF5350',
      bg: '#FFEBEE',
      text: '#B71C1C',
    },
  },

  // Semantic colors
  success: {
    light: '#10b981',
    dark: '#34d399',
    bg: '#d1fae5',
    text: '#065f46',
  },
  warning: {
    light: '#f59e0b',
    dark: '#fbbf24',
    bg: '#fef3c7',
    text: '#92400e',
  },
  danger: {
    light: '#ef4444',
    dark: '#f87171',
    bg: '#fee2e2',
    text: '#991b1b',
  },
  info: {
    light: '#3b82f6',
    dark: '#60a5fa',
    bg: '#dbeafe',
    text: '#1e40af',
  },
};

export const getStatusColor = (status) => {
  const statusMap = {
    new: colors.status.new,
    interested: colors.status.interested,
    scheduled: colors.status.scheduled,
    converted: colors.status.converted,
    rejected: colors.status.rejected,
  };
  return statusMap[status.toLowerCase()] || colors.secondary;
};

